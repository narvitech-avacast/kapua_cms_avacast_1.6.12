package org.eclipse.kapua.app.console.module.certificate.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/certificate/src/main/resources/org/eclipse/kapua/app/console/module/certificate/client/messages/ConsoleCertificateMessages.properties'.
 */
public interface ConsoleCertificateMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "Certificate".
   * 
   * @return translated "Certificate"
   */
  @DefaultMessage("Certificate")
  @Key("certificate")
  String certificate();
}
