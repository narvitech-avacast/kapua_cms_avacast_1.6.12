package org.eclipse.kapua.app.console.module.certificate.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtCertificateInfoServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.certificate.shared.service.GwtCertificateInfoService
     */
    void findAll( java.lang.String scopeIdString, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.certificate.shared.model.GwtCertificateInfo>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.certificate.shared.service.GwtCertificateInfoService
     */
    void isFindSupported( AsyncCallback<java.lang.Boolean> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtCertificateInfoServiceAsync instance;

        public static final GwtCertificateInfoServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtCertificateInfoServiceAsync) GWT.create( GwtCertificateInfoService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "certificateInfo" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
