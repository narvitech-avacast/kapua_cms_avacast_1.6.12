package org.eclipse.kapua.app.console.module.about.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/about/src/main/resources/org/eclipse/kapua/app/console/module/about/client/messages/ConsoleAboutMessages.properties'.
 */
public interface ConsoleAboutMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "(c) Copyright Eclipse contributors and others 2011, {0}. Eclipse and the Eclipse logo are trademarks of the Eclipse Foundation, Inc., <a target=\"_blank\" href=\"https://www.eclipse.org/\">https://www.eclipse.org/</a>. The Eclipse logo cannot be altered without Eclipse''s permission. Eclipse logos are provided for use under the Eclipse logo and trademark guidelines, <a target=\"_blank\" href=\"https://www.eclipse.org/logotm/\">https://www.eclipse.org/logotm/</a>. Oracle and Java are trademarks or registered trademarks of Oracle and/or its affiliates. Other names may be trademarks of their respective owners.<br/><br/>This product includes software developed by other open source projects including the Apache Software Foundation, <a target=\"_blank\" href=\"https://www.apache.org/\">https://www.apache.org/</a>.".
   * 
   * @return translated "(c) Copyright Eclipse contributors and others 2011, {0}. Eclipse and the Eclipse logo are trademarks of the Eclipse Foundation, Inc., <a target=\"_blank\" href=\"https://www.eclipse.org/\">https://www.eclipse.org/</a>. The Eclipse logo cannot be altered without Eclipse''s permission. Eclipse logos are provided for use under the Eclipse logo and trademark guidelines, <a target=\"_blank\" href=\"https://www.eclipse.org/logotm/\">https://www.eclipse.org/logotm/</a>. Oracle and Java are trademarks or registered trademarks of Oracle and/or its affiliates. Other names may be trademarks of their respective owners.<br/><br/>This product includes software developed by other open source projects including the Apache Software Foundation, <a target=\"_blank\" href=\"https://www.apache.org/\">https://www.apache.org/</a>."
   */
  @DefaultMessage("(c) Copyright Eclipse contributors and others 2011, {0}. Eclipse and the Eclipse logo are trademarks of the Eclipse Foundation, Inc., <a target=\"_blank\" href=\"https://www.eclipse.org/\">https://www.eclipse.org/</a>. The Eclipse logo cannot be altered without Eclipse''s permission. Eclipse logos are provided for use under the Eclipse logo and trademark guidelines, <a target=\"_blank\" href=\"https://www.eclipse.org/logotm/\">https://www.eclipse.org/logotm/</a>. Oracle and Java are trademarks or registered trademarks of Oracle and/or its affiliates. Other names may be trademarks of their respective owners.<br/><br/>This product includes software developed by other open source projects including the Apache Software Foundation, <a target=\"_blank\" href=\"https://www.apache.org/\">https://www.apache.org/</a>.")
  @Key("aboutBlurb")
  String aboutBlurb(String arg0);

  /**
   * Translated "ID".
   * 
   * @return translated "ID"
   */
  @DefaultMessage("ID")
  @Key("columnNameId")
  String columnNameId();

  /**
   * Translated "License".
   * 
   * @return translated "License"
   */
  @DefaultMessage("License")
  @Key("columnNameLicense")
  String columnNameLicense();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("columnNameName")
  String columnNameName();

  /**
   * Translated "Version".
   * 
   * @return translated "Version"
   */
  @DefaultMessage("Version")
  @Key("columnNameVersion")
  String columnNameVersion();

  /**
   * Translated "Failed to load about data".
   * 
   * @return translated "Failed to load about data"
   */
  @DefaultMessage("Failed to load about data")
  @Key("failedToLoad")
  String failedToLoad();

  /**
   * Translated "About".
   * 
   * @return translated "About"
   */
  @DefaultMessage("About")
  @Key("title")
  String title();
}
