package org.eclipse.kapua.app.console.module.about.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtAboutServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.about.shared.service.GwtAboutService
     */
    void getInformation( AsyncCallback<org.eclipse.kapua.app.console.module.about.shared.model.GwtAboutInformation> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.about.shared.service.GwtAboutService
     */
    void dummyGwtAboutDependency( AsyncCallback<org.eclipse.kapua.app.console.module.about.shared.model.GwtAboutDependency> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtAboutServiceAsync instance;

        public static final GwtAboutServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtAboutServiceAsync) GWT.create( GwtAboutService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "about" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
