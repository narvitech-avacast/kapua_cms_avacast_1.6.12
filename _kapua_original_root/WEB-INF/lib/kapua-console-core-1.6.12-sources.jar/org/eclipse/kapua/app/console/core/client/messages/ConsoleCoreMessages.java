package org.eclipse.kapua.app.console.core.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/core/src/main/resources/org/eclipse/kapua/app/console/core/client/messages/ConsoleCoreMessages.properties'.
 */
public interface ConsoleCoreMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "Login Failed.".
   * 
   * @return translated "Login Failed."
   */
  @DefaultMessage("Login Failed.")
  @Key("loginError")
  String loginError();

  /**
   * Translated "Login".
   * 
   * @return translated "Login"
   */
  @DefaultMessage("Login")
  @Key("loginLogin")
  String loginLogin();

  /**
   * Translated "Password".
   * 
   * @return translated "Password"
   */
  @DefaultMessage("Password")
  @Key("loginPassword")
  String loginPassword();

  /**
   * Translated "Reset".
   * 
   * @return translated "Reset"
   */
  @DefaultMessage("Reset")
  @Key("loginReset")
  String loginReset();

  /**
   * Translated "Error retrieving SSO Enablement status ".
   * 
   * @return translated "Error retrieving SSO Enablement status "
   */
  @DefaultMessage("Error retrieving SSO Enablement status ")
  @Key("loginSsoEnabledError")
  String loginSsoEnabledError();

  /**
   * Translated "SSO Login".
   * 
   * @return translated "SSO Login"
   */
  @DefaultMessage("SSO Login")
  @Key("loginSsoLogin")
  String loginSsoLogin();

  /**
   * Translated "SSO Login Error".
   * 
   * @return translated "SSO Login Error"
   */
  @DefaultMessage("SSO Login Error")
  @Key("loginSsoLoginError")
  String loginSsoLoginError();

  /**
   * Translated "{0} Console Login".
   * 
   * @return translated "{0} Console Login"
   */
  @DefaultMessage("{0} Console Login")
  @Key("loginTitle")
  String loginTitle(String arg0);

  /**
   * Translated "Username".
   * 
   * @return translated "Username"
   */
  @DefaultMessage("Username")
  @Key("loginUsername")
  String loginUsername();

  /**
   * Translated "Access denied, client authentication failed.".
   * 
   * @return translated "Access denied, client authentication failed."
   */
  @DefaultMessage("Access denied, client authentication failed.")
  @Key("ssoClientAuthenticationFailed")
  String ssoClientAuthenticationFailed();
}
