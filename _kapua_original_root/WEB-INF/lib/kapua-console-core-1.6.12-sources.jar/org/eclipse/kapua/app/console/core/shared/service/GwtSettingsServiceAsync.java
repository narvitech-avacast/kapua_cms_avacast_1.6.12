package org.eclipse.kapua.app.console.core.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtSettingsServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.core.shared.service.GwtSettingsService
     */
    void getProductInformation( AsyncCallback<org.eclipse.kapua.app.console.core.shared.model.GwtProductInformation> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.core.shared.service.GwtSettingsService
     */
    void getOpenIDLoginUri( AsyncCallback<java.lang.String> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.core.shared.service.GwtSettingsService
     */
    void getOpenIDLogoutUri( java.lang.String idToken, AsyncCallback<java.lang.String> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.core.shared.service.GwtSettingsService
     */
    void getHomeUri( AsyncCallback<java.lang.String> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.core.shared.service.GwtSettingsService
     */
    void getOpenIDEnabled( AsyncCallback<java.lang.Boolean> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtSettingsServiceAsync instance;

        public static final GwtSettingsServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtSettingsServiceAsync) GWT.create( GwtSettingsService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "settings" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
