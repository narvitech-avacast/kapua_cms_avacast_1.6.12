package org.eclipse.kapua.app.console.module.device.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/device/src/main/resources/org/eclipse/kapua/app/console/module/device/client/messages/ConsoleConnectionMessages.properties'.
 */
public interface ConsoleConnectionMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "Connected".
   * 
   * @return translated "Connected"
   */
  @DefaultMessage("Connected")
  @Key("connected")
  String connected();

  /**
   * Translated "Client IP".
   * 
   * @return translated "Client IP"
   */
  @DefaultMessage("Client IP")
  @Key("connectionFilterCLientIPLabel")
  String connectionFilterCLientIPLabel();

  /**
   * Translated "Client ID".
   * 
   * @return translated "Client ID"
   */
  @DefaultMessage("Client ID")
  @Key("connectionFilterClientIdLabel")
  String connectionFilterClientIdLabel();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("connectionFilterConnectionStatus")
  String connectionFilterConnectionStatus();

  /**
   * Translated "ANY".
   * 
   * @return translated "ANY"
   */
  @DefaultMessage("ANY")
  @Key("connectionFilterConnectionStatusEmptyText")
  String connectionFilterConnectionStatusEmptyText();

  /**
   * Translated "Connection Filter".
   * 
   * @return translated "Connection Filter"
   */
  @DefaultMessage("Connection Filter")
  @Key("connectionFilterHeader")
  String connectionFilterHeader();

  /**
   * Translated "Protocol".
   * 
   * @return translated "Protocol"
   */
  @DefaultMessage("Protocol")
  @Key("connectionFilterProtocolLabel")
  String connectionFilterProtocolLabel();

  /**
   * Translated "Reserved User".
   * 
   * @return translated "Reserved User"
   */
  @DefaultMessage("Reserved User")
  @Key("connectionFilterReservedUserLabel")
  String connectionFilterReservedUserLabel();

  /**
   * Translated "Last User".
   * 
   * @return translated "Last User"
   */
  @DefaultMessage("Last User")
  @Key("connectionFilterUser")
  String connectionFilterUser();

  /**
   * Translated "Error:".
   * 
   * @return translated "Error:"
   */
  @DefaultMessage("Error:")
  @Key("connectionFilteringPopUpError")
  String connectionFilteringPopUpError();

  /**
   * Translated "Error while fetching Users!".
   * 
   * @return translated "Error while fetching Users!"
   */
  @DefaultMessage("Error while fetching Users!")
  @Key("connectionFilteringUsersError")
  String connectionFilteringUsersError();

  /**
   * Translated "Empty".
   * 
   * @return translated "Empty"
   */
  @DefaultMessage("Empty")
  @Key("connectionFiltreUserEmptyText")
  String connectionFiltreUserEmptyText();

  /**
   * Translated "Allow User Change".
   * 
   * @return translated "Allow User Change"
   */
  @DefaultMessage("Allow User Change")
  @Key("connectionFormAllowUserChange")
  String connectionFormAllowUserChange();

  /**
   * Translated "Allow the user bound to the connection to be changed (if in STRICT mode and no reserved user id is set).".
   * 
   * @return translated "Allow the user bound to the connection to be changed (if in STRICT mode and no reserved user id is set)."
   */
  @DefaultMessage("Allow the user bound to the connection to be changed (if in STRICT mode and no reserved user id is set).")
  @Key("connectionFormAllowUserChangeTooltip")
  String connectionFormAllowUserChangeTooltip();

  /**
   * Translated "Security options".
   * 
   * @return translated "Security options"
   */
  @DefaultMessage("Security options")
  @Key("connectionFormFieldsetSecurityOptions")
  String connectionFormFieldsetSecurityOptions();

  /**
   * Translated "Last User".
   * 
   * @return translated "Last User"
   */
  @DefaultMessage("Last User")
  @Key("connectionFormLastUser")
  String connectionFormLastUser();

  /**
   * Translated "Last user used to connect the device.".
   * 
   * @return translated "Last user used to connect the device."
   */
  @DefaultMessage("Last user used to connect the device.")
  @Key("connectionFormLastUserTooltip")
  String connectionFormLastUserTooltip();

  /**
   * Translated "Reserved User".
   * 
   * @return translated "Reserved User"
   */
  @DefaultMessage("Reserved User")
  @Key("connectionFormReservedUser")
  String connectionFormReservedUser();

  /**
   * Translated "No user".
   * 
   * @return translated "No user"
   */
  @DefaultMessage("No user")
  @Key("connectionFormReservedUserNoUser")
  String connectionFormReservedUserNoUser();

  /**
   * Translated "Set reserved user for this connection. After this, other devices will not be able to connect with this user to Kapua.".
   * 
   * @return translated "Set reserved user for this connection. After this, other devices will not be able to connect with this user to Kapua."
   */
  @DefaultMessage("Set reserved user for this connection. After this, other devices will not be able to connect with this user to Kapua.")
  @Key("connectionFormReservedUserTooltip")
  String connectionFormReservedUserTooltip();

  /**
   * Translated "User Coupling Mode".
   * 
   * @return translated "User Coupling Mode"
   */
  @DefaultMessage("User Coupling Mode")
  @Key("connectionFormUserCouplingMode")
  String connectionFormUserCouplingMode();

  /**
   * Translated "Set the User-connection coupling bound behavior.".
   * 
   * @return translated "Set the User-connection coupling bound behavior."
   */
  @DefaultMessage("Set the User-connection coupling bound behavior.")
  @Key("connectionFormUserCouplingModeTooltip")
  String connectionFormUserCouplingModeTooltip();

  /**
   * Translated "Client ID".
   * 
   * @return translated "Client ID"
   */
  @DefaultMessage("Client ID")
  @Key("connectionTableClientId")
  String connectionTableClientId();

  /**
   * Translated "Client IP".
   * 
   * @return translated "Client IP"
   */
  @DefaultMessage("Client IP")
  @Key("connectionTableClientIp")
  String connectionTableClientIp();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultMessage("Modified On")
  @Key("connectionTableModifiedOn")
  String connectionTableModifiedOn();

  /**
   * Translated "Protocol".
   * 
   * @return translated "Protocol"
   */
  @DefaultMessage("Protocol")
  @Key("connectionTableProtocol")
  String connectionTableProtocol();

  /**
   * Translated "Reserved User".
   * 
   * @return translated "Reserved User"
   */
  @DefaultMessage("Reserved User")
  @Key("connectionTableReservedUserName")
  String connectionTableReservedUserName();

  /**
   * Translated "Connection Status".
   * 
   * @return translated "Connection Status"
   */
  @DefaultMessage("Connection Status")
  @Key("connectionTableStatus")
  String connectionTableStatus();

  /**
   * Translated "User Coupling Mode".
   * 
   * @return translated "User Coupling Mode"
   */
  @DefaultMessage("User Coupling Mode")
  @Key("connectionTableUserCouplingMode")
  String connectionTableUserCouplingMode();

  /**
   * Translated "User".
   * 
   * @return translated "User"
   */
  @DefaultMessage("User")
  @Key("connectionTableUserId")
  String connectionTableUserId();

  /**
   * Translated "Last User".
   * 
   * @return translated "Last User"
   */
  @DefaultMessage("Last User")
  @Key("connectionTableUserName")
  String connectionTableUserName();

  /**
   * Translated "Connections".
   * 
   * @return translated "Connections"
   */
  @DefaultMessage("Connections")
  @Key("connections")
  String connections();

  /**
   * Translated "Connection successfully updated.".
   * 
   * @return translated "Connection successfully updated."
   */
  @DefaultMessage("Connection successfully updated.")
  @Key("dialogEditConfirmation")
  String dialogEditConfirmation();

  /**
   * Translated "Connection edit failed: {0}".
   * 
   * @return translated "Connection edit failed: {0}"
   */
  @DefaultMessage("Connection edit failed: {0}")
  @Key("dialogEditError")
  String dialogEditError(String arg0);

  /**
   * Translated "Edit Connection: {0}".
   * 
   * @return translated "Edit Connection: {0}"
   */
  @DefaultMessage("Edit Connection: {0}")
  @Key("dialogEditHeader")
  String dialogEditHeader(String arg0);

  /**
   * Translated "Edit Connection''s security options.".
   * 
   * @return translated "Edit Connection''s security options."
   */
  @DefaultMessage("Edit Connection''s security options.")
  @Key("dialogEditInfo")
  String dialogEditInfo();

  /**
   * Translated "Disconnected".
   * 
   * @return translated "Disconnected"
   */
  @DefaultMessage("Disconnected")
  @Key("disconnected")
  String disconnected();

  /**
   * Translated "Enabled".
   * 
   * @return translated "Enabled"
   */
  @DefaultMessage("Enabled")
  @Key("enabled")
  String enabled();

  /**
   * Translated "Missing".
   * 
   * @return translated "Missing"
   */
  @DefaultMessage("Missing")
  @Key("missing")
  String missing();

  /**
   * Translated "Unknown".
   * 
   * @return translated "Unknown"
   */
  @DefaultMessage("Unknown")
  @Key("unknown")
  String unknown();
}
