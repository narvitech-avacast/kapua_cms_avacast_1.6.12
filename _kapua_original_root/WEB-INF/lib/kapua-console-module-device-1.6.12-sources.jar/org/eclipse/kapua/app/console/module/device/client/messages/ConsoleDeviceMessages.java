package org.eclipse.kapua.app.console.module.device.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/device/src/main/resources/org/eclipse/kapua/app/console/module/device/client/messages/ConsoleDeviceMessages.properties'.
 */
public interface ConsoleDeviceMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "Action".
   * 
   * @return translated "Action"
   */
  @DefaultMessage("Action")
  @Key("assetAction")
  String assetAction();

  /**
   * Translated "ASSETS".
   * 
   * @return translated "ASSETS"
   */
  @DefaultMessage("ASSETS")
  @Key("assetButton")
  String assetButton();

  /**
   * Translated "Assets".
   * 
   * @return translated "Assets"
   */
  @DefaultMessage("Assets")
  @Key("assetColumn")
  String assetColumn();

  /**
   * Translated "\"Asset 1(Driver)\"".
   * 
   * @return translated "\"Asset 1(Driver)\""
   */
  @DefaultMessage("\"Asset 1(Driver)\"")
  @Key("assetDriverLabel")
  String assetDriverLabel();

  /**
   * Translated "Asset 1(Driver)".
   * 
   * @return translated "Asset 1(Driver)"
   */
  @DefaultMessage("Asset 1(Driver)")
  @Key("assetLabel")
  String assetLabel();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("assetName")
  String assetName();

  /**
   * Translated "Asset Name: {0}".
   * 
   * @return translated "Asset Name: {0}"
   */
  @DefaultMessage("Asset Name: {0}")
  @Key("assetNameLabel")
  String assetNameLabel(String arg0);

  /**
   * Translated "No Available Assets".
   * 
   * @return translated "No Available Assets"
   */
  @DefaultMessage("No Available Assets")
  @Key("assetNoAssets")
  String assetNoAssets();

  /**
   * Translated "The selected device has no available assets.".
   * 
   * @return translated "The selected device has no available assets."
   */
  @DefaultMessage("The selected device has no available assets.")
  @Key("assetNoAssetsErrorMessage")
  String assetNoAssetsErrorMessage();

  /**
   * Translated "READ ALL".
   * 
   * @return translated "READ ALL"
   */
  @DefaultMessage("READ ALL")
  @Key("assetReadAll")
  String assetReadAll();

  /**
   * Translated "Read/Write".
   * 
   * @return translated "Read/Write"
   */
  @DefaultMessage("Read/Write")
  @Key("assetReadWrite")
  String assetReadWrite();

  /**
   * Translated "Asset".
   * 
   * @return translated "Asset"
   */
  @DefaultMessage("Asset")
  @Key("assetTabItemTitle")
  String assetTabItemTitle();

  /**
   * Translated "Value".
   * 
   * @return translated "Value"
   */
  @DefaultMessage("Value")
  @Key("assetValue")
  String assetValue();

  /**
   * Translated "Values".
   * 
   * @return translated "Values"
   */
  @DefaultMessage("Values")
  @Key("assetValuesTab")
  String assetValuesTab();

  /**
   * Translated "WRITE ALL".
   * 
   * @return translated "WRITE ALL"
   */
  @DefaultMessage("WRITE ALL")
  @Key("assetWriteAll")
  String assetWriteAll();

  /**
   * Translated "Assets".
   * 
   * @return translated "Assets"
   */
  @DefaultMessage("Assets")
  @Key("assets")
  String assets();

  /**
   * Translated "Start".
   * 
   * @return translated "Start"
   */
  @DefaultMessage("Start")
  @Key("buttonBundleStart")
  String buttonBundleStart();

  /**
   * Translated "Stop".
   * 
   * @return translated "Stop"
   */
  @DefaultMessage("Stop")
  @Key("buttonBundleStop")
  String buttonBundleStop();

  /**
   * Translated "Install".
   * 
   * @return translated "Install"
   */
  @DefaultMessage("Install")
  @Key("buttonPackageInstall")
  String buttonPackageInstall();

  /**
   * Translated "Log".
   * 
   * @return translated "Log"
   */
  @DefaultMessage("Log")
  @Key("buttonPackageLog")
  String buttonPackageLog();

  /**
   * Translated "Uninstall".
   * 
   * @return translated "Uninstall"
   */
  @DefaultMessage("Uninstall")
  @Key("buttonPackageUninstall")
  String buttonPackageUninstall();

  /**
   * Translated "Download".
   * 
   * @return translated "Download"
   */
  @DefaultMessage("Download")
  @Key("buttonSnapshotDownload")
  String buttonSnapshotDownload();

  /**
   * Translated "Rollback To".
   * 
   * @return translated "Rollback To"
   */
  @DefaultMessage("Rollback To")
  @Key("buttonSnapshotRollback")
  String buttonSnapshotRollback();

  /**
   * Translated "Upload And Apply".
   * 
   * @return translated "Upload And Apply"
   */
  @DefaultMessage("Upload And Apply")
  @Key("buttonSnapshotUpload")
  String buttonSnapshotUpload();

  /**
   * Translated "Certificate Type:".
   * 
   * @return translated "Certificate Type:"
   */
  @DefaultMessage("Certificate Type:")
  @Key("certificateType")
  String certificateType();

  /**
   * Translated "CHANNELS".
   * 
   * @return translated "CHANNELS"
   */
  @DefaultMessage("CHANNELS")
  @Key("channelButton")
  String channelButton();

  /**
   * Translated "ID".
   * 
   * @return translated "ID"
   */
  @DefaultMessage("ID")
  @Key("channelId")
  String channelId();

  /**
   * Translated "memory_address".
   * 
   * @return translated "memory_address"
   */
  @DefaultMessage("memory_address")
  @Key("channelMemoryAddress")
  String channelMemoryAddress();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("channelName")
  String channelName();

  /**
   * Translated "primary_table".
   * 
   * @return translated "primary_table"
   */
  @DefaultMessage("primary_table")
  @Key("channelPrimaryTable")
  String channelPrimaryTable();

  /**
   * Translated "Type".
   * 
   * @return translated "Type"
   */
  @DefaultMessage("Type")
  @Key("channelType")
  String channelType();

  /**
   * Translated "unit_id".
   * 
   * @return translated "unit_id"
   */
  @DefaultMessage("unit_id")
  @Key("channelUnitId")
  String channelUnitId();

  /**
   * Translated "Value Type".
   * 
   * @return translated "Value Type"
   */
  @DefaultMessage("Value Type")
  @Key("channelValueType")
  String channelValueType();

  /**
   * Translated "Configuration".
   * 
   * @return translated "Configuration"
   */
  @DefaultMessage("Configuration")
  @Key("configurationTabItem")
  String configurationTabItem();

  /**
   * Translated "Configuration".
   * 
   * @return translated "Configuration"
   */
  @DefaultMessage("Configuration")
  @Key("configurationTabItemTitle")
  String configurationTabItemTitle();

  /**
   * Translated "Are you sure you want to apply the new channels values to the selected asset?".
   * 
   * @return translated "Are you sure you want to apply the new channels values to the selected asset?"
   */
  @DefaultMessage("Are you sure you want to apply the new channels values to the selected asset?")
  @Key("deviceAssetConfirmation")
  String deviceAssetConfirmation();

  /**
   * Translated "ID".
   * 
   * @return translated "ID"
   */
  @DefaultMessage("ID")
  @Key("deviceBndId")
  String deviceBndId();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("deviceBndName")
  String deviceBndName();

  /**
   * Translated "State".
   * 
   * @return translated "State"
   */
  @DefaultMessage("State")
  @Key("deviceBndState")
  String deviceBndState();

  /**
   * Translated "Version".
   * 
   * @return translated "Version"
   */
  @DefaultMessage("Version")
  @Key("deviceBndVersion")
  String deviceBndVersion();

  /**
   * Translated "Are you sure you want to delete the certificate {0} from the DNSSEC registry?".
   * 
   * @return translated "Are you sure you want to delete the certificate {0} from the DNSSEC registry?"
   */
  @DefaultMessage("Are you sure you want to delete the certificate {0} from the DNSSEC registry?")
  @Key("deviceCertificateDeleteConfirmation")
  String deviceCertificateDeleteConfirmation(String arg0);

  /**
   * Translated "Are you sure you want to disable the certificate {0} from the DNSSEC registry?".
   * 
   * @return translated "Are you sure you want to disable the certificate {0} from the DNSSEC registry?"
   */
  @DefaultMessage("Are you sure you want to disable the certificate {0} from the DNSSEC registry?")
  @Key("deviceCertificateDisableConfirmation")
  String deviceCertificateDisableConfirmation(String arg0);

  /**
   * Translated "Are you sure you want to enable the certificate {0} from the DNSSEC registry?".
   * 
   * @return translated "Are you sure you want to enable the certificate {0} from the DNSSEC registry?"
   */
  @DefaultMessage("Are you sure you want to enable the certificate {0} from the DNSSEC registry?")
  @Key("deviceCertificateEnableConfirmation")
  String deviceCertificateEnableConfirmation(String arg0);

  /**
   * Translated "Are you sure you want to refresh the information related to the certificate {0} ?".
   * 
   * @return translated "Are you sure you want to refresh the information related to the certificate {0} ?"
   */
  @DefaultMessage("Are you sure you want to refresh the information related to the certificate {0} ?")
  @Key("deviceCertificateRefreshConfirmation")
  String deviceCertificateRefreshConfirmation(String arg0);

  /**
   * Translated "Update".
   * 
   * @return translated "Update"
   */
  @DefaultMessage("Update")
  @Key("deviceCertificateTabUpdateButton")
  String deviceCertificateTabUpdateButton();

  /**
   * Translated "Are you sure you want to apply the new configuration to service {0}? During the configuration update, the device will disconnect and reconnect. If a timeout is encountered during the reload of the device configuration, please refresh it manually.".
   * 
   * @return translated "Are you sure you want to apply the new configuration to service {0}? During the configuration update, the device will disconnect and reconnect. If a timeout is encountered during the reload of the device configuration, please refresh it manually."
   */
  @DefaultMessage("Are you sure you want to apply the new configuration to service {0}? During the configuration update, the device will disconnect and reconnect. If a timeout is encountered during the reload of the device configuration, please refresh it manually.")
  @Key("deviceCloudConfigConfirmation")
  String deviceCloudConfigConfirmation(String arg0);

  /**
   * Translated "Command".
   * 
   * @return translated "Command"
   */
  @DefaultMessage("Command")
  @Key("deviceCommand")
  String deviceCommand();

  /**
   * Translated "There was a problem with device communication. You have entered an invalid/incomplete command, rebooted/powered down the device or the permissions have changed. Please refresh the console.".
   * 
   * @return translated "There was a problem with device communication. You have entered an invalid/incomplete command, rebooted/powered down the device or the permissions have changed. Please refresh the console."
   */
  @DefaultMessage("There was a problem with device communication. You have entered an invalid/incomplete command, rebooted/powered down the device or the permissions have changed. Please refresh the console.")
  @Key("deviceCommandCommunicationError")
  String deviceCommandCommunicationError();

  /**
   * Translated "Execute".
   * 
   * @return translated "Execute"
   */
  @DefaultMessage("Execute")
  @Key("deviceCommandExecute")
  String deviceCommandExecute();

  /**
   * Translated "Enter a valid command for execution.".
   * 
   * @return translated "Enter a valid command for execution."
   */
  @DefaultMessage("Enter a valid command for execution.")
  @Key("deviceCommandExecuteTooltip")
  String deviceCommandExecuteTooltip();

  /**
   * Translated "Executing Command...".
   * 
   * @return translated "Executing Command..."
   */
  @DefaultMessage("Executing Command...")
  @Key("deviceCommandExecuting")
  String deviceCommandExecuting();

  /**
   * Translated "The entered command can not be executed. Please check the command and password and try again.".
   * 
   * @return translated "The entered command can not be executed. Please check the command and password and try again."
   */
  @DefaultMessage("The entered command can not be executed. Please check the command and password and try again.")
  @Key("deviceCommandExecutionErrorMessage")
  String deviceCommandExecutionErrorMessage();

  /**
   * Translated "File".
   * 
   * @return translated "File"
   */
  @DefaultMessage("File")
  @Key("deviceCommandFile")
  String deviceCommandFile();

  /**
   * Translated "Upload a file with list of commands that need to be executed.".
   * 
   * @return translated "Upload a file with list of commands that need to be executed."
   */
  @DefaultMessage("Upload a file with list of commands that need to be executed.")
  @Key("deviceCommandFileTooltip")
  String deviceCommandFileTooltip();

  /**
   * Translated "The limit for this field is 1024 characters. Longer commands should be put in .sh files, zipped, uploaded and executed using the file field.".
   * 
   * @return translated "The limit for this field is 1024 characters. Longer commands should be put in .sh files, zipped, uploaded and executed using the file field."
   */
  @DefaultMessage("The limit for this field is 1024 characters. Longer commands should be put in .sh files, zipped, uploaded and executed using the file field.")
  @Key("deviceCommandMaxLengthErrorMessage")
  String deviceCommandMaxLengthErrorMessage();

  /**
   * Translated "No Output".
   * 
   * @return translated "No Output"
   */
  @DefaultMessage("No Output")
  @Key("deviceCommandNoOutput")
  String deviceCommandNoOutput();

  /**
   * Translated "Device Service Password".
   * 
   * @return translated "Device Service Password"
   */
  @DefaultMessage("Device Service Password")
  @Key("deviceCommandPassword")
  String deviceCommandPassword();

  /**
   * Translated "This is the password set in the device command service configuration. If not installed please leave this field blank.".
   * 
   * @return translated "This is the password set in the device command service configuration. If not installed please leave this field blank."
   */
  @DefaultMessage("This is the password set in the device command service configuration. If not installed please leave this field blank.")
  @Key("deviceCommandPasswordTooltip")
  String deviceCommandPasswordTooltip();

  /**
   * Translated "Services".
   * 
   * @return translated "Services"
   */
  @DefaultMessage("Services")
  @Key("deviceConfigComponents")
  String deviceConfigComponents();

  /**
   * Translated "Are you sure you want to apply the new configuration to the selected asset?".
   * 
   * @return translated "Are you sure you want to apply the new configuration to the selected asset?"
   */
  @DefaultMessage("Are you sure you want to apply the new configuration to the selected asset?")
  @Key("deviceConfigConfirmation")
  String deviceConfigConfirmation();

  /**
   * Translated "There are unsaved changes. Do you want to discard them and continue?".
   * 
   * @return translated "There are unsaved changes. Do you want to discard them and continue?"
   */
  @DefaultMessage("There are unsaved changes. Do you want to discard them and continue?")
  @Key("deviceConfigDirty")
  String deviceConfigDirty();

  /**
   * Translated "One or more fields contain invalid values. Please correct them and try again. ".
   * 
   * @return translated "One or more fields contain invalid values. Please correct them and try again. "
   */
  @DefaultMessage("One or more fields contain invalid values. Please correct them and try again. ")
  @Key("deviceConfigError")
  String deviceConfigError();

  /**
   * Translated "Snapshots".
   * 
   * @return translated "Snapshots"
   */
  @DefaultMessage("Snapshots")
  @Key("deviceConfigSnapshots")
  String deviceConfigSnapshots();

  /**
   * Translated "Selected device not connected. Please refresh device list.".
   * 
   * @return translated "Selected device not connected. Please refresh device list."
   */
  @DefaultMessage("Selected device not connected. Please refresh device list.")
  @Key("deviceConnectionError")
  String deviceConnectionError();

  /**
   * Translated "Device successfully created.".
   * 
   * @return translated "Device successfully created."
   */
  @DefaultMessage("Device successfully created.")
  @Key("deviceCreationSuccess")
  String deviceCreationSuccess();

  /**
   * Translated "Are you sure you want to delete device {0} and its historical events?".
   * 
   * @return translated "Are you sure you want to delete device {0} and its historical events?"
   */
  @DefaultMessage("Are you sure you want to delete device {0} and its historical events?")
  @Key("deviceDeleteConfirmation")
  String deviceDeleteConfirmation(String arg0);

  /**
   * Translated "Action Type".
   * 
   * @return translated "Action Type"
   */
  @DefaultMessage("Action Type")
  @Key("deviceEventActionType")
  String deviceEventActionType();

  /**
   * Translated "Event Message".
   * 
   * @return translated "Event Message"
   */
  @DefaultMessage("Event Message")
  @Key("deviceEventMessage")
  String deviceEventMessage();

  /**
   * Translated "Detailed message for {0} event received on {1}:".
   * 
   * @return translated "Detailed message for {0} event received on {1}:"
   */
  @DefaultMessage("Detailed message for {0} event received on {1}:")
  @Key("deviceEventMessageDialogHeaderMessage")
  String deviceEventMessageDialogHeaderMessage(String arg0,  String arg1);

  /**
   * Translated "Response Code".
   * 
   * @return translated "Response Code"
   */
  @DefaultMessage("Response Code")
  @Key("deviceEventResponseCode")
  String deviceEventResponseCode();

  /**
   * Translated "No Events Received".
   * 
   * @return translated "No Events Received"
   */
  @DefaultMessage("No Events Received")
  @Key("deviceEventTableNoResult")
  String deviceEventTableNoResult();

  /**
   * Translated "Event Received On".
   * 
   * @return translated "Event Received On"
   */
  @DefaultMessage("Event Received On")
  @Key("deviceEventTime")
  String deviceEventTime();

  /**
   * Translated "Event Type".
   * 
   * @return translated "Event Type"
   */
  @DefaultMessage("Event Type")
  @Key("deviceEventType")
  String deviceEventType();

  /**
   * Translated "Applications:".
   * 
   * @return translated "Applications:"
   */
  @DefaultMessage("Applications:")
  @Key("deviceFilteringPanelApplications")
  String deviceFilteringPanelApplications();

  /**
   * Translated "Certificate:".
   * 
   * @return translated "Certificate:"
   */
  @DefaultMessage("Certificate:")
  @Key("deviceFilteringPanelCertificateId")
  String deviceFilteringPanelCertificateId();

  /**
   * Translated "Certificate Status:".
   * 
   * @return translated "Certificate Status:"
   */
  @DefaultMessage("Certificate Status:")
  @Key("deviceFilteringPanelCertificateStatus")
  String deviceFilteringPanelCertificateStatus();

  /**
   * Translated "Client ID:".
   * 
   * @return translated "Client ID:"
   */
  @DefaultMessage("Client ID:")
  @Key("deviceFilteringPanelClientId")
  String deviceFilteringPanelClientId();

  /**
   * Translated "Device Connection Status:".
   * 
   * @return translated "Device Connection Status:"
   */
  @DefaultMessage("Device Connection Status:")
  @Key("deviceFilteringPanelConnectionStatus")
  String deviceFilteringPanelConnectionStatus();

  /**
   * Translated "Select A Device Connection Status...".
   * 
   * @return translated "Select A Device Connection Status..."
   */
  @DefaultMessage("Select A Device Connection Status...")
  @Key("deviceFilteringPanelConnectionStatusEmptyText")
  String deviceFilteringPanelConnectionStatusEmptyText();

  /**
   * Translated "Custom Attributes".
   * 
   * @return translated "Custom Attributes"
   */
  @DefaultMessage("Custom Attributes")
  @Key("deviceFilteringPanelCustomAttribute")
  String deviceFilteringPanelCustomAttribute();

  /**
   * Translated "Custom Attribute 1:".
   * 
   * @return translated "Custom Attribute 1:"
   */
  @DefaultMessage("Custom Attribute 1:")
  @Key("deviceFilteringPanelCustomAttribute1")
  String deviceFilteringPanelCustomAttribute1();

  /**
   * Translated "Custom Attribute 2:".
   * 
   * @return translated "Custom Attribute 2:"
   */
  @DefaultMessage("Custom Attribute 2:")
  @Key("deviceFilteringPanelCustomAttribute2")
  String deviceFilteringPanelCustomAttribute2();

  /**
   * Translated "Display Name:".
   * 
   * @return translated "Display Name:"
   */
  @DefaultMessage("Display Name:")
  @Key("deviceFilteringPanelDisplayName")
  String deviceFilteringPanelDisplayName();

  /**
   * Translated "IoT Framework Version:".
   * 
   * @return translated "IoT Framework Version:"
   */
  @DefaultMessage("IoT Framework Version:")
  @Key("deviceFilteringPanelESFVersion")
  String deviceFilteringPanelESFVersion();

  /**
   * Translated "Group".
   * 
   * @return translated "Group"
   */
  @DefaultMessage("Group")
  @Key("deviceFilteringPanelGroup")
  String deviceFilteringPanelGroup();

  /**
   * Translated "Select An Access Group".
   * 
   * @return translated "Select An Access Group"
   */
  @DefaultMessage("Select An Access Group")
  @Key("deviceFilteringPanelGroupEmptyText")
  String deviceFilteringPanelGroupEmptyText();

  /**
   * Translated "Error while fetching groups!".
   * 
   * @return translated "Error while fetching groups!"
   */
  @DefaultMessage("Error while fetching groups!")
  @Key("deviceFilteringPanelGroupsError")
  String deviceFilteringPanelGroupsError();

  /**
   * Translated "Device Filter".
   * 
   * @return translated "Device Filter"
   */
  @DefaultMessage("Device Filter")
  @Key("deviceFilteringPanelHeading")
  String deviceFilteringPanelHeading();

  /**
   * Translated "Loading...".
   * 
   * @return translated "Loading..."
   */
  @DefaultMessage("Loading...")
  @Key("deviceFilteringPanelLoading")
  String deviceFilteringPanelLoading();

  /**
   * Translated "Serial Number:".
   * 
   * @return translated "Serial Number:"
   */
  @DefaultMessage("Serial Number:")
  @Key("deviceFilteringPanelSerialNumber")
  String deviceFilteringPanelSerialNumber();

  /**
   * Translated "Device Status:".
   * 
   * @return translated "Device Status:"
   */
  @DefaultMessage("Device Status:")
  @Key("deviceFilteringPanelStatus")
  String deviceFilteringPanelStatus();

  /**
   * Translated "Any".
   * 
   * @return translated "Any"
   */
  @DefaultMessage("Any")
  @Key("deviceFilteringPanelStatusAny")
  String deviceFilteringPanelStatusAny();

  /**
   * Translated "Connected".
   * 
   * @return translated "Connected"
   */
  @DefaultMessage("Connected")
  @Key("deviceFilteringPanelStatusConnected")
  String deviceFilteringPanelStatusConnected();

  /**
   * Translated "Disconnected".
   * 
   * @return translated "Disconnected"
   */
  @DefaultMessage("Disconnected")
  @Key("deviceFilteringPanelStatusDisconnected")
  String deviceFilteringPanelStatusDisconnected();

  /**
   * Translated "Select A Device Status".
   * 
   * @return translated "Select A Device Status"
   */
  @DefaultMessage("Select A Device Status")
  @Key("deviceFilteringPanelStatusEmptyText")
  String deviceFilteringPanelStatusEmptyText();

  /**
   * Translated "Missing".
   * 
   * @return translated "Missing"
   */
  @DefaultMessage("Missing")
  @Key("deviceFilteringPanelStatusMissing")
  String deviceFilteringPanelStatusMissing();

  /**
   * Translated "Tag".
   * 
   * @return translated "Tag"
   */
  @DefaultMessage("Tag")
  @Key("deviceFilteringPanelTag")
  String deviceFilteringPanelTag();

  /**
   * Translated "Select a tag...".
   * 
   * @return translated "Select a tag..."
   */
  @DefaultMessage("Select a tag...")
  @Key("deviceFilteringPanelTagEmptyText")
  String deviceFilteringPanelTagEmptyText();

  /**
   * Translated "Error while fetching tags!".
   * 
   * @return translated "Error while fetching tags!"
   */
  @DefaultMessage("Error while fetching tags!")
  @Key("deviceFilteringPanelTagsError")
  String deviceFilteringPanelTagsError();

  /**
   * Translated "Device creation failed: {0}".
   * 
   * @return translated "Device creation failed: {0}"
   */
  @DefaultMessage("Device creation failed: {0}")
  @Key("deviceFormAddError")
  String deviceFormAddError(String arg0);

  /**
   * Translated "Add New Tag".
   * 
   * @return translated "Add New Tag"
   */
  @DefaultMessage("Add New Tag")
  @Key("deviceFormAddTag")
  String deviceFormAddTag();

  /**
   * Translated "Allow Binding to New User".
   * 
   * @return translated "Allow Binding to New User"
   */
  @DefaultMessage("Allow Binding to New User")
  @Key("deviceFormAllowCredentialsChange")
  String deviceFormAllowCredentialsChange();

  /**
   * Translated "Allow a device with Device-bound credentials tight strategy to change its credentials on the next login. The new credentials used must follow the rules of the Device-bound device credentials strategy.  ".
   * 
   * @return translated "Allow a device with Device-bound credentials tight strategy to change its credentials on the next login. The new credentials used must follow the rules of the Device-bound device credentials strategy.  "
   */
  @DefaultMessage("Allow a device with Device-bound credentials tight strategy to change its credentials on the next login. The new credentials used must follow the rules of the Device-bound device credentials strategy.  ")
  @Key("deviceFormAllowCredentialsChangeTooltip")
  String deviceFormAllowCredentialsChangeTooltip();

  /**
   * Translated "Cancel".
   * 
   * @return translated "Cancel"
   */
  @DefaultMessage("Cancel")
  @Key("deviceFormCancelButton")
  String deviceFormCancelButton();

  /**
   * Translated "Client ID".
   * 
   * @return translated "Client ID"
   */
  @DefaultMessage("Client ID")
  @Key("deviceFormClientID")
  String deviceFormClientID();

  /**
   * Translated "Device’s unique Client ID.".
   * 
   * @return translated "Device’s unique Client ID."
   */
  @DefaultMessage("Device’s unique Client ID.")
  @Key("deviceFormClientIDEditDialogTooltip")
  String deviceFormClientIDEditDialogTooltip();

  /**
   * Translated "Client ID must be at least 1 character long and can contain alphanumeric characters combined with dash and/or underscore.".
   * 
   * @return translated "Client ID must be at least 1 character long and can contain alphanumeric characters combined with dash and/or underscore."
   */
  @DefaultMessage("Client ID must be at least 1 character long and can contain alphanumeric characters combined with dash and/or underscore.")
  @Key("deviceFormClientIDTooltip")
  String deviceFormClientIDTooltip();

  /**
   * Translated "Custom attribute #1".
   * 
   * @return translated "Custom attribute #1"
   */
  @DefaultMessage("Custom attribute #1")
  @Key("deviceFormCustomAttribute1")
  String deviceFormCustomAttribute1();

  /**
   * Translated "Custom attribute #2".
   * 
   * @return translated "Custom attribute #2"
   */
  @DefaultMessage("Custom attribute #2")
  @Key("deviceFormCustomAttribute2")
  String deviceFormCustomAttribute2();

  /**
   * Translated "Custom attribute #3".
   * 
   * @return translated "Custom attribute #3"
   */
  @DefaultMessage("Custom attribute #3")
  @Key("deviceFormCustomAttribute3")
  String deviceFormCustomAttribute3();

  /**
   * Translated "Custom attribute #4".
   * 
   * @return translated "Custom attribute #4"
   */
  @DefaultMessage("Custom attribute #4")
  @Key("deviceFormCustomAttribute4")
  String deviceFormCustomAttribute4();

  /**
   * Translated "Custom attribute #5".
   * 
   * @return translated "Custom attribute #5"
   */
  @DefaultMessage("Custom attribute #5")
  @Key("deviceFormCustomAttribute5")
  String deviceFormCustomAttribute5();

  /**
   * Translated "Enter a custom attribute specific for this device. This is used for simplified search of specific devices.".
   * 
   * @return translated "Enter a custom attribute specific for this device. This is used for simplified search of specific devices."
   */
  @DefaultMessage("Enter a custom attribute specific for this device. This is used for simplified search of specific devices.")
  @Key("deviceFormCustomAttributesTooltip")
  String deviceFormCustomAttributesTooltip();

  /**
   * Translated "Device User".
   * 
   * @return translated "Device User"
   */
  @DefaultMessage("Device User")
  @Key("deviceFormDeviceUser")
  String deviceFormDeviceUser();

  /**
   * Translated "The user that the device is using. If the device is in Device-bound credentials tight strategy the device MUST use the new user credentials set for this device on the next connect.".
   * 
   * @return translated "The user that the device is using. If the device is in Device-bound credentials tight strategy the device MUST use the new user credentials set for this device on the next connect."
   */
  @DefaultMessage("The user that the device is using. If the device is in Device-bound credentials tight strategy the device MUST use the new user credentials set for this device on the next connect.")
  @Key("deviceFormDeviceUserTooltip")
  String deviceFormDeviceUserTooltip();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultMessage("Display Name")
  @Key("deviceFormDisplayName")
  String deviceFormDisplayName();

  /**
   * Translated "Enter a display name for more complete profile of the device.".
   * 
   * @return translated "Enter a display name for more complete profile of the device."
   */
  @DefaultMessage("Enter a display name for more complete profile of the device.")
  @Key("deviceFormDisplayNameTooltip")
  String deviceFormDisplayNameTooltip();

  /**
   * Translated "Device edit failed: {0}".
   * 
   * @return translated "Device edit failed: {0}"
   */
  @DefaultMessage("Device edit failed: {0}")
  @Key("deviceFormEditError")
  String deviceFormEditError(String arg0);

  /**
   * Translated "Custom Attributes".
   * 
   * @return translated "Custom Attributes"
   */
  @DefaultMessage("Custom Attributes")
  @Key("deviceFormFieldsetCustomAttributes")
  String deviceFormFieldsetCustomAttributes();

  /**
   * Translated "General Info".
   * 
   * @return translated "General Info"
   */
  @DefaultMessage("General Info")
  @Key("deviceFormFieldsetGeneralInfo")
  String deviceFormFieldsetGeneralInfo();

  /**
   * Translated "Device Connection Options".
   * 
   * @return translated "Device Connection Options"
   */
  @DefaultMessage("Device Connection Options")
  @Key("deviceFormFieldsetSecurityOptions")
  String deviceFormFieldsetSecurityOptions();

  /**
   * Translated "Tags".
   * 
   * @return translated "Tags"
   */
  @DefaultMessage("Tags")
  @Key("deviceFormFieldsetTags")
  String deviceFormFieldsetTags();

  /**
   * Translated "Access Group".
   * 
   * @return translated "Access Group"
   */
  @DefaultMessage("Access Group")
  @Key("deviceFormGroup")
  String deviceFormGroup();

  /**
   * Translated "Select an access group in which you want the device to be part of.".
   * 
   * @return translated "Select an access group in which you want the device to be part of."
   */
  @DefaultMessage("Select an access group in which you want the device to be part of.")
  @Key("deviceFormGroupTooltip")
  String deviceFormGroupTooltip();

  /**
   * Translated "Edit Device: {0}".
   * 
   * @return translated "Edit Device: {0}"
   */
  @DefaultMessage("Edit Device: {0}")
  @Key("deviceFormHeadingEdit")
  String deviceFormHeadingEdit(String arg0);

  /**
   * Translated "New Device".
   * 
   * @return translated "New Device"
   */
  @DefaultMessage("New Device")
  @Key("deviceFormHeadingNew")
  String deviceFormHeadingNew();

  /**
   * Translated "More custom attributes".
   * 
   * @return translated "More custom attributes"
   */
  @DefaultMessage("More custom attributes")
  @Key("deviceFormMoreCustomAttributes")
  String deviceFormMoreCustomAttributes();

  /**
   * Translated "No Group".
   * 
   * @return translated "No Group"
   */
  @DefaultMessage("No Group")
  @Key("deviceFormNoGroup")
  String deviceFormNoGroup();

  /**
   * Translated "Device Credential Strategy".
   * 
   * @return translated "Device Credential Strategy"
   */
  @DefaultMessage("Device Credential Strategy")
  @Key("deviceFormProvisionedCredentialsTight")
  String deviceFormProvisionedCredentialsTight();

  /**
   * Translated "The credentials tight strategy assigned for device. <br>- Device-bound means that the device can only use only one set of credentials and cannot chenage them. <br>- Unbound means that the device is not restricted on the credential usage in any way.<br>- Account Default means that the device will inherit the strategy from the account service plan. <br>All strategies requires that credentials on login must be valid.".
   * 
   * @return translated "The credentials tight strategy assigned for device. <br>- Device-bound means that the device can only use only one set of credentials and cannot chenage them. <br>- Unbound means that the device is not restricted on the credential usage in any way.<br>- Account Default means that the device will inherit the strategy from the account service plan. <br>All strategies requires that credentials on login must be valid."
   */
  @DefaultMessage("The credentials tight strategy assigned for device. <br>- Device-bound means that the device can only use only one set of credentials and cannot chenage them. <br>- Unbound means that the device is not restricted on the credential usage in any way.<br>- Account Default means that the device will inherit the strategy from the account service plan. <br>All strategies requires that credentials on login must be valid.")
  @Key("deviceFormProvisionedCredentialsTightTooltip")
  String deviceFormProvisionedCredentialsTightTooltip();

  /**
   * Translated "Device Status".
   * 
   * @return translated "Device Status"
   */
  @DefaultMessage("Device Status")
  @Key("deviceFormStatus")
  String deviceFormStatus();

  /**
   * Translated "Select if the device should be enabled or disabled.".
   * 
   * @return translated "Select if the device should be enabled or disabled."
   */
  @DefaultMessage("Select if the device should be enabled or disabled.")
  @Key("deviceFormStatusTooltip")
  String deviceFormStatusTooltip();

  /**
   * Translated "Submit".
   * 
   * @return translated "Submit"
   */
  @DefaultMessage("Submit")
  @Key("deviceFormSubmitButton")
  String deviceFormSubmitButton();

  /**
   * Translated "Assigned By".
   * 
   * @return translated "Assigned By"
   */
  @DefaultMessage("Assigned By")
  @Key("deviceFormTagGridCreatedBy")
  String deviceFormTagGridCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("deviceFormTagGridCreatedOn")
  String deviceFormTagGridCreatedOn();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("deviceFormTagGridName")
  String deviceFormTagGridName();

  /**
   * Translated "Select a tag from the list to be applied to the device.".
   * 
   * @return translated "Select a tag from the list to be applied to the device."
   */
  @DefaultMessage("Select a tag from the list to be applied to the device.")
  @Key("deviceFormTagTooltip")
  String deviceFormTagTooltip();

  /**
   * Translated "History".
   * 
   * @return translated "History"
   */
  @DefaultMessage("History")
  @Key("deviceInstallTabHistory")
  String deviceInstallTabHistory();

  /**
   * Translated "Log for management operation".
   * 
   * @return translated "Log for management operation"
   */
  @DefaultMessage("Log for management operation")
  @Key("deviceInstallTabHistoryDialogLogHeader")
  String deviceInstallTabHistoryDialogLogHeader();

  /**
   * Translated "No management operations found.".
   * 
   * @return translated "No management operations found."
   */
  @DefaultMessage("No management operations found.")
  @Key("deviceInstallTabHistoryTableEmpty")
  String deviceInstallTabHistoryTableEmpty();

  /**
   * Translated "EndedOn".
   * 
   * @return translated "EndedOn"
   */
  @DefaultMessage("EndedOn")
  @Key("deviceInstallTabHistoryTableEndedOn")
  String deviceInstallTabHistoryTableEndedOn();

  /**
   * Translated "In progress...".
   * 
   * @return translated "In progress..."
   */
  @DefaultMessage("In progress...")
  @Key("deviceInstallTabHistoryTableEndedOnInProgress")
  String deviceInstallTabHistoryTableEndedOnInProgress();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("deviceInstallTabHistoryTableId")
  String deviceInstallTabHistoryTableId();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("deviceInstallTabHistoryTableName")
  String deviceInstallTabHistoryTableName();

  /**
   * Translated "Operation Type".
   * 
   * @return translated "Operation Type"
   */
  @DefaultMessage("Operation Type")
  @Key("deviceInstallTabHistoryTableResource")
  String deviceInstallTabHistoryTableResource();

  /**
   * Translated "StartedOn".
   * 
   * @return translated "StartedOn"
   */
  @DefaultMessage("StartedOn")
  @Key("deviceInstallTabHistoryTableStartedOn")
  String deviceInstallTabHistoryTableStartedOn();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("deviceInstallTabHistoryTableStatus")
  String deviceInstallTabHistoryTableStatus();

  /**
   * Translated "COMPLETED".
   * 
   * @return translated "COMPLETED"
   */
  @DefaultMessage("COMPLETED")
  @Key("deviceInstallTabHistoryTableStatusCompleted")
  String deviceInstallTabHistoryTableStatusCompleted();

  /**
   * Translated "FAILED".
   * 
   * @return translated "FAILED"
   */
  @DefaultMessage("FAILED")
  @Key("deviceInstallTabHistoryTableStatusFailed")
  String deviceInstallTabHistoryTableStatusFailed();

  /**
   * Translated "RUNNING".
   * 
   * @return translated "RUNNING"
   */
  @DefaultMessage("RUNNING")
  @Key("deviceInstallTabHistoryTableStatusRunning")
  String deviceInstallTabHistoryTableStatusRunning();

  /**
   * Translated "STALE".
   * 
   * @return translated "STALE"
   */
  @DefaultMessage("STALE")
  @Key("deviceInstallTabHistoryTableStatusStale")
  String deviceInstallTabHistoryTableStatusStale();

  /**
   * Translated "URI".
   * 
   * @return translated "URI"
   */
  @DefaultMessage("URI")
  @Key("deviceInstallTabHistoryTableURI")
  String deviceInstallTabHistoryTableURI();

  /**
   * Translated "Version".
   * 
   * @return translated "Version"
   */
  @DefaultMessage("Version")
  @Key("deviceInstallTabHistoryTableVersion")
  String deviceInstallTabHistoryTableVersion();

  /**
   * Translated "In Progress".
   * 
   * @return translated "In Progress"
   */
  @DefaultMessage("In Progress")
  @Key("deviceInstallTabInProgress")
  String deviceInstallTabInProgress();

  /**
   * Translated "Dp Name".
   * 
   * @return translated "Dp Name"
   */
  @DefaultMessage("Dp Name")
  @Key("deviceInstallTabInProgressTableDpName")
  String deviceInstallTabInProgressTableDpName();

  /**
   * Translated "No installations running on the selected device.".
   * 
   * @return translated "No installations running on the selected device."
   */
  @DefaultMessage("No installations running on the selected device.")
  @Key("deviceInstallTabInProgressTableEmpty")
  String deviceInstallTabInProgressTableEmpty();

  /**
   * Translated "Last Update On".
   * 
   * @return translated "Last Update On"
   */
  @DefaultMessage("Last Update On")
  @Key("deviceInstallTabInProgressTableLastUpdateOn")
  String deviceInstallTabInProgressTableLastUpdateOn();

  /**
   * Translated "Operation".
   * 
   * @return translated "Operation"
   */
  @DefaultMessage("Operation")
  @Key("deviceInstallTabInProgressTableOperation")
  String deviceInstallTabInProgressTableOperation();

  /**
   * Translated "Operation Id".
   * 
   * @return translated "Operation Id"
   */
  @DefaultMessage("Operation Id")
  @Key("deviceInstallTabInProgressTableOperationId")
  String deviceInstallTabInProgressTableOperationId();

  /**
   * Translated "Install".
   * 
   * @return translated "Install"
   */
  @DefaultMessage("Install")
  @Key("deviceInstallTabInProgressTableOperationInstall")
  String deviceInstallTabInProgressTableOperationInstall();

  /**
   * Translated "Uninstall".
   * 
   * @return translated "Uninstall"
   */
  @DefaultMessage("Uninstall")
  @Key("deviceInstallTabInProgressTableOperationUninstall")
  String deviceInstallTabInProgressTableOperationUninstall();

  /**
   * Translated "Unknow".
   * 
   * @return translated "Unknow"
   */
  @DefaultMessage("Unknow")
  @Key("deviceInstallTabInProgressTableOperationUnknow")
  String deviceInstallTabInProgressTableOperationUnknow();

  /**
   * Translated "Progress [%]".
   * 
   * @return translated "Progress [%]"
   */
  @DefaultMessage("Progress [%]")
  @Key("deviceInstallTabInProgressTableProgressPercentage")
  String deviceInstallTabInProgressTableProgressPercentage();

  /**
   * Translated "Size".
   * 
   * @return translated "Size"
   */
  @DefaultMessage("Size")
  @Key("deviceInstallTabInProgressTableSize")
  String deviceInstallTabInProgressTableSize();

  /**
   * Translated "Installed".
   * 
   * @return translated "Installed"
   */
  @DefaultMessage("Installed")
  @Key("deviceInstallTabInstalled")
  String deviceInstallTabInstalled();

  /**
   * Translated "No authentication certificate installed for the selected device ".
   * 
   * @return translated "No authentication certificate installed for the selected device "
   */
  @DefaultMessage("No authentication certificate installed for the selected device ")
  @Key("deviceNoAuthenticationCertificate")
  String deviceNoAuthenticationCertificate();

  /**
   * Translated "No certificate installed. It s possible to proced with the Update button to install one.".
   * 
   * @return translated "No certificate installed. It s possible to proced with the Update button to install one."
   */
  @DefaultMessage("No certificate installed. It s possible to proced with the Update button to install one.")
  @Key("deviceNoCertificateInstalledProcedWithUpdate")
  String deviceNoCertificateInstalledProcedWithUpdate();

  /**
   * Translated "One or more selected devices cannot support this action.".
   * 
   * @return translated "One or more selected devices cannot support this action."
   */
  @DefaultMessage("One or more selected devices cannot support this action.")
  @Key("deviceNoCompatibleActionOnSelectedDevices")
  String deviceNoCompatibleActionOnSelectedDevices();

  /**
   * Translated "No Components Available".
   * 
   * @return translated "No Components Available"
   */
  @DefaultMessage("No Components Available")
  @Key("deviceNoComponents")
  String deviceNoComponents();

  /**
   * Translated "The selected Device is not online or it does not support remote configuration.".
   * 
   * @return translated "The selected Device is not online or it does not support remote configuration."
   */
  @DefaultMessage("The selected Device is not online or it does not support remote configuration.")
  @Key("deviceNoConfigSupported")
  String deviceNoConfigSupported();

  /**
   * Translated "No Device Selected".
   * 
   * @return translated "No Device Selected"
   */
  @DefaultMessage("No Device Selected")
  @Key("deviceNoDeviceSelected")
  String deviceNoDeviceSelected();

  /**
   * Translated "No device selected or it is offline.".
   * 
   * @return translated "No device selected or it is offline."
   */
  @DefaultMessage("No device selected or it is offline.")
  @Key("deviceNoDeviceSelectedOrOffline")
  String deviceNoDeviceSelectedOrOffline();

  /**
   * Translated "No Packages Installed".
   * 
   * @return translated "No Packages Installed"
   */
  @DefaultMessage("No Packages Installed")
  @Key("deviceNoPackagesInstalled")
  String deviceNoPackagesInstalled();

  /**
   * Translated "No SIM Card Available".
   * 
   * @return translated "No SIM Card Available"
   */
  @DefaultMessage("No SIM Card Available")
  @Key("deviceNoSimCardSelected")
  String deviceNoSimCardSelected();

  /**
   * Translated "The selected Device is offline.".
   * 
   * @return translated "The selected Device is offline."
   */
  @DefaultMessage("The selected Device is offline.")
  @Key("deviceOffline")
  String deviceOffline();

  /**
   * Translated "Enter a package name if you are installing the package in two steps (first download and then install).".
   * 
   * @return translated "Enter a package name if you are installing the package in two steps (first download and then install)."
   */
  @DefaultMessage("Enter a package name if you are installing the package in two steps (first download and then install).")
  @Key("devicePackageNameTooltip")
  String devicePackageNameTooltip();

  /**
   * Translated "Select the delay between package installation and device reboot.".
   * 
   * @return translated "Select the delay between package installation and device reboot."
   */
  @DefaultMessage("Select the delay between package installation and device reboot.")
  @Key("devicePackageRebootDelayTooltip")
  String devicePackageRebootDelayTooltip();

  /**
   * Translated "Select if you want to reboot the device after package installation.".
   * 
   * @return translated "Select if you want to reboot the device after package installation."
   */
  @DefaultMessage("Select if you want to reboot the device after package installation.")
  @Key("devicePackageRebootTooltip")
  String devicePackageRebootTooltip();

  /**
   * Translated "Enter a package version if you are installing the package in two steps (first download and then install).".
   * 
   * @return translated "Enter a package version if you are installing the package in two steps (first download and then install)."
   */
  @DefaultMessage("Enter a package version if you are installing the package in two steps (first download and then install).")
  @Key("devicePackageVersionTooltip")
  String devicePackageVersionTooltip();

  /**
   * Translated "No Packages Installed".
   * 
   * @return translated "No Packages Installed"
   */
  @DefaultMessage("No Packages Installed")
  @Key("devicePackagesNone")
  String devicePackagesNone();

  /**
   * Translated "Enter a package URL address from which the package should be installed.".
   * 
   * @return translated "Enter a package URL address from which the package should be installed."
   */
  @DefaultMessage("Enter a package URL address from which the package should be installed.")
  @Key("devicePackagesUrlTooltip")
  String devicePackagesUrlTooltip();

  /**
   * Translated "Accept-Encoding".
   * 
   * @return translated "Accept-Encoding"
   */
  @DefaultMessage("Accept-Encoding")
  @Key("deviceProfileFormAcceptEncoding")
  String deviceProfileFormAcceptEncoding();

  /**
   * Translated "Account ID".
   * 
   * @return translated "Account ID"
   */
  @DefaultMessage("Account ID")
  @Key("deviceProfileFormAccountId")
  String deviceProfileFormAccountId();

  /**
   * Translated "Address".
   * 
   * @return translated "Address"
   */
  @DefaultMessage("Address")
  @Key("deviceProfileFormAddress")
  String deviceProfileFormAddress();

  /**
   * Translated "Altitude".
   * 
   * @return translated "Altitude"
   */
  @DefaultMessage("Altitude")
  @Key("deviceProfileFormAltitude")
  String deviceProfileFormAltitude();

  /**
   * Translated "Application Identifiers".
   * 
   * @return translated "Application Identifiers"
   */
  @DefaultMessage("Application Identifiers")
  @Key("deviceProfileFormApplicationIdentifiers")
  String deviceProfileFormApplicationIdentifiers();

  /**
   * Translated "Applications Information".
   * 
   * @return translated "Applications Information"
   */
  @DefaultMessage("Applications Information")
  @Key("deviceProfileFormApplications")
  String deviceProfileFormApplications();

  /**
   * Translated "BIOS Version".
   * 
   * @return translated "BIOS Version"
   */
  @DefaultMessage("BIOS Version")
  @Key("deviceProfileFormBiosVersion")
  String deviceProfileFormBiosVersion();

  /**
   * Translated "Client ID".
   * 
   * @return translated "Client ID"
   */
  @DefaultMessage("Client ID")
  @Key("deviceProfileFormClientId")
  String deviceProfileFormClientId();

  /**
   * Translated "Interface".
   * 
   * @return translated "Interface"
   */
  @DefaultMessage("Interface")
  @Key("deviceProfileFormConnectionInterface")
  String deviceProfileFormConnectionInterface();

  /**
   * Translated "IP Address".
   * 
   * @return translated "IP Address"
   */
  @DefaultMessage("IP Address")
  @Key("deviceProfileFormConnectionIp")
  String deviceProfileFormConnectionIp();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultMessage("Display Name")
  @Key("deviceProfileFormDisplayName")
  String deviceProfileFormDisplayName();

  /**
   * Translated "Firmware Version".
   * 
   * @return translated "Firmware Version"
   */
  @DefaultMessage("Firmware Version")
  @Key("deviceProfileFormFirmwareVersion")
  String deviceProfileFormFirmwareVersion();

  /**
   * Translated "GPS Information".
   * 
   * @return translated "GPS Information"
   */
  @DefaultMessage("GPS Information")
  @Key("deviceProfileFormGps")
  String deviceProfileFormGps();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("deviceProfileFormGwtDeviceStatus")
  String deviceProfileFormGwtDeviceStatus();

  /**
   * Translated "Hardware Information".
   * 
   * @return translated "Hardware Information"
   */
  @DefaultMessage("Hardware Information")
  @Key("deviceProfileFormHardware")
  String deviceProfileFormHardware();

  /**
   * Translated "Device Information".
   * 
   * @return translated "Device Information"
   */
  @DefaultMessage("Device Information")
  @Key("deviceProfileFormInformation")
  String deviceProfileFormInformation();

  /**
   * Translated "JVM Name".
   * 
   * @return translated "JVM Name"
   */
  @DefaultMessage("JVM Name")
  @Key("deviceProfileFormJvmName")
  String deviceProfileFormJvmName();

  /**
   * Translated "JVM Profile".
   * 
   * @return translated "JVM Profile"
   */
  @DefaultMessage("JVM Profile")
  @Key("deviceProfileFormJvmProfile")
  String deviceProfileFormJvmProfile();

  /**
   * Translated "JVM Version".
   * 
   * @return translated "JVM Version"
   */
  @DefaultMessage("JVM Version")
  @Key("deviceProfileFormJvmVersion")
  String deviceProfileFormJvmVersion();

  /**
   * Translated "Last Event Date".
   * 
   * @return translated "Last Event Date"
   */
  @DefaultMessage("Last Event Date")
  @Key("deviceProfileFormLastEventDate")
  String deviceProfileFormLastEventDate();

  /**
   * Translated "Last Event Message".
   * 
   * @return translated "Last Event Message"
   */
  @DefaultMessage("Last Event Message")
  @Key("deviceProfileFormLastEventMessage")
  String deviceProfileFormLastEventMessage();

  /**
   * Translated "Last Event Type".
   * 
   * @return translated "Last Event Type"
   */
  @DefaultMessage("Last Event Type")
  @Key("deviceProfileFormLastEventType")
  String deviceProfileFormLastEventType();

  /**
   * Translated "Latitude".
   * 
   * @return translated "Latitude"
   */
  @DefaultMessage("Latitude")
  @Key("deviceProfileFormLatitude")
  String deviceProfileFormLatitude();

  /**
   * Translated "Longitude".
   * 
   * @return translated "Longitude"
   */
  @DefaultMessage("Longitude")
  @Key("deviceProfileFormLongitude")
  String deviceProfileFormLongitude();

  /**
   * Translated "Model ID".
   * 
   * @return translated "Model ID"
   */
  @DefaultMessage("Model ID")
  @Key("deviceProfileFormModelId")
  String deviceProfileFormModelId();

  /**
   * Translated "Model Name".
   * 
   * @return translated "Model Name"
   */
  @DefaultMessage("Model Name")
  @Key("deviceProfileFormModelName")
  String deviceProfileFormModelName();

  /**
   * Translated "Available Processors".
   * 
   * @return translated "Available Processors"
   */
  @DefaultMessage("Available Processors")
  @Key("deviceProfileFormNbProc")
  String deviceProfileFormNbProc();

  /**
   * Translated "Network Information".
   * 
   * @return translated "Network Information"
   */
  @DefaultMessage("Network Information")
  @Key("deviceProfileFormNetwork")
  String deviceProfileFormNetwork();

  /**
   * Translated "Operating System".
   * 
   * @return translated "Operating System"
   */
  @DefaultMessage("Operating System")
  @Key("deviceProfileFormOs")
  String deviceProfileFormOs();

  /**
   * Translated "Operating System Version".
   * 
   * @return translated "Operating System Version"
   */
  @DefaultMessage("Operating System Version")
  @Key("deviceProfileFormOsVersion")
  String deviceProfileFormOsVersion();

  /**
   * Translated "Part Number".
   * 
   * @return translated "Part Number"
   */
  @DefaultMessage("Part Number")
  @Key("deviceProfileFormPartNumber")
  String deviceProfileFormPartNumber();

  /**
   * Translated "Serial Number".
   * 
   * @return translated "Serial Number"
   */
  @DefaultMessage("Serial Number")
  @Key("deviceProfileFormSerialNumber")
  String deviceProfileFormSerialNumber();

  /**
   * Translated "Software Information".
   * 
   * @return translated "Software Information"
   */
  @DefaultMessage("Software Information")
  @Key("deviceProfileFormSoftware")
  String deviceProfileFormSoftware();

  /**
   * Translated "Status Information".
   * 
   * @return translated "Status Information"
   */
  @DefaultMessage("Status Information")
  @Key("deviceProfileFormStatus")
  String deviceProfileFormStatus();

  /**
   * Translated "Total Memory".
   * 
   * @return translated "Total Memory"
   */
  @DefaultMessage("Total Memory")
  @Key("deviceProfileFormTotalMem")
  String deviceProfileFormTotalMem();

  /**
   * Translated "Uptime".
   * 
   * @return translated "Uptime"
   */
  @DefaultMessage("Uptime")
  @Key("deviceProfileFormUptime")
  String deviceProfileFormUptime();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("deviceSnapshotCreatedOn")
  String deviceSnapshotCreatedOn();

  /**
   * Translated "Select a snapshot file that should be uploaded and applied to the device.".
   * 
   * @return translated "Select a snapshot file that should be uploaded and applied to the device."
   */
  @DefaultMessage("Select a snapshot file that should be uploaded and applied to the device.")
  @Key("deviceSnapshotFileTooltip")
  String deviceSnapshotFileTooltip();

  /**
   * Translated "Snapshot ID".
   * 
   * @return translated "Snapshot ID"
   */
  @DefaultMessage("Snapshot ID")
  @Key("deviceSnapshotId")
  String deviceSnapshotId();

  /**
   * Translated "Are you sure you want to rollback to a previous configuration? During the rollback operation, the device will disconnect and reconnect. If a timeout is encountered during the reload of the device configuration, please refresh it manually. ".
   * 
   * @return translated "Are you sure you want to rollback to a previous configuration? During the rollback operation, the device will disconnect and reconnect. If a timeout is encountered during the reload of the device configuration, please refresh it manually. "
   */
  @DefaultMessage("Are you sure you want to rollback to a previous configuration? During the rollback operation, the device will disconnect and reconnect. If a timeout is encountered during the reload of the device configuration, please refresh it manually. ")
  @Key("deviceSnapshotRollbackConfirm")
  String deviceSnapshotRollbackConfirm();

  /**
   * Translated "No Snapshots Available".
   * 
   * @return translated "No Snapshots Available"
   */
  @DefaultMessage("No Snapshots Available")
  @Key("deviceSnapshotsNone")
  String deviceSnapshotsNone();

  /**
   * Translated "Are you sure you want to stop the bundle \"{0}\"? Stopping a bundle might have unexpected effects on the stability of the framework. If in doubt, select \"No\".".
   * 
   * @return translated "Are you sure you want to stop the bundle \"{0}\"? Stopping a bundle might have unexpected effects on the stability of the framework. If in doubt, select \"No\"."
   */
  @DefaultMessage("Are you sure you want to stop the bundle \"{0}\"? Stopping a bundle might have unexpected effects on the stability of the framework. If in doubt, select \"No\".")
  @Key("deviceStopBundle")
  String deviceStopBundle(String arg0);

  /**
   * Translated "Select a certificate type.....".
   * 
   * @return translated "Select a certificate type....."
   */
  @DefaultMessage("Select a certificate type.....")
  @Key("deviceTabCertificateType")
  String deviceTabCertificateType();

  /**
   * Translated "Dashboard".
   * 
   * @return translated "Dashboard"
   */
  @DefaultMessage("Dashboard")
  @Key("deviceTabDashboard")
  String deviceTabDashboard();

  /**
   * Translated "Delete".
   * 
   * @return translated "Delete"
   */
  @DefaultMessage("Delete")
  @Key("deviceTabDeleteCert")
  String deviceTabDeleteCert();

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("deviceTabDescription")
  String deviceTabDescription();

  /**
   * Translated "Disable".
   * 
   * @return translated "Disable"
   */
  @DefaultMessage("Disable")
  @Key("deviceTabDisable")
  String deviceTabDisable();

  /**
   * Translated "Enable".
   * 
   * @return translated "Enable"
   */
  @DefaultMessage("Enable")
  @Key("deviceTabEnable")
  String deviceTabEnable();

  /**
   * Translated "Update SIM GPS".
   * 
   * @return translated "Update SIM GPS"
   */
  @DefaultMessage("Update SIM GPS")
  @Key("deviceTabGpsUpdate")
  String deviceTabGpsUpdate();

  /**
   * Translated "Send Reboot SMS".
   * 
   * @return translated "Send Reboot SMS"
   */
  @DefaultMessage("Send Reboot SMS")
  @Key("deviceTabSendRebootSms")
  String deviceTabSendRebootSms();

  /**
   * Translated "Send Wakeup SMS".
   * 
   * @return translated "Send Wakeup SMS"
   */
  @DefaultMessage("Send Wakeup SMS")
  @Key("deviceTabSendWakeupSms")
  String deviceTabSendWakeupSms();

  /**
   * Translated "Refresh".
   * 
   * @return translated "Refresh"
   */
  @DefaultMessage("Refresh")
  @Key("deviceTabUpdateCertInformations")
  String deviceTabUpdateCertInformations();

  /**
   * Translated "Synchronize SIM".
   * 
   * @return translated "Synchronize SIM"
   */
  @DefaultMessage("Synchronize SIM")
  @Key("deviceTabUpdateSimInformations")
  String deviceTabUpdateSimInformations();

  /**
   * Translated "Applications".
   * 
   * @return translated "Applications"
   */
  @DefaultMessage("Applications")
  @Key("deviceTableApplications")
  String deviceTableApplications();

  /**
   * Translated "Bios Version".
   * 
   * @return translated "Bios Version"
   */
  @DefaultMessage("Bios Version")
  @Key("deviceTableBiosVersion")
  String deviceTableBiosVersion();

  /**
   * Translated "Cert.Status".
   * 
   * @return translated "Cert.Status"
   */
  @DefaultMessage("Cert.Status")
  @Key("deviceTableCertStatus")
  String deviceTableCertStatus();

  /**
   * Translated "Certificate ID".
   * 
   * @return translated "Certificate ID"
   */
  @DefaultMessage("Certificate ID")
  @Key("deviceTableCertificate")
  String deviceTableCertificate();

  /**
   * Translated "Device Management Communication is not signed".
   * 
   * @return translated "Device Management Communication is not signed"
   */
  @DefaultMessage("Device Management Communication is not signed")
  @Key("deviceTableCertificateDMTooltipStatusNotSigned")
  String deviceTableCertificateDMTooltipStatusNotSigned();

  /**
   * Translated "Device Management communication is signed but device certificate has been revoked and it must be updated.".
   * 
   * @return translated "Device Management communication is signed but device certificate has been revoked and it must be updated."
   */
  @DefaultMessage("Device Management communication is signed but device certificate has been revoked and it must be updated.")
  @Key("deviceTableCertificateDMTooltipStatusNotSignedRevoked")
  String deviceTableCertificateDMTooltipStatusNotSignedRevoked();

  /**
   * Translated "Device Management Communication is signed".
   * 
   * @return translated "Device Management Communication is signed"
   */
  @DefaultMessage("Device Management Communication is signed")
  @Key("deviceTableCertificateDMTooltipStatusSigned")
  String deviceTableCertificateDMTooltipStatusSigned();

  /**
   * Translated "Device Management communication is signed but device certificate must be updated.".
   * 
   * @return translated "Device Management communication is signed but device certificate must be updated."
   */
  @DefaultMessage("Device Management communication is signed but device certificate must be updated.")
  @Key("deviceTableCertificateDMTooltipStatusSignedNeedUpdate")
  String deviceTableCertificateDMTooltipStatusSignedNeedUpdate();

  /**
   * Translated "Device has not certificate installed".
   * 
   * @return translated "Device has not certificate installed"
   */
  @DefaultMessage("Device has not certificate installed")
  @Key("deviceTableCertificateTooltipStatusNoCert")
  String deviceTableCertificateTooltipStatusNoCert();

  /**
   * Translated "The certificate on this device needs to be updated".
   * 
   * @return translated "The certificate on this device needs to be updated"
   */
  @DefaultMessage("The certificate on this device needs to be updated")
  @Key("deviceTableCertificateTooltipStatusNoOk")
  String deviceTableCertificateTooltipStatusNoOk();

  /**
   * Translated "Device certificate correctly installed".
   * 
   * @return translated "Device certificate correctly installed"
   */
  @DefaultMessage("Device certificate correctly installed")
  @Key("deviceTableCertificateTooltipStatusOk")
  String deviceTableCertificateTooltipStatusOk();

  /**
   * Translated "Client ID".
   * 
   * @return translated "Client ID"
   */
  @DefaultMessage("Client ID")
  @Key("deviceTableClientID")
  String deviceTableClientID();

  /**
   * Translated "Custom Attribute 1".
   * 
   * @return translated "Custom Attribute 1"
   */
  @DefaultMessage("Custom Attribute 1")
  @Key("deviceTableCustomAttribute1")
  String deviceTableCustomAttribute1();

  /**
   * Translated "Custom Attribute 2".
   * 
   * @return translated "Custom Attribute 2"
   */
  @DefaultMessage("Custom Attribute 2")
  @Key("deviceTableCustomAttribute2")
  String deviceTableCustomAttribute2();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultMessage("Display Name")
  @Key("deviceTableDisplayName")
  String deviceTableDisplayName();

  /**
   * Translated "IoT Framework Version".
   * 
   * @return translated "IoT Framework Version"
   */
  @DefaultMessage("IoT Framework Version")
  @Key("deviceTableEsfKuraVersion")
  String deviceTableEsfKuraVersion();

  /**
   * Translated "Firmware Version".
   * 
   * @return translated "Firmware Version"
   */
  @DefaultMessage("Firmware Version")
  @Key("deviceTableFirmwareVersion")
  String deviceTableFirmwareVersion();

  /**
   * Translated "ICCID".
   * 
   * @return translated "ICCID"
   */
  @DefaultMessage("ICCID")
  @Key("deviceTableIccid")
  String deviceTableIccid();

  /**
   * Translated "IMEI".
   * 
   * @return translated "IMEI"
   */
  @DefaultMessage("IMEI")
  @Key("deviceTableImei")
  String deviceTableImei();

  /**
   * Translated "IMSI".
   * 
   * @return translated "IMSI"
   */
  @DefaultMessage("IMSI")
  @Key("deviceTableImsi")
  String deviceTableImsi();

  /**
   * Translated "IP Address".
   * 
   * @return translated "IP Address"
   */
  @DefaultMessage("IP Address")
  @Key("deviceTableIpAddress")
  String deviceTableIpAddress();

  /**
   * Translated "Jvm Version".
   * 
   * @return translated "Jvm Version"
   */
  @DefaultMessage("Jvm Version")
  @Key("deviceTableJvmVersion")
  String deviceTableJvmVersion();

  /**
   * Translated "Last Event Type".
   * 
   * @return translated "Last Event Type"
   */
  @DefaultMessage("Last Event Type")
  @Key("deviceTableLastEventType")
  String deviceTableLastEventType();

  /**
   * Translated "Last Event On".
   * 
   * @return translated "Last Event On"
   */
  @DefaultMessage("Last Event On")
  @Key("deviceTableLastReportedDate")
  String deviceTableLastReportedDate();

  /**
   * Translated "Model ID".
   * 
   * @return translated "Model ID"
   */
  @DefaultMessage("Model ID")
  @Key("deviceTableModelId")
  String deviceTableModelId();

  /**
   * Translated "No Devices".
   * 
   * @return translated "No Devices"
   */
  @DefaultMessage("No Devices")
  @Key("deviceTableNoDevices")
  String deviceTableNoDevices();

  /**
   * Translated "Os Version".
   * 
   * @return translated "Os Version"
   */
  @DefaultMessage("Os Version")
  @Key("deviceTableOsVersion")
  String deviceTableOsVersion();

  /**
   * Translated "OSGi Version".
   * 
   * @return translated "OSGi Version"
   */
  @DefaultMessage("OSGi Version")
  @Key("deviceTableOsgiVersion")
  String deviceTableOsgiVersion();

  /**
   * Translated "Remote IP".
   * 
   * @return translated "Remote IP"
   */
  @DefaultMessage("Remote IP")
  @Key("deviceTableRemoteIpAddress")
  String deviceTableRemoteIpAddress();

  /**
   * Translated "Serial Number".
   * 
   * @return translated "Serial Number"
   */
  @DefaultMessage("Serial Number")
  @Key("deviceTableSerialNumber")
  String deviceTableSerialNumber();

  /**
   * Translated "Connection Status".
   * 
   * @return translated "Connection Status"
   */
  @DefaultMessage("Connection Status")
  @Key("deviceTableStatus")
  String deviceTableStatus();

  /**
   * Translated "Reboot after uninstall".
   * 
   * @return translated "Reboot after uninstall"
   */
  @DefaultMessage("Reboot after uninstall")
  @Key("deviceUnistallAsyncUninstallReboot")
  String deviceUnistallAsyncUninstallReboot();

  /**
   * Translated "Reboot delay [s]".
   * 
   * @return translated "Reboot delay [s]"
   */
  @DefaultMessage("Reboot delay [s]")
  @Key("deviceUnistallAsyncUninstallRebootDelay")
  String deviceUnistallAsyncUninstallRebootDelay();

  /**
   * Translated "Select the delay between package installation and device reboot.".
   * 
   * @return translated "Select the delay between package installation and device reboot."
   */
  @DefaultMessage("Select the delay between package installation and device reboot.")
  @Key("deviceUnistallAsyncUninstallRebootDelayTooltip")
  String deviceUnistallAsyncUninstallRebootDelayTooltip();

  /**
   * Translated "Select if you want to reboot the device after package installation.".
   * 
   * @return translated "Select if you want to reboot the device after package installation."
   */
  @DefaultMessage("Select if you want to reboot the device after package installation.")
  @Key("deviceUnistallAsyncUninstallRebootTooltip")
  String deviceUnistallAsyncUninstallRebootTooltip();

  /**
   * Translated "Device update succeeded.".
   * 
   * @return translated "Device update succeeded."
   */
  @DefaultMessage("Device update succeeded.")
  @Key("deviceUpdateSuccess")
  String deviceUpdateSuccess();

  /**
   * Translated "Device deleted successfully.".
   * 
   * @return translated "Device deleted successfully."
   */
  @DefaultMessage("Device deleted successfully.")
  @Key("dialogDeleteConfirmation")
  String dialogDeleteConfirmation();

  /**
   * Translated "Delete Device: {0}".
   * 
   * @return translated "Delete Device: {0}"
   */
  @DefaultMessage("Delete Device: {0}")
  @Key("dialogDeleteHeader")
  String dialogDeleteHeader(String arg0);

  /**
   * Translated "Are you sure you want to delete the selected device and its events?".
   * 
   * @return translated "Are you sure you want to delete the selected device and its events?"
   */
  @DefaultMessage("Are you sure you want to delete the selected device and its events?")
  @Key("dialogDeleteInfo")
  String dialogDeleteInfo();

  /**
   * Translated "Create a new device providing Client ID, Display Name, Access Group and Device Status.".
   * 
   * @return translated "Create a new device providing Client ID, Display Name, Access Group and Device Status."
   */
  @DefaultMessage("Create a new device providing Client ID, Display Name, Access Group and Device Status.")
  @Key("dialogDeviceAddInfoMessage")
  String dialogDeviceAddInfoMessage();

  /**
   * Translated "Error when deleting device: {0}".
   * 
   * @return translated "Error when deleting device: {0}"
   */
  @DefaultMessage("Error when deleting device: {0}")
  @Key("dialogDeviceDeleteError")
  String dialogDeviceDeleteError(String arg0);

  /**
   * Translated "Tag successfully applied.".
   * 
   * @return translated "Tag successfully applied."
   */
  @DefaultMessage("Tag successfully applied.")
  @Key("dialogDeviceTagAddConfirmation")
  String dialogDeviceTagAddConfirmation();

  /**
   * Translated "Error when applying tag: {0}".
   * 
   * @return translated "Error when applying tag: {0}"
   */
  @DefaultMessage("Error when applying tag: {0}")
  @Key("dialogDeviceTagAddError")
  String dialogDeviceTagAddError(String arg0);

  /**
   * Translated "Tag".
   * 
   * @return translated "Tag"
   */
  @DefaultMessage("Tag")
  @Key("dialogDeviceTagAddFieldTag")
  String dialogDeviceTagAddFieldTag();

  /**
   * Translated "Select A Tag".
   * 
   * @return translated "Select A Tag"
   */
  @DefaultMessage("Select A Tag")
  @Key("dialogDeviceTagAddFieldTagEmptyText")
  String dialogDeviceTagAddFieldTagEmptyText();

  /**
   * Translated "No Tags found...".
   * 
   * @return translated "No Tags found..."
   */
  @DefaultMessage("No Tags found...")
  @Key("dialogDeviceTagAddFieldTagEmptyTextNoTags")
  String dialogDeviceTagAddFieldTagEmptyTextNoTags();

  /**
   * Translated "Unable to load tag list: {0}".
   * 
   * @return translated "Unable to load tag list: {0}"
   */
  @DefaultMessage("Unable to load tag list: {0}")
  @Key("dialogDeviceTagAddFieldTagLoadingError")
  String dialogDeviceTagAddFieldTagLoadingError(String arg0);

  /**
   * Translated "Apply Tag".
   * 
   * @return translated "Apply Tag"
   */
  @DefaultMessage("Apply Tag")
  @Key("dialogDeviceTagAddHeader")
  String dialogDeviceTagAddHeader();

  /**
   * Translated "Apply a tag to the device.".
   * 
   * @return translated "Apply a tag to the device."
   */
  @DefaultMessage("Apply a tag to the device.")
  @Key("dialogDeviceTagAddInfo")
  String dialogDeviceTagAddInfo();

  /**
   * Translated "Tag successfully removed.".
   * 
   * @return translated "Tag successfully removed."
   */
  @DefaultMessage("Tag successfully removed.")
  @Key("dialogDeviceTagDeleteConfirmation")
  String dialogDeviceTagDeleteConfirmation();

  /**
   * Translated "Error while removing tag: {0}".
   * 
   * @return translated "Error while removing tag: {0}"
   */
  @DefaultMessage("Error while removing tag: {0}")
  @Key("dialogDeviceTagDeleteError")
  String dialogDeviceTagDeleteError(String arg0);

  /**
   * Translated "Remove Tag: {0}".
   * 
   * @return translated "Remove Tag: {0}"
   */
  @DefaultMessage("Remove Tag: {0}")
  @Key("dialogDeviceTagDeleteHeader")
  String dialogDeviceTagDeleteHeader(String arg0);

  /**
   * Translated "Are you sure you want to remove the selected tag?".
   * 
   * @return translated "Are you sure you want to remove the selected tag?"
   */
  @DefaultMessage("Are you sure you want to remove the selected tag?")
  @Key("dialogDeviceTagDeleteInfo")
  String dialogDeviceTagDeleteInfo();

  /**
   * Translated "Edit device''s data.".
   * 
   * @return translated "Edit device''s data."
   */
  @DefaultMessage("Edit device''s data.")
  @Key("dialogEditInfo")
  String dialogEditInfo();

  /**
   * Translated "Error loading device: {0}".
   * 
   * @return translated "Error loading device: {0}"
   */
  @DefaultMessage("Error loading device: {0}")
  @Key("dialogFormEditLoadFailed")
  String dialogFormEditLoadFailed(String arg0);

  /**
   * Translated "Error: Unable to update SIM card position data".
   * 
   * @return translated "Error: Unable to update SIM card position data"
   */
  @DefaultMessage("Error: Unable to update SIM card position data")
  @Key("gpsNotUpdated")
  String gpsNotUpdated();

  /**
   * Translated "SIM card position data updated".
   * 
   * @return translated "SIM card position data updated"
   */
  @DefaultMessage("SIM card position data updated")
  @Key("gpsUpdated")
  String gpsUpdated();

  /**
   * Translated "Devices".
   * 
   * @return translated "Devices"
   */
  @DefaultMessage("Devices")
  @Key("mainMenuDevices")
  String mainMenuDevices();

  /**
   * Translated "This device has no available assets.".
   * 
   * @return translated "This device has no available assets."
   */
  @DefaultMessage("This device has no available assets.")
  @Key("noAsset")
  String noAsset();

  /**
   * Translated "No SIM Card available for the selected Device".
   * 
   * @return translated "No SIM Card available for the selected Device"
   */
  @DefaultMessage("No SIM Card available for the selected Device")
  @Key("noSimCardAvailable")
  String noSimCardAvailable();

  /**
   * Translated "Install".
   * 
   * @return translated "Install"
   */
  @DefaultMessage("Install")
  @Key("packageInstallButton")
  String packageInstallButton();

  /**
   * Translated "Block Delay [ms]".
   * 
   * @return translated "Block Delay [ms]"
   */
  @DefaultMessage("Block Delay [ms]")
  @Key("packageInstallDpDialogAdvancedBlockDelay")
  String packageInstallDpDialogAdvancedBlockDelay();

  /**
   * Translated "The delay in millisecons between each block transfer from the URI.".
   * 
   * @return translated "The delay in millisecons between each block transfer from the URI."
   */
  @DefaultMessage("The delay in millisecons between each block transfer from the URI.")
  @Key("packageInstallDpDialogAdvancedBlockDelayTooltip")
  String packageInstallDpDialogAdvancedBlockDelayTooltip();

  /**
   * Translated "Block Size [B]".
   * 
   * @return translated "Block Size [B]"
   */
  @DefaultMessage("Block Size [B]")
  @Key("packageInstallDpDialogAdvancedBlockSize")
  String packageInstallDpDialogAdvancedBlockSize();

  /**
   * Translated "The size in Bytes of the blocks to transfer from the URI.".
   * 
   * @return translated "The size in Bytes of the blocks to transfer from the URI."
   */
  @DefaultMessage("The size in Bytes of the blocks to transfer from the URI.")
  @Key("packageInstallDpDialogAdvancedBlockSizeTooltip")
  String packageInstallDpDialogAdvancedBlockSizeTooltip();

  /**
   * Translated "Block Timeout [ms]".
   * 
   * @return translated "Block Timeout [ms]"
   */
  @DefaultMessage("Block Timeout [ms]")
  @Key("packageInstallDpDialogAdvancedBlockTimeout")
  String packageInstallDpDialogAdvancedBlockTimeout();

  /**
   * Translated "The timeout in milliseconds for transferring a block from the URI.".
   * 
   * @return translated "The timeout in milliseconds for transferring a block from the URI."
   */
  @DefaultMessage("The timeout in milliseconds for transferring a block from the URI.")
  @Key("packageInstallDpDialogAdvancedBlockTimeoutTooltip")
  String packageInstallDpDialogAdvancedBlockTimeoutTooltip();

  /**
   * Translated "Install Verifier URI".
   * 
   * @return translated "Install Verifier URI"
   */
  @DefaultMessage("Install Verifier URI")
  @Key("packageInstallDpDialogAdvancedInstallVerifierURI")
  String packageInstallDpDialogAdvancedInstallVerifierURI();

  /**
   * Translated "The URI for the executable shell script to verify the installing of the downloaded file.".
   * 
   * @return translated "The URI for the executable shell script to verify the installing of the downloaded file."
   */
  @DefaultMessage("The URI for the executable shell script to verify the installing of the downloaded file.")
  @Key("packageInstallDpDialogAdvancedInstallVerifierURITooltip")
  String packageInstallDpDialogAdvancedInstallVerifierURITooltip();

  /**
   * Translated "Notify Block Size [B]".
   * 
   * @return translated "Notify Block Size [B]"
   */
  @DefaultMessage("Notify Block Size [B]")
  @Key("packageInstallDpDialogAdvancedNotifyBlockSize")
  String packageInstallDpDialogAdvancedNotifyBlockSize();

  /**
   * Translated "The size in Bytes of the blocks to be transfer between notifications".
   * 
   * @return translated "The size in Bytes of the blocks to be transfer between notifications"
   */
  @DefaultMessage("The size in Bytes of the blocks to be transfer between notifications")
  @Key("packageInstallDpDialogAdvancedNotifyBlockSizeTooltip")
  String packageInstallDpDialogAdvancedNotifyBlockSizeTooltip();

  /**
   * Translated "Control advanced properties of the operation.".
   * 
   * @return translated "Control advanced properties of the operation."
   */
  @DefaultMessage("Control advanced properties of the operation.")
  @Key("packageInstallDpDialogAdvancedTabInfo")
  String packageInstallDpDialogAdvancedTabInfo();

  /**
   * Translated "Advanced Options".
   * 
   * @return translated "Advanced Options"
   */
  @DefaultMessage("Advanced Options")
  @Key("packageInstallDpDialogAdvancedTabTitle")
  String packageInstallDpDialogAdvancedTabTitle();

  /**
   * Translated "File Hash".
   * 
   * @return translated "File Hash"
   */
  @DefaultMessage("File Hash")
  @Key("packageInstallDpDialogFileHash")
  String packageInstallDpDialogFileHash();

  /**
   * Translated "The file hash to verify the downloaded file.<br/>It must be specifies as {@code {HASH_ALGORITHM}:{HASH_VALUE}}<br/>Example: MD5:46cbc7f212b94187cb6480fe9429a89c".
   * 
   * @return translated "The file hash to verify the downloaded file.<br/>It must be specifies as {@code {HASH_ALGORITHM}:{HASH_VALUE}}<br/>Example: MD5:46cbc7f212b94187cb6480fe9429a89c"
   */
  @DefaultMessage("The file hash to verify the downloaded file.<br/>It must be specifies as {@code {HASH_ALGORITHM}:{HASH_VALUE}}<br/>Example: MD5:46cbc7f212b94187cb6480fe9429a89c")
  @Key("packageInstallDpDialogFileHashTooltip")
  String packageInstallDpDialogFileHashTooltip();

  /**
   * Translated "File Type".
   * 
   * @return translated "File Type"
   */
  @DefaultMessage("File Type")
  @Key("packageInstallDpDialogFileType")
  String packageInstallDpDialogFileType();

  /**
   * Translated "The file type of the target file to download.".
   * 
   * @return translated "The file type of the target file to download."
   */
  @DefaultMessage("The file type of the target file to download.")
  @Key("packageInstallDpDialogFileTypeTooltip")
  String packageInstallDpDialogFileTypeTooltip();

  /**
   * Translated "Package Name".
   * 
   * @return translated "Package Name"
   */
  @DefaultMessage("Package Name")
  @Key("packageInstallDpDialogName")
  String packageInstallDpDialogName();

  /**
   * Translated "This is the first part of the name of the file that will be written on the device file system concatenated with the version. <br>Format: {packageName}-{packageVersion}".
   * 
   * @return translated "This is the first part of the name of the file that will be written on the device file system concatenated with the version. <br>Format: {packageName}-{packageVersion}"
   */
  @DefaultMessage("This is the first part of the name of the file that will be written on the device file system concatenated with the version. <br>Format: {packageName}-{packageVersion}")
  @Key("packageInstallDpDialogNameTooltip")
  String packageInstallDpDialogNameTooltip();

  /**
   * Translated "Reboot After Install".
   * 
   * @return translated "Reboot After Install"
   */
  @DefaultMessage("Reboot After Install")
  @Key("packageInstallDpDialogOperationReboot")
  String packageInstallDpDialogOperationReboot();

  /**
   * Translated "Reboot Delay [s]".
   * 
   * @return translated "Reboot Delay [s]"
   */
  @DefaultMessage("Reboot Delay [s]")
  @Key("packageInstallDpDialogOperationRebootDelay")
  String packageInstallDpDialogOperationRebootDelay();

  /**
   * Translated "The delay after which the device is rebooted when the operation has been completed.".
   * 
   * @return translated "The delay after which the device is rebooted when the operation has been completed."
   */
  @DefaultMessage("The delay after which the device is rebooted when the operation has been completed.")
  @Key("packageInstallDpDialogOperationRebootDelayTooltip")
  String packageInstallDpDialogOperationRebootDelayTooltip();

  /**
   * Translated "Whether or not reboot the device after the operation has been completed.".
   * 
   * @return translated "Whether or not reboot the device after the operation has been completed."
   */
  @DefaultMessage("Whether or not reboot the device after the operation has been completed.")
  @Key("packageInstallDpDialogOperationRebootTooltip")
  String packageInstallDpDialogOperationRebootTooltip();

  /**
   * Translated "Restart Download".
   * 
   * @return translated "Restart Download"
   */
  @DefaultMessage("Restart Download")
  @Key("packageInstallDpDialogOperationRestart")
  String packageInstallDpDialogOperationRestart();

  /**
   * Translated "Whether or not restart the download from the beginning.".
   * 
   * @return translated "Whether or not restart the download from the beginning."
   */
  @DefaultMessage("Whether or not restart the download from the beginning.")
  @Key("packageInstallDpDialogOperationRestartTooltip")
  String packageInstallDpDialogOperationRestartTooltip();

  /**
   * Translated "Control accessory properties of the operation.".
   * 
   * @return translated "Control accessory properties of the operation."
   */
  @DefaultMessage("Control accessory properties of the operation.")
  @Key("packageInstallDpDialogOperationTabInfo")
  String packageInstallDpDialogOperationTabInfo();

  /**
   * Translated "Operation Options".
   * 
   * @return translated "Operation Options"
   */
  @DefaultMessage("Operation Options")
  @Key("packageInstallDpDialogOperationTabTitle")
  String packageInstallDpDialogOperationTabTitle();

  /**
   * Translated "URI Password".
   * 
   * @return translated "URI Password"
   */
  @DefaultMessage("URI Password")
  @Key("packageInstallDpDialogPassword")
  String packageInstallDpDialogPassword();

  /**
   * Translated "The password to provide as a credential when accessing the URI.".
   * 
   * @return translated "The password to provide as a credential when accessing the URI."
   */
  @DefaultMessage("The password to provide as a credential when accessing the URI.")
  @Key("packageInstallDpDialogPasswordTooltip")
  String packageInstallDpDialogPasswordTooltip();

  /**
   * Translated "Specify the URL location of the package to be installed. The device will first download the package from the provided URL and then install it.<br>Make sure that the provided URL is accessible by the device.".
   * 
   * @return translated "Specify the URL location of the package to be installed. The device will first download the package from the provided URL and then install it.<br>Make sure that the provided URL is accessible by the device."
   */
  @DefaultMessage("Specify the URL location of the package to be installed. The device will first download the package from the provided URL and then install it.<br>Make sure that the provided URL is accessible by the device.")
  @Key("packageInstallDpDialogTabInfo")
  String packageInstallDpDialogTabInfo();

  /**
   * Translated "Package Location".
   * 
   * @return translated "Package Location"
   */
  @DefaultMessage("Package Location")
  @Key("packageInstallDpDialogTabTitle")
  String packageInstallDpDialogTabTitle();

  /**
   * Translated "Package URL".
   * 
   * @return translated "Package URL"
   */
  @DefaultMessage("Package URL")
  @Key("packageInstallDpDialogUri")
  String packageInstallDpDialogUri();

  /**
   * Translated "URI Username".
   * 
   * @return translated "URI Username"
   */
  @DefaultMessage("URI Username")
  @Key("packageInstallDpDialogUsername")
  String packageInstallDpDialogUsername();

  /**
   * Translated "The username to provide as a credential when accessing the URI.".
   * 
   * @return translated "The username to provide as a credential when accessing the URI."
   */
  @DefaultMessage("The username to provide as a credential when accessing the URI.")
  @Key("packageInstallDpDialogUsernameTooltip")
  String packageInstallDpDialogUsernameTooltip();

  /**
   * Translated "Package Version".
   * 
   * @return translated "Package Version"
   */
  @DefaultMessage("Package Version")
  @Key("packageInstallDpDialogVersion")
  String packageInstallDpDialogVersion();

  /**
   * Translated "This is the last part of the name of the file that will be written on the device file system concatenated with the version. <br>Format: {packageName}-{packageVersion}".
   * 
   * @return translated "This is the last part of the name of the file that will be written on the device file system concatenated with the version. <br>Format: {packageName}-{packageVersion}"
   */
  @DefaultMessage("This is the last part of the name of the file that will be written on the device file system concatenated with the version. <br>Format: {packageName}-{packageVersion}")
  @Key("packageInstallDpDialogVersionTooltip")
  String packageInstallDpDialogVersionTooltip();

  /**
   * Translated "Please check form informations.".
   * 
   * @return translated "Please check form informations."
   */
  @DefaultMessage("Please check form informations.")
  @Key("packageInstallError")
  String packageInstallError();

  /**
   * Translated "Delete".
   * 
   * @return translated "Delete"
   */
  @DefaultMessage("Delete")
  @Key("packageInstallInteractiveDeleteButton")
  String packageInstallInteractiveDeleteButton();

  /**
   * Translated "Operation deleted.".
   * 
   * @return translated "Operation deleted."
   */
  @DefaultMessage("Operation deleted.")
  @Key("packageInstallInteractiveDeleteConfirmation")
  String packageInstallInteractiveDeleteConfirmation();

  /**
   * Translated "Error while deleting the operation.<br> Cause: {0}.".
   * 
   * @return translated "Error while deleting the operation.<br> Cause: {0}."
   */
  @DefaultMessage("Error while deleting the operation.<br> Cause: {0}.")
  @Key("packageInstallInteractiveDeleteError")
  String packageInstallInteractiveDeleteError(String arg0);

  /**
   * Translated "Delete operation".
   * 
   * @return translated "Delete operation"
   */
  @DefaultMessage("Delete operation")
  @Key("packageInstallInteractiveDeleteHeading")
  String packageInstallInteractiveDeleteHeading();

  /**
   * Translated "Are you sure you want to delete {0} operation?".
   * 
   * @return translated "Are you sure you want to delete {0} operation?"
   */
  @DefaultMessage("Are you sure you want to delete {0} operation?")
  @Key("packageInstallInteractiveDeleteInfo")
  String packageInstallInteractiveDeleteInfo(String arg0);

  /**
   * Translated "Install New Package".
   * 
   * @return translated "Install New Package"
   */
  @DefaultMessage("Install New Package")
  @Key("packageInstallNewPackage")
  String packageInstallNewPackage();

  /**
   * Translated "Package install request has been sent to the device.".
   * 
   * @return translated "Package install request has been sent to the device."
   */
  @DefaultMessage("Package install request has been sent to the device.")
  @Key("packageInstallSuccess")
  String packageInstallSuccess();

  /**
   * Translated "Package uninstall task has been created and should start in a few seconds.".
   * 
   * @return translated "Package uninstall task has been created and should start in a few seconds."
   */
  @DefaultMessage("Package uninstall task has been created and should start in a few seconds.")
  @Key("packageUninstallAsyncSuccess")
  String packageUninstallAsyncSuccess();

  /**
   * Translated "Uninstall".
   * 
   * @return translated "Uninstall"
   */
  @DefaultMessage("Uninstall")
  @Key("packageUninstallButton")
  String packageUninstallButton();

  /**
   * Translated "Uninstall Package".
   * 
   * @return translated "Uninstall Package"
   */
  @DefaultMessage("Uninstall Package")
  @Key("packageUninstallPackage")
  String packageUninstallPackage();

  /**
   * Translated "Are you sure you want to uninstall the package \"<i>{0}</i>\"? Uninstalling a package might have unexpected effects on the stability of the framework.<br>If in doubt, cancel the operation.".
   * 
   * @return translated "Are you sure you want to uninstall the package \"<i>{0}</i>\"? Uninstalling a package might have unexpected effects on the stability of the framework.<br>If in doubt, cancel the operation."
   */
  @DefaultMessage("Are you sure you want to uninstall the package \"<i>{0}</i>\"? Uninstalling a package might have unexpected effects on the stability of the framework.<br>If in doubt, cancel the operation.")
  @Key("packageUninstallPackageInfo")
  String packageUninstallPackageInfo(String arg0);

  /**
   * Translated "Package has been succesfully unistalled from the device.".
   * 
   * @return translated "Package has been succesfully unistalled from the device."
   */
  @DefaultMessage("Package has been succesfully unistalled from the device.")
  @Key("packageUninstallSyncSuccess")
  String packageUninstallSyncSuccess();

  /**
   * Translated "Error: reboot SMS not sent".
   * 
   * @return translated "Error: reboot SMS not sent"
   */
  @DefaultMessage("Error: reboot SMS not sent")
  @Key("rebootMessageNotSent")
  String rebootMessageNotSent();

  /**
   * Translated "Reboot SMS sent".
   * 
   * @return translated "Reboot SMS sent"
   */
  @DefaultMessage("Reboot SMS sent")
  @Key("rebootMessageSent")
  String rebootMessageSent();

  /**
   * Translated "Bundles".
   * 
   * @return translated "Bundles"
   */
  @DefaultMessage("Bundles")
  @Key("tabBundles")
  String tabBundles();

  /**
   * Translated "Command".
   * 
   * @return translated "Command"
   */
  @DefaultMessage("Command")
  @Key("tabCommand")
  String tabCommand();

  /**
   * Translated "Configuration".
   * 
   * @return translated "Configuration"
   */
  @DefaultMessage("Configuration")
  @Key("tabConfiguration")
  String tabConfiguration();

  /**
   * Translated "Events".
   * 
   * @return translated "Events"
   */
  @DefaultMessage("Events")
  @Key("tabEvents")
  String tabEvents();

  /**
   * Translated "Packages".
   * 
   * @return translated "Packages"
   */
  @DefaultMessage("Packages")
  @Key("tabPackages")
  String tabPackages();

  /**
   * Translated "Apply".
   * 
   * @return translated "Apply"
   */
  @DefaultMessage("Apply")
  @Key("tabTagsAddButton")
  String tabTagsAddButton();

  /**
   * Translated "Remove".
   * 
   * @return translated "Remove"
   */
  @DefaultMessage("Remove")
  @Key("tabTagsDeleteButton")
  String tabTagsDeleteButton();

  /**
   * Translated "Tags".
   * 
   * @return translated "Tags"
   */
  @DefaultMessage("Tags")
  @Key("tabTagsTitle")
  String tabTagsTitle();

  /**
   * Translated "Topic".
   * 
   * @return translated "Topic"
   */
  @DefaultMessage("Topic")
  @Key("topic")
  String topic();

  /**
   * Translated "Values".
   * 
   * @return translated "Values"
   */
  @DefaultMessage("Values")
  @Key("valueTabItem")
  String valueTabItem();

  /**
   * Translated "Value".
   * 
   * @return translated "Value"
   */
  @DefaultMessage("Value")
  @Key("valueTabItemTitle")
  String valueTabItemTitle();

  /**
   * Translated "Error: wakeup SMS not sent".
   * 
   * @return translated "Error: wakeup SMS not sent"
   */
  @DefaultMessage("Error: wakeup SMS not sent")
  @Key("wakeUpMessageNotSent")
  String wakeUpMessageNotSent();

  /**
   * Translated "Wakeup SMS sent".
   * 
   * @return translated "Wakeup SMS sent"
   */
  @DefaultMessage("Wakeup SMS sent")
  @Key("wakeUpMessageSent")
  String wakeUpMessageSent();
}
