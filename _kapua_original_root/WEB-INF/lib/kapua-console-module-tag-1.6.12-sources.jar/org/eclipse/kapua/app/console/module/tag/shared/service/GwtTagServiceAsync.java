package org.eclipse.kapua.app.console.module.tag.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtTagServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.tag.shared.service.GwtTagService
     */
    void create( org.eclipse.kapua.app.console.module.tag.shared.model.GwtTagCreator gwtTagCreator, AsyncCallback<org.eclipse.kapua.app.console.module.tag.shared.model.GwtTag> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.tag.shared.service.GwtTagService
     */
    void update( org.eclipse.kapua.app.console.module.tag.shared.model.GwtTag gwtTag, AsyncCallback<org.eclipse.kapua.app.console.module.tag.shared.model.GwtTag> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.tag.shared.service.GwtTagService
     */
    void find( java.lang.String scopeShortId, java.lang.String roleShortId, AsyncCallback<org.eclipse.kapua.app.console.module.tag.shared.model.GwtTag> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.tag.shared.service.GwtTagService
     */
    void query( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.tag.shared.model.GwtTagQuery gwtTagQuery, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.tag.shared.model.GwtTag>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.tag.shared.service.GwtTagService
     */
    void delete( java.lang.String scopeId, java.lang.String tagId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.tag.shared.service.GwtTagService
     */
    void getTagDescription( java.lang.String scopeShortId, java.lang.String tagShortId, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.api.shared.model.GwtGroupedNVPair>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.tag.shared.service.GwtTagService
     */
    void findAll( java.lang.String scopeId, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.tag.shared.model.GwtTag>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.tag.shared.service.GwtTagService
     */
    void findByDeviceId( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, java.lang.String gwtScopeId, java.lang.String gwtDeviceId, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.tag.shared.model.GwtTag>> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtTagServiceAsync instance;

        public static final GwtTagServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtTagServiceAsync) GWT.create( GwtTagService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "tag" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
