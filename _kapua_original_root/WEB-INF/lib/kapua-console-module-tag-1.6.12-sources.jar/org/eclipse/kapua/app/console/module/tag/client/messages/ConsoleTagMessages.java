package org.eclipse.kapua.app.console.module.tag.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/tag/src/main/resources/org/eclipse/kapua/app/console/module/tag/client/messages/ConsoleTagMessages.properties'.
 */
public interface ConsoleTagMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "Tag successfully created.".
   * 
   * @return translated "Tag successfully created."
   */
  @DefaultMessage("Tag successfully created.")
  @Key("dialogAddConfirmation")
  String dialogAddConfirmation();

  /**
   * Translated "Tag creation failed: {0}".
   * 
   * @return translated "Tag creation failed: {0}"
   */
  @DefaultMessage("Tag creation failed: {0}")
  @Key("dialogAddError")
  String dialogAddError(String arg0);

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("dialogAddFieldName")
  String dialogAddFieldName();

  /**
   * Translated "The name of the new tag. It must be unique.".
   * 
   * @return translated "The name of the new tag. It must be unique."
   */
  @DefaultMessage("The name of the new tag. It must be unique.")
  @Key("dialogAddFieldNameTooltip")
  String dialogAddFieldNameTooltip();

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("dialogAddFieldTagDescription")
  String dialogAddFieldTagDescription();

  /**
   * Translated "Enter a tag description for detailed information about the tag.".
   * 
   * @return translated "Enter a tag description for detailed information about the tag."
   */
  @DefaultMessage("Enter a tag description for detailed information about the tag.")
  @Key("dialogAddFieldTagDescriptionTooltip")
  String dialogAddFieldTagDescriptionTooltip();

  /**
   * Translated "New Tag".
   * 
   * @return translated "New Tag"
   */
  @DefaultMessage("New Tag")
  @Key("dialogAddHeader")
  String dialogAddHeader();

  /**
   * Translated "Create a new tag providing a name and an optional description.".
   * 
   * @return translated "Create a new tag providing a name and an optional description."
   */
  @DefaultMessage("Create a new tag providing a name and an optional description.")
  @Key("dialogAddInfo")
  String dialogAddInfo();

  /**
   * Translated "Tag successfully deleted.".
   * 
   * @return translated "Tag successfully deleted."
   */
  @DefaultMessage("Tag successfully deleted.")
  @Key("dialogDeleteConfirmation")
  String dialogDeleteConfirmation();

  /**
   * Translated "Tag delete failed: {0}".
   * 
   * @return translated "Tag delete failed: {0}"
   */
  @DefaultMessage("Tag delete failed: {0}")
  @Key("dialogDeleteError")
  String dialogDeleteError(String arg0);

  /**
   * Translated "Delete Tag: {0}".
   * 
   * @return translated "Delete Tag: {0}"
   */
  @DefaultMessage("Delete Tag: {0}")
  @Key("dialogDeleteHeader")
  String dialogDeleteHeader(String arg0);

  /**
   * Translated "Are you sure you want to delete the selected tag?".
   * 
   * @return translated "Are you sure you want to delete the selected tag?"
   */
  @DefaultMessage("Are you sure you want to delete the selected tag?")
  @Key("dialogDeleteInfo")
  String dialogDeleteInfo();

  /**
   * Translated "Tag successfully updated.".
   * 
   * @return translated "Tag successfully updated."
   */
  @DefaultMessage("Tag successfully updated.")
  @Key("dialogEditConfirmation")
  String dialogEditConfirmation();

  /**
   * Translated "Tag edit failed: {0}".
   * 
   * @return translated "Tag edit failed: {0}"
   */
  @DefaultMessage("Tag edit failed: {0}")
  @Key("dialogEditError")
  String dialogEditError(String arg0);

  /**
   * Translated "Edit Tag: {0}".
   * 
   * @return translated "Edit Tag: {0}"
   */
  @DefaultMessage("Edit Tag: {0}")
  @Key("dialogEditHeader")
  String dialogEditHeader(String arg0);

  /**
   * Translated "Edit tag''s data.".
   * 
   * @return translated "Edit tag''s data."
   */
  @DefaultMessage("Edit tag''s data.")
  @Key("dialogEditInfo")
  String dialogEditInfo();

  /**
   * Translated "Cannot load tag: {0}".
   * 
   * @return translated "Cannot load tag: {0}"
   */
  @DefaultMessage("Cannot load tag: {0}")
  @Key("dialogEditLoadFailed")
  String dialogEditLoadFailed(String arg0);

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("filterFieldTagDescriptionLabel")
  String filterFieldTagDescriptionLabel();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("filterFieldTagNameLabel")
  String filterFieldTagNameLabel();

  /**
   * Translated "Tag Filter".
   * 
   * @return translated "Tag Filter"
   */
  @DefaultMessage("Tag Filter")
  @Key("filterHeader")
  String filterHeader();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultMessage("Created By")
  @Key("gridTagColumnHeaderCreatedBy")
  String gridTagColumnHeaderCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("gridTagColumnHeaderCreatedOn")
  String gridTagColumnHeaderCreatedOn();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridTagColumnHeaderId")
  String gridTagColumnHeaderId();

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("gridTagColumnHeaderTagDescription")
  String gridTagColumnHeaderTagDescription();

  /**
   * Translated "Tag Name".
   * 
   * @return translated "Tag Name"
   */
  @DefaultMessage("Tag Name")
  @Key("gridTagColumnHeaderTagName")
  String gridTagColumnHeaderTagName();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultMessage("Display Name")
  @Key("gridTagsSubjectColumnHeaderDisplayName")
  String gridTagsSubjectColumnHeaderDisplayName();

  /**
   * Translated "Tags".
   * 
   * @return translated "Tags"
   */
  @DefaultMessage("Tags")
  @Key("tags")
  String tags();

  /**
   * Translated "Client ID".
   * 
   * @return translated "Client ID"
   */
  @DefaultMessage("Client ID")
  @Key("tagsSubjectColumnHeaderClientId")
  String tagsSubjectColumnHeaderClientId();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("tagsSubjectColumnHeaderId")
  String tagsSubjectColumnHeaderId();

  /**
   * Translated "Assigned Devices".
   * 
   * @return translated "Assigned Devices"
   */
  @DefaultMessage("Assigned Devices")
  @Key("tagsTabSubjectGridTitle")
  String tagsTabSubjectGridTitle();
}
