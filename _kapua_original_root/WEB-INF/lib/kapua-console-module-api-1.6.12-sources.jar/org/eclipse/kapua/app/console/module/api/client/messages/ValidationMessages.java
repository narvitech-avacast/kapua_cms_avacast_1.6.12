package org.eclipse.kapua.app.console.module.api.client.messages;

/**
 * Interface to represent the constants contained in resource bundle:
 * 	'D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/api/src/main/resources/org/eclipse/kapua/app/console/module/api/client/messages/ValidationMessages.properties'.
 */
public interface ValidationMessages extends com.google.gwt.i18n.client.ConstantsWithLookup {
  
  /**
   * Translated "Operation not allowed on admin role.".
   * 
   * @return translated "Operation not allowed on admin role."
   */
  @DefaultStringValue("Operation not allowed on admin role.")
  @Key("ADMIN_ROLE_DELETED_ERROR")
  String ADMIN_ROLE_DELETED_ERROR();

  /**
   * Translated "Being Deleted".
   * 
   * @return translated "Being Deleted"
   */
  @DefaultStringValue("Being Deleted")
  @Key("BEING_DELETED")
  String BEING_DELETED();

  /**
   * Translated "Under Provisioning".
   * 
   * @return translated "Under Provisioning"
   */
  @DefaultStringValue("Under Provisioning")
  @Key("BEING_PROVISIONED")
  String BEING_PROVISIONED();

  /**
   * Translated "Cannot delete the last Administrator of an Account or remove its Administrator Role: {0}.".
   * 
   * @return translated "Cannot delete the last Administrator of an Account or remove its Administrator Role: {0}."
   */
  @DefaultStringValue("Cannot delete the last Administrator of an Account or remove its Administrator Role: {0}.")
  @Key("CANNOT_REMOVE_LAST_ADMIN")
  String CANNOT_REMOVE_LAST_ADMIN();

  /**
   * Translated "Completed".
   * 
   * @return translated "Completed"
   */
  @DefaultStringValue("Completed")
  @Key("COMPLETED")
  String COMPLETED();

  /**
   * Translated "There was an error. Error: {0}".
   * 
   * @return translated "There was an error. Error: {0}"
   */
  @DefaultStringValue("There was an error. Error: {0}")
  @Key("DEVICE_MANAGEMENT_ERROR")
  String DEVICE_MANAGEMENT_ERROR();

  /**
   * Translated "The device didn't understood the request. {0} - {1}".
   * 
   * @return translated "The device didn't understood the request. {0} - {1}"
   */
  @DefaultStringValue("The device didn't understood the request. {0} - {1}")
  @Key("DEVICE_MANAGEMENT_RESPONSE_BAD_REQUEST")
  String DEVICE_MANAGEMENT_RESPONSE_BAD_REQUEST();

  /**
   * Translated "The device has errored while processing the request. {0} - {1}".
   * 
   * @return translated "The device has errored while processing the request. {0} - {1}"
   */
  @DefaultStringValue("The device has errored while processing the request. {0} - {1}")
  @Key("DEVICE_MANAGEMENT_RESPONSE_INTERNAL_ERROR")
  String DEVICE_MANAGEMENT_RESPONSE_INTERNAL_ERROR();

  /**
   * Translated "The device didn't found the requested resource. {0} - {1}".
   * 
   * @return translated "The device didn't found the requested resource. {0} - {1}"
   */
  @DefaultStringValue("The device didn't found the requested resource. {0} - {1}")
  @Key("DEVICE_MANAGEMENT_RESPONSE_NOT_FOUND")
  String DEVICE_MANAGEMENT_RESPONSE_NOT_FOUND();

  /**
   * Translated "There was an error while sending the request. Error: {0}".
   * 
   * @return translated "There was an error while sending the request. Error: {0}"
   */
  @DefaultStringValue("There was an error while sending the request. Error: {0}")
  @Key("DEVICE_MANAGEMENT_SEND_ERROR")
  String DEVICE_MANAGEMENT_SEND_ERROR();

  /**
   * Translated "The request has exceeded the {0} timed out.".
   * 
   * @return translated "The request has exceeded the {0} timed out."
   */
  @DefaultStringValue("The request has exceeded the {0} timed out.")
  @Key("DEVICE_MANAGEMENT_TIMEOUT")
  String DEVICE_MANAGEMENT_TIMEOUT();

  /**
   * Translated "The device is not connected.".
   * 
   * @return translated "The device is not connected."
   */
  @DefaultStringValue("The device is not connected.")
  @Key("DEVICE_NOT_CONNECTED")
  String DEVICE_NOT_CONNECTED();

  /**
   * Translated "The selected devices were not found. Please refresh device list.".
   * 
   * @return translated "The selected devices were not found. Please refresh device list."
   */
  @DefaultStringValue("The selected devices were not found. Please refresh device list.")
  @Key("DEVICE_NOT_FOUND")
  String DEVICE_NOT_FOUND();

  /**
   * Translated "Device Timestamp (if available)".
   * 
   * @return translated "Device Timestamp (if available)"
   */
  @DefaultStringValue("Device Timestamp (if available)")
  @Key("DEVICE_TIMESTAMP")
  String DEVICE_TIMESTAMP();

  /**
   * Translated "Disabled".
   * 
   * @return translated "Disabled"
   */
  @DefaultStringValue("Disabled")
  @Key("DISABLED")
  String DISABLED();

  /**
   * Translated "Error: Another resource is currently downloading. Please wait a few moments so package finishes downloading and then try again.".
   * 
   * @return translated "Error: Another resource is currently downloading. Please wait a few moments so package finishes downloading and then try again."
   */
  @DefaultStringValue("Error: Another resource is currently downloading. Please wait a few moments so package finishes downloading and then try again.")
  @Key("DOWNLOAD_PACKAGE_EXCEPTION")
  String DOWNLOAD_PACKAGE_EXCEPTION();

  /**
   * Translated "An entity with the same external id already exists.".
   * 
   * @return translated "An entity with the same external id already exists."
   */
  @DefaultStringValue("An entity with the same external id already exists.")
  @Key("DUPLICATE_EXTERNAL_ID")
  String DUPLICATE_EXTERNAL_ID();

  /**
   * Translated "An entity with the same value for field already exists.".
   * 
   * @return translated "An entity with the same value for field already exists."
   */
  @DefaultStringValue("An entity with the same value for field already exists.")
  @Key("DUPLICATE_NAME")
  String DUPLICATE_NAME();

  /**
   * Translated "Enabled".
   * 
   * @return translated "Enabled"
   */
  @DefaultStringValue("Enabled")
  @Key("ENABLED")
  String ENABLED();

  /**
   * Translated "The start time cannot be later than the end time.".
   * 
   * @return translated "The start time cannot be later than the end time."
   */
  @DefaultStringValue("The start time cannot be later than the end time.")
  @Key("END_BEFORE_START_TIME_ERROR")
  String END_BEFORE_START_TIME_ERROR();

  /**
   * Translated "An entity with the same unique value already exists.".
   * 
   * @return translated "An entity with the same unique value already exists."
   */
  @DefaultStringValue("An entity with the same unique value already exists.")
  @Key("ENTITY_ALREADY_EXISTS")
  String ENTITY_ALREADY_EXISTS();

  /**
   * Translated "{0} already exists in another account.".
   * 
   * @return translated "{0} already exists in another account."
   */
  @DefaultStringValue("{0} already exists in another account.")
  @Key("ENTITY_ALREADY_EXIST_IN_ANOTHER_ACCOUNT")
  String ENTITY_ALREADY_EXIST_IN_ANOTHER_ACCOUNT();

  /**
   * Translated "The entity of type {0} with id/name {1} was not found.".
   * 
   * @return translated "The entity of type {0} with id/name {1} was not found."
   */
  @DefaultStringValue("The entity of type {0} with id/name {1} was not found.")
  @Key("ENTITY_NOT_FOUND")
  String ENTITY_NOT_FOUND();

  /**
   * Translated "Duplicate entry for fields:".
   * 
   * @return translated "Duplicate entry for fields:"
   */
  @DefaultStringValue("Duplicate entry for fields:")
  @Key("ENTITY_UNIQUENESS")
  String ENTITY_UNIQUENESS();

  /**
   * Translated "An entity with the same external id {0} already exists in another account.".
   * 
   * @return translated "An entity with the same external id {0} already exists in another account."
   */
  @DefaultStringValue("An entity with the same external id {0} already exists in another account.")
  @Key("EXTERNAL_ID_ALREADY_EXIST_IN_ANOTHER_ACCOUNT")
  String EXTERNAL_ID_ALREADY_EXIST_IN_ANOTHER_ACCOUNT();

  /**
   * Translated "The current subject is not authorized to perform this operation.".
   * 
   * @return translated "The current subject is not authorized to perform this operation."
   */
  @DefaultStringValue("The current subject is not authorized to perform this operation.")
  @Key("ILLEGAL_ACCESS")
  String ILLEGAL_ACCESS();

  /**
   * Translated "An illegal value was provided for the argument {0}.".
   * 
   * @return translated "An illegal value was provided for the argument {0}."
   */
  @DefaultStringValue("An illegal value was provided for the argument {0}.")
  @Key("ILLEGAL_ARGUMENT")
  String ILLEGAL_ARGUMENT();

  /**
   * Translated "An illegal null value was provided for the argument {0}.".
   * 
   * @return translated "An illegal null value was provided for the argument {0}."
   */
  @DefaultStringValue("An illegal null value was provided for the argument {0}.")
  @Key("ILLEGAL_NULL_ARGUMENT")
  String ILLEGAL_NULL_ARGUMENT();

  /**
   * Translated "{0}".
   * 
   * @return translated "{0}"
   */
  @DefaultStringValue("{0}")
  @Key("INTERNAL_ERROR")
  String INTERNAL_ERROR();

  /**
   * Translated "Rules can have a single From clause for KapuaMessageEvent or for a PatternStream".
   * 
   * @return translated "Rules can have a single From clause for KapuaMessageEvent or for a PatternStream"
   */
  @DefaultStringValue("Rules can have a single From clause for KapuaMessageEvent or for a PatternStream")
  @Key("INVALID_RULE_FROMCLAUSE")
  String INVALID_RULE_FROMCLAUSE();

  /**
   * Translated "{0}".
   * 
   * @return translated "{0}"
   */
  @DefaultStringValue("{0}")
  @Key("INVALID_RULE_QUERY")
  String INVALID_RULE_QUERY();

  /**
   * Translated "Invalid login credentials.".
   * 
   * @return translated "Invalid login credentials."
   */
  @DefaultStringValue("Invalid login credentials.")
  @Key("INVALID_USERNAME_PASSWORD")
  String INVALID_USERNAME_PASSWORD();

  /**
   * Translated "Attempts remaining before lock the user: {0}".
   * 
   * @return translated "Attempts remaining before lock the user: {0}"
   */
  @DefaultStringValue("Attempts remaining before lock the user: {0}")
  @Key("INVALID_USERNAME_PASSWORD_LOGIN_ATTEMPTS")
  String INVALID_USERNAME_PASSWORD_LOGIN_ATTEMPTS();

  /**
   * Translated "The user has been locked!".
   * 
   * @return translated "The user has been locked!"
   */
  @DefaultStringValue("The user has been locked!")
  @Key("INVALID_USERNAME_PASSWORD_USER_LOCKED")
  String INVALID_USERNAME_PASSWORD_USER_LOCKED();

  /**
   * Translated "In Progress".
   * 
   * @return translated "In Progress"
   */
  @DefaultStringValue("In Progress")
  @Key("IN_PROGRESS")
  String IN_PROGRESS();

  /**
   * Translated "Selected job could not be started. There is a problem with its parameters, it has already been started or it has not finished yet. Please check the configuration or try again later.".
   * 
   * @return translated "Selected job could not be started. There is a problem with its parameters, it has already been started or it has not finished yet. Please check the configuration or try again later."
   */
  @DefaultStringValue("Selected job could not be started. There is a problem with its parameters, it has already been started or it has not finished yet. Please check the configuration or try again later.")
  @Key("JOB_STARTING_ERROR")
  String JOB_STARTING_ERROR();

  /**
   * Translated "Selected job could not be stopped. No execution running found.".
   * 
   * @return translated "Selected job could not be stopped. No execution running found."
   */
  @DefaultStringValue("Selected job could not be stopped. No execution running found.")
  @Key("JOB_STOPPING_ERROR")
  String JOB_STOPPING_ERROR();

  /**
   * Translated "Locked".
   * 
   * @return translated "Locked"
   */
  @DefaultStringValue("Locked")
  @Key("LOCKED")
  String LOCKED();

  /**
   * Translated "User has been locked or password has expired. Contact your account administrator.".
   * 
   * @return translated "User has been locked or password has expired. Contact your account administrator."
   */
  @DefaultStringValue("User has been locked or password has expired. Contact your account administrator.")
  @Key("LOCKED_USER")
  String LOCKED_USER();

  /**
   * Translated "Max number of {0} reached. Please increase the number or set InfiniteChild{0} parameter to True.".
   * 
   * @return translated "Max number of {0} reached. Please increase the number or set InfiniteChild{0} parameter to True."
   */
  @DefaultStringValue("Max number of {0} reached. Please increase the number or set InfiniteChild{0} parameter to True.")
  @Key("MAX_NUMBER_OF_ITEMS_REACHED")
  String MAX_NUMBER_OF_ITEMS_REACHED();

  /**
   * Translated "None".
   * 
   * @return translated "None"
   */
  @DefaultStringValue("None")
  @Key("NONE")
  String NONE();

  /**
   * Translated "Operation not allowed on admin user. It cannot have an expiration date nor be deleted. Also, a normal user cannot use the reserved admin name.".
   * 
   * @return translated "Operation not allowed on admin user. It cannot have an expiration date nor be deleted. Also, a normal user cannot use the reserved admin name."
   */
  @DefaultStringValue("Operation not allowed on admin user. It cannot have an expiration date nor be deleted. Also, a normal user cannot use the reserved admin name.")
  @Key("OPERATION_NOT_ALLOWED_ON_ADMIN_USER")
  String OPERATION_NOT_ALLOWED_ON_ADMIN_USER();

  /**
   * Translated "The maximum number of rules allowed for this account has been reached.".
   * 
   * @return translated "The maximum number of rules allowed for this account has been reached."
   */
  @DefaultStringValue("The maximum number of rules allowed for this account has been reached.")
  @Key("OVER_RULE_LIMIT")
  String OVER_RULE_LIMIT();

  /**
   * Translated "Illegal characters in Package URL path. Please check the parameters and try again.".
   * 
   * @return translated "Illegal characters in Package URL path. Please check the parameters and try again."
   */
  @DefaultStringValue("Illegal characters in Package URL path. Please check the parameters and try again.")
  @Key("PACKAGE_URI_SYNTAX_ERROR")
  String PACKAGE_URI_SYNTAX_ERROR();

  /**
   * Translated "Maximum number of items has been exceeded".
   * 
   * @return translated "Maximum number of items has been exceeded"
   */
  @DefaultStringValue("Maximum number of items has been exceeded")
  @Key("PARENT_LIMIT_EXCEEDED_IN_CONFIG")
  String PARENT_LIMIT_EXCEEDED_IN_CONFIG();

  /**
   * Translated "Password cannot be changed.".
   * 
   * @return translated "Password cannot be changed."
   */
  @DefaultStringValue("Password cannot be changed.")
  @Key("PASSWORD_CANNOT_BE_CHANGED")
  String PASSWORD_CANNOT_BE_CHANGED();

  /**
   * Translated "Operation not allowed on this specific permission.".
   * 
   * @return translated "Operation not allowed on this specific permission."
   */
  @DefaultStringValue("Operation not allowed on this specific permission.")
  @Key("PERMISSION_DELETE_NOT_ALLOWED")
  String PERMISSION_DELETE_NOT_ALLOWED();

  /**
   * Translated "The requested method is not valid.".
   * 
   * @return translated "The requested method is not valid."
   */
  @DefaultStringValue("The requested method is not valid.")
  @Key("REQUEST_BAD_METHOD")
  String REQUEST_BAD_METHOD();

  /**
   * Translated "Full MFA credentials are required.".
   * 
   * @return translated "Full MFA credentials are required."
   */
  @DefaultStringValue("Full MFA credentials are required.")
  @Key("REQUIRE_MFA_CODE")
  String REQUIRE_MFA_CODE();

  /**
   * Translated "There should only be one scheduling parameter - either Retry interval or Cron schedule.".
   * 
   * @return translated "There should only be one scheduling parameter - either Retry interval or Cron schedule."
   */
  @DefaultStringValue("There should only be one scheduling parameter - either Retry interval or Cron schedule.")
  @Key("RETRY_AND_CRON_BOTH_SELECTED")
  String RETRY_AND_CRON_BOTH_SELECTED();

  /**
   * Translated "Start and end time cannot be at the same point in time. Please change the parameters.".
   * 
   * @return translated "Start and end time cannot be at the same point in time. Please change the parameters."
   */
  @DefaultStringValue("Start and end time cannot be at the same point in time. Please change the parameters.")
  @Key("SAME_START_AND_DATE")
  String SAME_START_AND_DATE();

  /**
   * Translated "An entity with the same value for field already exists here or in another job.".
   * 
   * @return translated "An entity with the same value for field already exists here or in another job."
   */
  @DefaultStringValue("An entity with the same value for field already exists here or in another job.")
  @Key("SCHEDULE_DUPLICATE_NAME")
  String SCHEDULE_DUPLICATE_NAME();

  /**
   * Translated "Value too small, please remove some items or increase value.".
   * 
   * @return translated "Value too small, please remove some items or increase value."
   */
  @DefaultStringValue("Value too small, please remove some items or increase value.")
  @Key("SELF_LIMIT_EXCEEDED_IN_CONFIG")
  String SELF_LIMIT_EXCEEDED_IN_CONFIG();

  /**
   * Translated "Server Timestamp".
   * 
   * @return translated "Server Timestamp"
   */
  @DefaultStringValue("Server Timestamp")
  @Key("SERVER_TIMESTAMP")
  String SERVER_TIMESTAMP();

  /**
   * Translated "The requested service is not available for configuration. {0}".
   * 
   * @return translated "The requested service is not available for configuration. {0}"
   */
  @DefaultStringValue("The requested service is not available for configuration. {0}")
  @Key("SERVICE_UNAVAILABLE")
  String SERVICE_UNAVAILABLE();

  /**
   * Translated "User does not have permission to perform this action. Required permission: {0}.".
   * 
   * @return translated "User does not have permission to perform this action. Required permission: {0}."
   */
  @DefaultStringValue("User does not have permission to perform this action. Required permission: {0}.")
  @Key("SUBJECT_UNAUTHORIZED")
  String SUBJECT_UNAUTHORIZED();

  /**
   * Translated "Timestamp".
   * 
   * @return translated "Timestamp"
   */
  @DefaultStringValue("Timestamp")
  @Key("TIMESTAMP")
  String TIMESTAMP();

  /**
   * Translated "There is problem with Job scheduling. Either Job does not exist, there is a problem with schedule's trigger or an internal scheduler error occurred.".
   * 
   * @return translated "There is problem with Job scheduling. Either Job does not exist, there is a problem with schedule's trigger or an internal scheduler error occurred."
   */
  @DefaultStringValue("There is problem with Job scheduling. Either Job does not exist, there is a problem with schedule's trigger or an internal scheduler error occurred.")
  @Key("TRIGGER_NEVER_FIRE")
  String TRIGGER_NEVER_FIRE();

  /**
   * Translated "Unable to parse cron expression. {0}".
   * 
   * @return translated "Unable to parse cron expression. {0}"
   */
  @DefaultStringValue("Unable to parse cron expression. {0}")
  @Key("UNABLE_TO_PARSE_CRON_EXPRESSION")
  String UNABLE_TO_PARSE_CRON_EXPRESSION();

  /**
   * Translated "You are not logged in.".
   * 
   * @return translated "You are not logged in."
   */
  @DefaultStringValue("You are not logged in.")
  @Key("UNAUTHENTICATED")
  String UNAUTHENTICATED();

  /**
   * Translated "Value".
   * 
   * @return translated "Value"
   */
  @DefaultStringValue("Value")
  @Key("VALUE")
  String VALUE();

  /**
   * Translated "Waiting to Start ".
   * 
   * @return translated "Waiting to Start "
   */
  @DefaultStringValue("Waiting to Start ")
  @Key("WAITING_TO_START")
  String WAITING_TO_START();

  /**
   * Translated "The operation completed with a warning. {0}".
   * 
   * @return translated "The operation completed with a warning. {0}"
   */
  @DefaultStringValue("The operation completed with a warning. {0}")
  @Key("WARNING")
  String WARNING();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultStringValue("Created By")
  @Key("accessGroupCreatedBy")
  String accessGroupCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultStringValue("Created On")
  @Key("accessGroupCreatedOn")
  String accessGroupCreatedOn();

  /**
   * Translated "Access Group Description".
   * 
   * @return translated "Access Group Description"
   */
  @DefaultStringValue("Access Group Description")
  @Key("accessGroupDescription")
  String accessGroupDescription();

  /**
   * Translated "Access Group".
   * 
   * @return translated "Access Group"
   */
  @DefaultStringValue("Access Group")
  @Key("accessGroupInfo")
  String accessGroupInfo();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultStringValue("Modified By")
  @Key("accessGroupModifiedBy")
  String accessGroupModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultStringValue("Modified On")
  @Key("accessGroupModifiedOn")
  String accessGroupModifiedOn();

  /**
   * Translated "Access Group Name".
   * 
   * @return translated "Access Group Name"
   */
  @DefaultStringValue("Access Group Name")
  @Key("accessGroupName")
  String accessGroupName();

  /**
   * Translated "Access Token".
   * 
   * @return translated "Access Token"
   */
  @DefaultStringValue("Access Token")
  @Key("accessTokenParameterLabelKey")
  String accessTokenParameterLabelKey();

  /**
   * Translated "Access Token".
   * 
   * @return translated "Access Token"
   */
  @DefaultStringValue("Access Token")
  @Key("accessTokenParameterTooltipKey")
  String accessTokenParameterTooltipKey();

  /**
   * Translated "Access Token Secret".
   * 
   * @return translated "Access Token Secret"
   */
  @DefaultStringValue("Access Token Secret")
  @Key("accessTokenSecretParameterLabelKey")
  String accessTokenSecretParameterLabelKey();

  /**
   * Translated "Access Token Secret".
   * 
   * @return translated "Access Token Secret"
   */
  @DefaultStringValue("Access Token Secret")
  @Key("accessTokenSecretParameterTooltipKey")
  String accessTokenSecretParameterTooltipKey();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultStringValue("Created By")
  @Key("accountCreatedBy")
  String accountCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultStringValue("Created On")
  @Key("accountCreatedOn")
  String accountCreatedOn();

  /**
   * Translated "Account Information".
   * 
   * @return translated "Account Information"
   */
  @DefaultStringValue("Account Information")
  @Key("accountInfo")
  String accountInfo();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultStringValue("Modified By")
  @Key("accountModifiedBy")
  String accountModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultStringValue("Modified On")
  @Key("accountModifiedOn")
  String accountModifiedOn();

  /**
   * Translated "Account Name".
   * 
   * @return translated "Account Name"
   */
  @DefaultStringValue("Account Name")
  @Key("accountName")
  String accountName();

  /**
   * Translated "Parent Account Name".
   * 
   * @return translated "Parent Account Name"
   */
  @DefaultStringValue("Parent Account Name")
  @Key("accountParent")
  String accountParent();

  /**
   * Translated "Provisioning Status".
   * 
   * @return translated "Provisioning Status"
   */
  @DefaultStringValue("Provisioning Status")
  @Key("accountProvisioningStatus")
  String accountProvisioningStatus();

  /**
   * Translated "Account Status".
   * 
   * @return translated "Account Status"
   */
  @DefaultStringValue("Account Status")
  @Key("accountStatus")
  String accountStatus();

  /**
   * Translated "Twilio Account ID".
   * 
   * @return translated "Twilio Account ID"
   */
  @DefaultStringValue("Twilio Account ID")
  @Key("accountsidParameterLabelKey")
  String accountsidParameterLabelKey();

  /**
   * Translated "The 34 character Account identifier (starting with 'AC'). This can be found on the Twilio dashboard page.".
   * 
   * @return translated "The 34 character Account identifier (starting with 'AC'). This can be found on the Twilio dashboard page."
   */
  @DefaultStringValue("The 34 character Account identifier (starting with 'AC'). This can be found on the Twilio dashboard page.")
  @Key("accountsidParameterTooltipKey")
  String accountsidParameterTooltipKey();

  /**
   * Translated "Alert".
   * 
   * @return translated "Alert"
   */
  @DefaultStringValue("Alert")
  @Key("alertRuleActionLabelKey")
  String alertRuleActionLabelKey();

  /**
   * Translated "Mandatory Provisioning".
   * 
   * @return translated "Mandatory Provisioning"
   */
  @DefaultStringValue("Mandatory Provisioning")
  @Key("allowNewNotProvisionedDevices")
  String allowNewNotProvisionedDevices();

  /**
   * Translated "Allow User Change".
   * 
   * @return translated "Allow User Change"
   */
  @DefaultStringValue("Allow User Change")
  @Key("allowUserChange")
  String allowUserChange();

  /**
   * Translated "Any".
   * 
   * @return translated "Any"
   */
  @DefaultStringValue("Any")
  @Key("any")
  String any();

  /**
   * Translated "Attachment Content Type".
   * 
   * @return translated "Attachment Content Type"
   */
  @DefaultStringValue("Attachment Content Type")
  @Key("attachmentContentType")
  String attachmentContentType();

  /**
   * Translated "Attachment #1 Info".
   * 
   * @return translated "Attachment #1 Info"
   */
  @DefaultStringValue("Attachment #1 Info")
  @Key("attachmentInfo1")
  String attachmentInfo1();

  /**
   * Translated "Attachment #10 Info".
   * 
   * @return translated "Attachment #10 Info"
   */
  @DefaultStringValue("Attachment #10 Info")
  @Key("attachmentInfo10")
  String attachmentInfo10();

  /**
   * Translated "Attachment #2 Info".
   * 
   * @return translated "Attachment #2 Info"
   */
  @DefaultStringValue("Attachment #2 Info")
  @Key("attachmentInfo2")
  String attachmentInfo2();

  /**
   * Translated "Attachment #3 Info".
   * 
   * @return translated "Attachment #3 Info"
   */
  @DefaultStringValue("Attachment #3 Info")
  @Key("attachmentInfo3")
  String attachmentInfo3();

  /**
   * Translated "Attachment #4 Info".
   * 
   * @return translated "Attachment #4 Info"
   */
  @DefaultStringValue("Attachment #4 Info")
  @Key("attachmentInfo4")
  String attachmentInfo4();

  /**
   * Translated "Attachment #5 Info".
   * 
   * @return translated "Attachment #5 Info"
   */
  @DefaultStringValue("Attachment #5 Info")
  @Key("attachmentInfo5")
  String attachmentInfo5();

  /**
   * Translated "Attachment #6 Info".
   * 
   * @return translated "Attachment #6 Info"
   */
  @DefaultStringValue("Attachment #6 Info")
  @Key("attachmentInfo6")
  String attachmentInfo6();

  /**
   * Translated "Attachment #7 Info".
   * 
   * @return translated "Attachment #7 Info"
   */
  @DefaultStringValue("Attachment #7 Info")
  @Key("attachmentInfo7")
  String attachmentInfo7();

  /**
   * Translated "Attachment #8 Info".
   * 
   * @return translated "Attachment #8 Info"
   */
  @DefaultStringValue("Attachment #8 Info")
  @Key("attachmentInfo8")
  String attachmentInfo8();

  /**
   * Translated "Attachment #9 Info".
   * 
   * @return translated "Attachment #9 Info"
   */
  @DefaultStringValue("Attachment #9 Info")
  @Key("attachmentInfo9")
  String attachmentInfo9();

  /**
   * Translated "Attachment Name".
   * 
   * @return translated "Attachment Name"
   */
  @DefaultStringValue("Attachment Name")
  @Key("attachmentName")
  String attachmentName();

  /**
   * Translated "Attachment Size".
   * 
   * @return translated "Attachment Size"
   */
  @DefaultStringValue("Attachment Size")
  @Key("attachmentSize")
  String attachmentSize();

  /**
   * Translated "Twilio Auth Token".
   * 
   * @return translated "Twilio Auth Token"
   */
  @DefaultStringValue("Twilio Auth Token")
  @Key("authtokenParameterLabelKey")
  String authtokenParameterLabelKey();

  /**
   * Translated "the 32 character AuthToken. This can be found on the Twilio dashboard page.".
   * 
   * @return translated "the 32 character AuthToken. This can be found on the Twilio dashboard page."
   */
  @DefaultStringValue("the 32 character AuthToken. This can be found on the Twilio dashboard page.")
  @Key("authtokenParameterTooltipKey")
  String authtokenParameterTooltipKey();

  /**
   * Translated "Active".
   * 
   * @return translated "Active"
   */
  @DefaultStringValue("Active")
  @Key("bndActive")
  String bndActive();

  /**
   * Translated "Installed".
   * 
   * @return translated "Installed"
   */
  @DefaultStringValue("Installed")
  @Key("bndInstalled")
  String bndInstalled();

  /**
   * Translated "Resolved".
   * 
   * @return translated "Resolved"
   */
  @DefaultStringValue("Resolved")
  @Key("bndResolved")
  String bndResolved();

  /**
   * Translated "Starting".
   * 
   * @return translated "Starting"
   */
  @DefaultStringValue("Starting")
  @Key("bndStarting")
  String bndStarting();

  /**
   * Translated "Stopping".
   * 
   * @return translated "Stopping"
   */
  @DefaultStringValue("Stopping")
  @Key("bndStopping")
  String bndStopping();

  /**
   * Translated "Uninstalled".
   * 
   * @return translated "Uninstalled"
   */
  @DefaultStringValue("Uninstalled")
  @Key("bndUninstalled")
  String bndUninstalled();

  /**
   * Translated "Unknown".
   * 
   * @return translated "Unknown"
   */
  @DefaultStringValue("Unknown")
  @Key("bndUnknown")
  String bndUnknown();

  /**
   * Translated "Body".
   * 
   * @return translated "Body"
   */
  @DefaultStringValue("Body")
  @Key("bodyParameterLabelKey")
  String bodyParameterLabelKey();

  /**
   * Translated "Email Body".
   * 
   * @return translated "Email Body"
   */
  @DefaultStringValue("Email Body")
  @Key("bodyParameterTooltipKey")
  String bodyParameterTooltipKey();

  /**
   * Translated "Alternative body".
   * 
   * @return translated "Alternative body"
   */
  @DefaultStringValue("Alternative body")
  @Key("bodyTextOnlyParameterLabelKey")
  String bodyTextOnlyParameterLabelKey();

  /**
   * Translated "Alternative email body if the recipient client doesn't support the HTML format.".
   * 
   * @return translated "Alternative email body if the recipient client doesn't support the HTML format."
   */
  @DefaultStringValue("Alternative email body if the recipient client doesn't support the HTML format.")
  @Key("bodyTextOnlyParameterTooltipKey")
  String bodyTextOnlyParameterTooltipKey();

  /**
   * Translated "Compute Optimized 2-Extra Large (c3.2xlarge)".
   * 
   * @return translated "Compute Optimized 2-Extra Large (c3.2xlarge)"
   */
  @DefaultStringValue("Compute Optimized 2-Extra Large (c3.2xlarge)")
  @Key("c3_2xlarge")
  String c3_2xlarge();

  /**
   * Translated "Compute Optimized 4-Extra Large (c3.4xlarge)".
   * 
   * @return translated "Compute Optimized 4-Extra Large (c3.4xlarge)"
   */
  @DefaultStringValue("Compute Optimized 4-Extra Large (c3.4xlarge)")
  @Key("c3_4xlarge")
  String c3_4xlarge();

  /**
   * Translated "Compute Optimized 8-Extra Large (c3.8xlarge)".
   * 
   * @return translated "Compute Optimized 8-Extra Large (c3.8xlarge)"
   */
  @DefaultStringValue("Compute Optimized 8-Extra Large (c3.8xlarge)")
  @Key("c3_8xlarge")
  String c3_8xlarge();

  /**
   * Translated "Compute Optimized Large (c3.large)".
   * 
   * @return translated "Compute Optimized Large (c3.large)"
   */
  @DefaultStringValue("Compute Optimized Large (c3.large)")
  @Key("c3_large")
  String c3_large();

  /**
   * Translated "Compute Optimized Extra Large (c3.xlarge)".
   * 
   * @return translated "Compute Optimized Extra Large (c3.xlarge)"
   */
  @DefaultStringValue("Compute Optimized Extra Large (c3.xlarge)")
  @Key("c3_xlarge")
  String c3_xlarge();

  /**
   * Translated "Category".
   * 
   * @return translated "Category"
   */
  @DefaultStringValue("Category")
  @Key("categoryParameterLabelKey")
  String categoryParameterLabelKey();

  /**
   * Translated "Could be 'Performance', 'Security', etc ...".
   * 
   * @return translated "Could be 'Performance', 'Security', etc ..."
   */
  @DefaultStringValue("Could be 'Performance', 'Security', etc ...")
  @Key("categoryParameterTooltipKey")
  String categoryParameterTooltipKey();

  /**
   * Translated "Choice".
   * 
   * @return translated "Choice"
   */
  @DefaultStringValue("Choice")
  @Key("choice")
  String choice();

  /**
   * Translated "Choice".
   * 
   * @return translated "Choice"
   */
  @DefaultStringValue("Choice")
  @Key("choiceParameterLabelKey")
  String choiceParameterLabelKey();

  /**
   * Translated "Choice Tooltip".
   * 
   * @return translated "Choice Tooltip"
   */
  @DefaultStringValue("Choice Tooltip")
  @Key("choiceTooltip")
  String choiceTooltip();

  /**
   * Translated "Code".
   * 
   * @return translated "Code"
   */
  @DefaultStringValue("Code")
  @Key("codeParameterLabelKey")
  String codeParameterLabelKey();

  /**
   * Translated "A code at your convenance ('VPN', 'CPU' etc...)".
   * 
   * @return translated "A code at your convenance ('VPN', 'CPU' etc...)"
   */
  @DefaultStringValue("A code at your convenance ('VPN', 'CPU' etc...)")
  @Key("codeParameterTooltipKey")
  String codeParameterTooltipKey();

  /**
   * Translated "Value must be smaller than {0}".
   * 
   * @return translated "Value must be smaller than {0}"
   */
  @DefaultStringValue("Value must be smaller than {0}")
  @Key("configMaxValue")
  String configMaxValue();

  /**
   * Translated "Value must be greater than {0}".
   * 
   * @return translated "Value must be greater than {0}"
   */
  @DefaultStringValue("Value must be greater than {0}")
  @Key("configMinValue")
  String configMinValue();

  /**
   * Translated "Connection Client ID".
   * 
   * @return translated "Connection Client ID"
   */
  @DefaultStringValue("Connection Client ID")
  @Key("connClientId")
  String connClientId();

  /**
   * Translated "Remote IP".
   * 
   * @return translated "Remote IP"
   */
  @DefaultStringValue("Remote IP")
  @Key("connClientIp")
  String connClientIp();

  /**
   * Translated "Connection Status".
   * 
   * @return translated "Connection Status"
   */
  @DefaultStringValue("Connection Status")
  @Key("connConnectionStatus")
  String connConnectionStatus();

  /**
   * Translated "Connection Information".
   * 
   * @return translated "Connection Information"
   */
  @DefaultStringValue("Connection Information")
  @Key("connInfo")
  String connInfo();

  /**
   * Translated "Reserved User".
   * 
   * @return translated "Reserved User"
   */
  @DefaultStringValue("Reserved User")
  @Key("connReservedUserId")
  String connReservedUserId();

  /**
   * Translated "User Coupling Mode".
   * 
   * @return translated "User Coupling Mode"
   */
  @DefaultStringValue("User Coupling Mode")
  @Key("connUserCouplingMode")
  String connUserCouplingMode();

  /**
   * Translated "Last Connected User".
   * 
   * @return translated "Last Connected User"
   */
  @DefaultStringValue("Last Connected User")
  @Key("connUserName")
  String connUserName();

  /**
   * Translated "Client ID".
   * 
   * @return translated "Client ID"
   */
  @DefaultStringValue("Client ID")
  @Key("connectionClientId")
  String connectionClientId();

  /**
   * Translated "Client IP".
   * 
   * @return translated "Client IP"
   */
  @DefaultStringValue("Client IP")
  @Key("connectionClientIp")
  String connectionClientIp();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultStringValue("Created By")
  @Key("connectionFirstEstablishedBy")
  String connectionFirstEstablishedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultStringValue("Created On")
  @Key("connectionFirstEstablishedOn")
  String connectionFirstEstablishedOn();

  /**
   * Translated "Connection Information".
   * 
   * @return translated "Connection Information"
   */
  @DefaultStringValue("Connection Information")
  @Key("connectionInfo")
  String connectionInfo();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultStringValue("Modified By")
  @Key("connectionModifiedBy")
  String connectionModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultStringValue("Modified On")
  @Key("connectionModifiedOn")
  String connectionModifiedOn();

  /**
   * Translated "Protocol".
   * 
   * @return translated "Protocol"
   */
  @DefaultStringValue("Protocol")
  @Key("connectionProtocol")
  String connectionProtocol();

  /**
   * Translated "Reserved User".
   * 
   * @return translated "Reserved User"
   */
  @DefaultStringValue("Reserved User")
  @Key("connectionReservedUser")
  String connectionReservedUser();

  /**
   * Translated "Server IP".
   * 
   * @return translated "Server IP"
   */
  @DefaultStringValue("Server IP")
  @Key("connectionServerIp")
  String connectionServerIp();

  /**
   * Translated "Connection Status".
   * 
   * @return translated "Connection Status"
   */
  @DefaultStringValue("Connection Status")
  @Key("connectionStatus")
  String connectionStatus();

  /**
   * Translated "User".
   * 
   * @return translated "User"
   */
  @DefaultStringValue("User")
  @Key("connectionUser")
  String connectionUser();

  /**
   * Translated "User Coupling Mode".
   * 
   * @return translated "User Coupling Mode"
   */
  @DefaultStringValue("User Coupling Mode")
  @Key("connectionUserCouplingMode")
  String connectionUserCouplingMode();

  /**
   * Translated "User Coupling Mode Information".
   * 
   * @return translated "User Coupling Mode Information"
   */
  @DefaultStringValue("User Coupling Mode Information")
  @Key("connectionUserCouplingModeInfo")
  String connectionUserCouplingModeInfo();

  /**
   * Translated "Connection Information".
   * 
   * @return translated "Connection Information"
   */
  @DefaultStringValue("Connection Information")
  @Key("connectionsInfo")
  String connectionsInfo();

  /**
   * Translated "Consumer Key".
   * 
   * @return translated "Consumer Key"
   */
  @DefaultStringValue("Consumer Key")
  @Key("consumerKeyParameterLabelKey")
  String consumerKeyParameterLabelKey();

  /**
   * Translated "you get your app's consumer key/secret pair after registering an application into https://dev.twitter.com/ ".
   * 
   * @return translated "you get your app's consumer key/secret pair after registering an application into https://dev.twitter.com/ "
   */
  @DefaultStringValue("you get your app's consumer key/secret pair after registering an application into https://dev.twitter.com/ ")
  @Key("consumerKeyParameterTooltipKey")
  String consumerKeyParameterTooltipKey();

  /**
   * Translated "Consumer Secret".
   * 
   * @return translated "Consumer Secret"
   */
  @DefaultStringValue("Consumer Secret")
  @Key("consumerSecretParameterLabelKey")
  String consumerSecretParameterLabelKey();

  /**
   * Translated "you get your app's consumer key/secret pair after registering an application into https://dev.twitter.com/ ".
   * 
   * @return translated "you get your app's consumer key/secret pair after registering an application into https://dev.twitter.com/ "
   */
  @DefaultStringValue("you get your app's consumer key/secret pair after registering an application into https://dev.twitter.com/ ")
  @Key("consumerSecretParameterTooltipKey")
  String consumerSecretParameterTooltipKey();

  /**
   * Translated "Cron expression is required".
   * 
   * @return translated "Cron expression is required"
   */
  @DefaultStringValue("Cron expression is required")
  @Key("cronExpressionRequired")
  String cronExpressionRequired();

  /**
   * Translated "Data Plan Per Device (MB/m)".
   * 
   * @return translated "Data Plan Per Device (MB/m)"
   */
  @DefaultStringValue("Data Plan Per Device (MB/m)")
  @Key("dataPlanPerDevice")
  String dataPlanPerDevice();

  /**
   * Translated "Data Storage Enabled?".
   * 
   * @return translated "Data Storage Enabled?"
   */
  @DefaultStringValue("Data Storage Enabled?")
  @Key("dataStorage")
  String dataStorage();

  /**
   * Translated "Data Time to Live (days)".
   * 
   * @return translated "Data Time to Live (days)"
   */
  @DefaultStringValue("Data Time to Live (days)")
  @Key("dataTimeToLive")
  String dataTimeToLive();

  /**
   * Translated "Date".
   * 
   * @return translated "Date"
   */
  @DefaultStringValue("Date")
  @Key("date")
  String date();

  /**
   * Translated "Date".
   * 
   * @return translated "Date"
   */
  @DefaultStringValue("Date")
  @Key("dateParameterLabelKey")
  String dateParameterLabelKey();

  /**
   * Translated "This date comes before Thursday January 01 01:00:00 CET 1970".
   * 
   * @return translated "This date comes before Thursday January 01 01:00:00 CET 1970"
   */
  @DefaultStringValue("This date comes before Thursday January 01 01:00:00 CET 1970")
  @Key("dateRangeValidatorAfter1Jan1970")
  String dateRangeValidatorAfter1Jan1970();

  /**
   * Translated "The end date comes before the start date. If not set the start date is automatically set to the current date.".
   * 
   * @return translated "The end date comes before the start date. If not set the start date is automatically set to the current date."
   */
  @DefaultStringValue("The end date comes before the start date. If not set the start date is automatically set to the current date.")
  @Key("dateRangeValidatorEndDateBeforeStartDate")
  String dateRangeValidatorEndDateBeforeStartDate();

  /**
   * Translated "Date Tooltip".
   * 
   * @return translated "Date Tooltip"
   */
  @DefaultStringValue("Date Tooltip")
  @Key("dateTooltip")
  String dateTooltip();

  /**
   * Translated "Device Credential Strategy".
   * 
   * @return translated "Device Credential Strategy"
   */
  @DefaultStringValue("Device Credential Strategy")
  @Key("defaultDeviceTightCredentials")
  String defaultDeviceTightCredentials();

  /**
   * Translated "Broker Image Name".
   * 
   * @return translated "Broker Image Name"
   */
  @DefaultStringValue("Broker Image Name")
  @Key("deploymentBrokerImageName")
  String deploymentBrokerImageName();

  /**
   * Translated "Deployment Info".
   * 
   * @return translated "Deployment Info"
   */
  @DefaultStringValue("Deployment Info")
  @Key("deploymentInfo")
  String deploymentInfo();

  /**
   * Translated "Broker URI".
   * 
   * @return translated "Broker URI"
   */
  @DefaultStringValue("Broker URI")
  @Key("deploymentNodeUri")
  String deploymentNodeUri();

  /**
   * Translated "Secure Broker URI".
   * 
   * @return translated "Secure Broker URI"
   */
  @DefaultStringValue("Secure Broker URI")
  @Key("deploymentNodeUriSecure")
  String deploymentNodeUriSecure();

  /**
   * Translated "Vpn URL".
   * 
   * @return translated "Vpn URL"
   */
  @DefaultStringValue("Vpn URL")
  @Key("deploymentVpnURL")
  String deploymentVpnURL();

  /**
   * Translated "Accepted Payload Encoding".
   * 
   * @return translated "Accepted Payload Encoding"
   */
  @DefaultStringValue("Accepted Payload Encoding")
  @Key("devAccEnc")
  String devAccEnc();

  /**
   * Translated "Active Cloud Applications".
   * 
   * @return translated "Active Cloud Applications"
   */
  @DefaultStringValue("Active Cloud Applications")
  @Key("devApps")
  String devApps();

  /**
   * Translated "Attributes Information".
   * 
   * @return translated "Attributes Information"
   */
  @DefaultStringValue("Attributes Information")
  @Key("devAttributesInfo")
  String devAttributesInfo();

  /**
   * Translated "Available Processors".
   * 
   * @return translated "Available Processors"
   */
  @DefaultStringValue("Available Processors")
  @Key("devAvailableProcessors")
  String devAvailableProcessors();

  /**
   * Translated "BIOS Version".
   * 
   * @return translated "BIOS Version"
   */
  @DefaultStringValue("BIOS Version")
  @Key("devBiosVersion")
  String devBiosVersion();

  /**
   * Translated "Client ID".
   * 
   * @return translated "Client ID"
   */
  @DefaultStringValue("Client ID")
  @Key("devClientId")
  String devClientId();

  /**
   * Translated "Connection Status".
   * 
   * @return translated "Connection Status"
   */
  @DefaultStringValue("Connection Status")
  @Key("devConnectionStatus")
  String devConnectionStatus();

  /**
   * Translated "Custom Attribute 1".
   * 
   * @return translated "Custom Attribute 1"
   */
  @DefaultStringValue("Custom Attribute 1")
  @Key("devCustomAttribute1")
  String devCustomAttribute1();

  /**
   * Translated "Custom Attribute 2".
   * 
   * @return translated "Custom Attribute 2"
   */
  @DefaultStringValue("Custom Attribute 2")
  @Key("devCustomAttribute2")
  String devCustomAttribute2();

  /**
   * Translated "Custom Attribute 3".
   * 
   * @return translated "Custom Attribute 3"
   */
  @DefaultStringValue("Custom Attribute 3")
  @Key("devCustomAttribute3")
  String devCustomAttribute3();

  /**
   * Translated "Custom Attribute 4".
   * 
   * @return translated "Custom Attribute 4"
   */
  @DefaultStringValue("Custom Attribute 4")
  @Key("devCustomAttribute4")
  String devCustomAttribute4();

  /**
   * Translated "Custom Attribute 5".
   * 
   * @return translated "Custom Attribute 5"
   */
  @DefaultStringValue("Custom Attribute 5")
  @Key("devCustomAttribute5")
  String devCustomAttribute5();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultStringValue("Display Name")
  @Key("devDisplayName")
  String devDisplayName();

  /**
   * Translated "KURA/ESF Version".
   * 
   * @return translated "KURA/ESF Version"
   */
  @DefaultStringValue("KURA/ESF Version")
  @Key("devEsfVersion")
  String devEsfVersion();

  /**
   * Translated "Firmware Version".
   * 
   * @return translated "Firmware Version"
   */
  @DefaultStringValue("Firmware Version")
  @Key("devFirmwareVersion")
  String devFirmwareVersion();

  /**
   * Translated "Group ID".
   * 
   * @return translated "Group ID"
   */
  @DefaultStringValue("Group ID")
  @Key("devGroupId")
  String devGroupId();

  /**
   * Translated "Access Group".
   * 
   * @return translated "Access Group"
   */
  @DefaultStringValue("Access Group")
  @Key("devGroupName")
  String devGroupName();

  /**
   * Translated "Hardware Information".
   * 
   * @return translated "Hardware Information"
   */
  @DefaultStringValue("Hardware Information")
  @Key("devHw")
  String devHw();

  /**
   * Translated "Cloud Connection Information".
   * 
   * @return translated "Cloud Connection Information"
   */
  @DefaultStringValue("Cloud Connection Information")
  @Key("devInfo")
  String devInfo();

  /**
   * Translated "Java Information".
   * 
   * @return translated "Java Information"
   */
  @DefaultStringValue("Java Information")
  @Key("devJava")
  String devJava();

  /**
   * Translated "Java Virtual Machine".
   * 
   * @return translated "Java Virtual Machine"
   */
  @DefaultStringValue("Java Virtual Machine")
  @Key("devJvmName")
  String devJvmName();

  /**
   * Translated "Java Runtime".
   * 
   * @return translated "Java Runtime"
   */
  @DefaultStringValue("Java Runtime")
  @Key("devJvmProfile")
  String devJvmProfile();

  /**
   * Translated "Java Virtual Machine Version".
   * 
   * @return translated "Java Virtual Machine Version"
   */
  @DefaultStringValue("Java Virtual Machine Version")
  @Key("devJvmVersion")
  String devJvmVersion();

  /**
   * Translated "Last Event On".
   * 
   * @return translated "Last Event On"
   */
  @DefaultStringValue("Last Event On")
  @Key("devLastEventOn")
  String devLastEventOn();

  /**
   * Translated "Last Event Type".
   * 
   * @return translated "Last Event Type"
   */
  @DefaultStringValue("Last Event Type")
  @Key("devLastEventType")
  String devLastEventType();

  /**
   * Translated "Last Successfully Connected User".
   * 
   * @return translated "Last Successfully Connected User"
   */
  @DefaultStringValue("Last Successfully Connected User")
  @Key("devLastUserUsed")
  String devLastUserUsed();

  /**
   * Translated "Model ID".
   * 
   * @return translated "Model ID"
   */
  @DefaultStringValue("Model ID")
  @Key("devModelId")
  String devModelId();

  /**
   * Translated "Model Name".
   * 
   * @return translated "Model Name"
   */
  @DefaultStringValue("Model Name")
  @Key("devModelName")
  String devModelName();

  /**
   * Translated "Number of Processors".
   * 
   * @return translated "Number of Processors"
   */
  @DefaultStringValue("Number of Processors")
  @Key("devNumProc")
  String devNumProc();

  /**
   * Translated "Operating System".
   * 
   * @return translated "Operating System"
   */
  @DefaultStringValue("Operating System")
  @Key("devOs")
  String devOs();

  /**
   * Translated "OS Architecture".
   * 
   * @return translated "OS Architecture"
   */
  @DefaultStringValue("OS Architecture")
  @Key("devOsArch")
  String devOsArch();

  /**
   * Translated "Operating System Version".
   * 
   * @return translated "Operating System Version"
   */
  @DefaultStringValue("Operating System Version")
  @Key("devOsVersion")
  String devOsVersion();

  /**
   * Translated "OSGI Framework".
   * 
   * @return translated "OSGI Framework"
   */
  @DefaultStringValue("OSGI Framework")
  @Key("devOsgiFramework")
  String devOsgiFramework();

  /**
   * Translated "OSGI Framework Version".
   * 
   * @return translated "OSGI Framework Version"
   */
  @DefaultStringValue("OSGI Framework Version")
  @Key("devOsgiFrameworkVersion")
  String devOsgiFrameworkVersion();

  /**
   * Translated "Part Number".
   * 
   * @return translated "Part Number"
   */
  @DefaultStringValue("Part Number")
  @Key("devPartNumber")
  String devPartNumber();

  /**
   * Translated "Free RAM".
   * 
   * @return translated "Free RAM"
   */
  @DefaultStringValue("Free RAM")
  @Key("devRamFree")
  String devRamFree();

  /**
   * Translated "Total RAM".
   * 
   * @return translated "Total RAM"
   */
  @DefaultStringValue("Total RAM")
  @Key("devRamTot")
  String devRamTot();

  /**
   * Translated "Device Credentials Security".
   * 
   * @return translated "Device Credentials Security"
   */
  @DefaultStringValue("Device Credentials Security")
  @Key("devSecurity")
  String devSecurity();

  /**
   * Translated "Allow Credentials Change".
   * 
   * @return translated "Allow Credentials Change"
   */
  @DefaultStringValue("Allow Credentials Change")
  @Key("devSecurityAllowCredentialsChange")
  String devSecurityAllowCredentialsChange();

  /**
   * Translated "Credentials Tight Strategy".
   * 
   * @return translated "Credentials Tight Strategy"
   */
  @DefaultStringValue("Credentials Tight Strategy")
  @Key("devSecurityCredentialsTight")
  String devSecurityCredentialsTight();

  /**
   * Translated "Serial Number".
   * 
   * @return translated "Serial Number"
   */
  @DefaultStringValue("Serial Number")
  @Key("devSerialNumber")
  String devSerialNumber();

  /**
   * Translated "Status Information".
   * 
   * @return translated "Status Information"
   */
  @DefaultStringValue("Status Information")
  @Key("devStat")
  String devStat();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultStringValue("Status")
  @Key("devStatus")
  String devStatus();

  /**
   * Translated "Software Information".
   * 
   * @return translated "Software Information"
   */
  @DefaultStringValue("Software Information")
  @Key("devSw")
  String devSw();

  /**
   * Translated "Tags".
   * 
   * @return translated "Tags"
   */
  @DefaultStringValue("Tags")
  @Key("devTagAttributes")
  String devTagAttributes();

  /**
   * Translated "Total Memory".
   * 
   * @return translated "Total Memory"
   */
  @DefaultStringValue("Total Memory")
  @Key("devTotalMemory")
  String devTotalMemory();

  /**
   * Translated "Uptime".
   * 
   * @return translated "Uptime"
   */
  @DefaultStringValue("Uptime")
  @Key("devUptime")
  String devUptime();

  /**
   * Translated "Display Name must be minimum 3 char long and not have whitespace at the beginning or at the end .".
   * 
   * @return translated "Display Name must be minimum 3 char long and not have whitespace at the beginning or at the end ."
   */
  @DefaultStringValue("Display Name must be minimum 3 char long and not have whitespace at the beginning or at the end .")
  @Key("deviceFormDisplayNameValidationMessage")
  String deviceFormDisplayNameValidationMessage();

  /**
   * Translated "Tag Name must be 3 to 255 char long and could include chars, numbers and - _ @ # ! $ % ^ &amp; * + = ? &lt; &gt; ".
   * 
   * @return translated "Tag Name must be 3 to 255 char long and could include chars, numbers and - _ @ # ! $ % ^ &amp; * + = ? &lt; &gt; "
   */
  @DefaultStringValue("Tag Name must be 3 to 255 char long and could include chars, numbers and - _ @ # ! $ % ^ &amp; * + = ? &lt; &gt; ")
  @Key("deviceFormTagNameValidationMessage")
  String deviceFormTagNameValidationMessage();

  /**
   * Translated "Device ID".
   * 
   * @return translated "Device ID"
   */
  @DefaultStringValue("Device ID")
  @Key("deviceId")
  String deviceId();

  /**
   * Translated "This value cannot be equals or lower of the current job retries.".
   * 
   * @return translated "This value cannot be equals or lower of the current job retries."
   */
  @DefaultStringValue("This value cannot be equals or lower of the current job retries.")
  @Key("deviceJobFormMaxRetriesMin")
  String deviceJobFormMaxRetriesMin();

  /**
   * Translated "Please select at least one tag or one client id as target of this job.".
   * 
   * @return translated "Please select at least one tag or one client id as target of this job."
   */
  @DefaultStringValue("Please select at least one tag or one client id as target of this job.")
  @Key("deviceJobFormTarget")
  String deviceJobFormTarget();

  /**
   * Translated "Accept-Encoding".
   * 
   * @return translated "Accept-Encoding"
   */
  @DefaultStringValue("Accept-Encoding")
  @Key("deviceProfileFormAcceptEncoding")
  String deviceProfileFormAcceptEncoding();

  /**
   * Translated "Account ID".
   * 
   * @return translated "Account ID"
   */
  @DefaultStringValue("Account ID")
  @Key("deviceProfileFormAccountId")
  String deviceProfileFormAccountId();

  /**
   * Translated "Address".
   * 
   * @return translated "Address"
   */
  @DefaultStringValue("Address")
  @Key("deviceProfileFormAddress")
  String deviceProfileFormAddress();

  /**
   * Translated "Application Identifiers".
   * 
   * @return translated "Application Identifiers"
   */
  @DefaultStringValue("Application Identifiers")
  @Key("deviceProfileFormApplicationIdentifiers")
  String deviceProfileFormApplicationIdentifiers();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultStringValue("Status")
  @Key("deviceProfileFormGwtDeviceStatus")
  String deviceProfileFormGwtDeviceStatus();

  /**
   * Translated "Last Event Date".
   * 
   * @return translated "Last Event Date"
   */
  @DefaultStringValue("Last Event Date")
  @Key("deviceProfileFormLastEventDate")
  String deviceProfileFormLastEventDate();

  /**
   * Translated "Last Event Message".
   * 
   * @return translated "Last Event Message"
   */
  @DefaultStringValue("Last Event Message")
  @Key("deviceProfileFormLastEventMessage")
  String deviceProfileFormLastEventMessage();

  /**
   * Translated "Last Event Type".
   * 
   * @return translated "Last Event Type"
   */
  @DefaultStringValue("Last Event Type")
  @Key("deviceProfileFormLastEventType")
  String deviceProfileFormLastEventType();

  /**
   * Translated "Device Connection Options".
   * 
   * @return translated "Device Connection Options"
   */
  @DefaultStringValue("Device Connection Options")
  @Key("deviceSecurityInfo")
  String deviceSecurityInfo();

  /**
   * Translated "Name must be at least 1 character and can contain alphanumeric characters combined with dash.".
   * 
   * @return translated "Name must be at least 1 character and can contain alphanumeric characters combined with dash."
   */
  @DefaultStringValue("Name must be at least 1 character and can contain alphanumeric characters combined with dash.")
  @Key("device_client_idRegexMsg")
  String device_client_idRegexMsg();

  /**
   * Translated "Device Client ID is required".
   * 
   * @return translated "Device Client ID is required"
   */
  @DefaultStringValue("Device Client ID is required")
  @Key("device_client_idRequiredMsg")
  String device_client_idRequiredMsg();

  /**
   * Translated "Must be at least 1 character and can contain alphanumeric characters combined with dash.".
   * 
   * @return translated "Must be at least 1 character and can contain alphanumeric characters combined with dash."
   */
  @DefaultStringValue("Must be at least 1 character and can contain alphanumeric characters combined with dash.")
  @Key("device_client_idToolTipMsg")
  String device_client_idToolTipMsg();

  /**
   * Translated "Double".
   * 
   * @return translated "Double"
   */
  @DefaultStringValue("Double")
  @Key("doubleParameterLabelKey")
  String doubleParameterLabelKey();

  /**
   * Translated "This value is already taken. Please specify another value. ".
   * 
   * @return translated "This value is already taken. Please specify another value. "
   */
  @DefaultStringValue("This value is already taken. Please specify another value. ")
  @Key("duplicateValue")
  String duplicateValue();

  /**
   * Translated "Invalid provided value. Must be a number or '0 - Disabled'.".
   * 
   * @return translated "Invalid provided value. Must be a number or '0 - Disabled'."
   */
  @DefaultStringValue("Invalid provided value. Must be a number or '0 - Disabled'.")
  @Key("editableComboRegexMsg")
  String editableComboRegexMsg();

  /**
   * Translated "Body Format".
   * 
   * @return translated "Body Format"
   */
  @DefaultStringValue("Body Format")
  @Key("emailFormatParameterLabelKey")
  String emailFormatParameterLabelKey();

  /**
   * Translated "The format of the mail body".
   * 
   * @return translated "The format of the mail body"
   */
  @DefaultStringValue("The format of the mail body")
  @Key("emailFormatParameterTooltipKey")
  String emailFormatParameterTooltipKey();

  /**
   * Translated "Email should be in the format of username@domain.com.".
   * 
   * @return translated "Email should be in the format of username@domain.com."
   */
  @DefaultStringValue("Email should be in the format of username@domain.com.")
  @Key("emailRegexMsg")
  String emailRegexMsg();

  /**
   * Translated "Rule Action to send an Email message.".
   * 
   * @return translated "Rule Action to send an Email message."
   */
  @DefaultStringValue("Rule Action to send an Email message.")
  @Key("emailRuleActionDescriptionKey")
  String emailRuleActionDescriptionKey();

  /**
   * Translated "email".
   * 
   * @return translated "email"
   */
  @DefaultStringValue("email")
  @Key("emailRuleActionIconUrl")
  String emailRuleActionIconUrl();

  /**
   * Translated "Email".
   * 
   * @return translated "Email"
   */
  @DefaultStringValue("Email")
  @Key("emailRuleActionLabelKey")
  String emailRuleActionLabelKey();

  /**
   * Translated "End date is in the past.".
   * 
   * @return translated "End date is in the past."
   */
  @DefaultStringValue("End date is in the past.")
  @Key("endDateOutOfTime")
  String endDateOutOfTime();

  /**
   * Translated "No end time specified with end date, or time not in 15 minutes interval".
   * 
   * @return translated "No end time specified with end date, or time not in 15 minutes interval"
   */
  @DefaultStringValue("No end time specified with end date, or time not in 15 minutes interval")
  @Key("endDateWithoutEndTime")
  String endDateWithoutEndTime();

  /**
   * Translated "End Time field is required".
   * 
   * @return translated "End Time field is required"
   */
  @DefaultStringValue("End Time field is required")
  @Key("endTimeEmpty")
  String endTimeEmpty();

  /**
   * Translated "No end date specified with end time".
   * 
   * @return translated "No end date specified with end time"
   */
  @DefaultStringValue("No end date specified with end time")
  @Key("endTimeWithoutEndDate")
  String endTimeWithoutEndDate();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultStringValue("Created By")
  @Key("endpointCreatedBy")
  String endpointCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultStringValue("Created On")
  @Key("endpointCreatedOn")
  String endpointCreatedOn();

  /**
   * Translated "Domain Name".
   * 
   * @return translated "Domain Name"
   */
  @DefaultStringValue("Domain Name")
  @Key("endpointDns")
  String endpointDns();

  /**
   * Translated "Endpoint".
   * 
   * @return translated "Endpoint"
   */
  @DefaultStringValue("Endpoint")
  @Key("endpointInfo")
  String endpointInfo();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultStringValue("Modified By")
  @Key("endpointModifiedBy")
  String endpointModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultStringValue("Modified On")
  @Key("endpointModifiedOn")
  String endpointModifiedOn();

  /**
   * Translated "Port".
   * 
   * @return translated "Port"
   */
  @DefaultStringValue("Port")
  @Key("endpointPort")
  String endpointPort();

  /**
   * Translated "Schema".
   * 
   * @return translated "Schema"
   */
  @DefaultStringValue("Schema")
  @Key("endpointSchema")
  String endpointSchema();

  /**
   * Translated "Secure".
   * 
   * @return translated "Secure"
   */
  @DefaultStringValue("Secure")
  @Key("endpointSecure")
  String endpointSecure();

  /**
   * Translated "Usages".
   * 
   * @return translated "Usages"
   */
  @DefaultStringValue("Usages")
  @Key("endpointUsages")
  String endpointUsages();

  /**
   * Translated "The end date cannot be earlier than the start date".
   * 
   * @return translated "The end date cannot be earlier than the start date"
   */
  @DefaultStringValue("The end date cannot be earlier than the start date")
  @Key("endsOnDateEarlierThanStartsOn")
  String endsOnDateEarlierThanStartsOn();

  /**
   * Translated "The end time cannot be earlier than the start time".
   * 
   * @return translated "The end time cannot be earlier than the start time"
   */
  @DefaultStringValue("The end time cannot be earlier than the start time")
  @Key("endsOnTimeEarlierThanStartsOn")
  String endsOnTimeEarlierThanStartsOn();

  /**
   * Translated "Entity".
   * 
   * @return translated "Entity"
   */
  @DefaultStringValue("Entity")
  @Key("entityInfo")
  String entityInfo();

  /**
   * Translated "Expiration Date".
   * 
   * @return translated "Expiration Date"
   */
  @DefaultStringValue("Expiration Date")
  @Key("expirationDate")
  String expirationDate();

  /**
   * Translated "Exponent".
   * 
   * @return translated "Exponent"
   */
  @DefaultStringValue("Exponent")
  @Key("exponent")
  String exponent();

  /**
   * Translated "Float".
   * 
   * @return translated "Float"
   */
  @DefaultStringValue("Float")
  @Key("floatParameterLabelKey")
  String floatParameterLabelKey();

  /**
   * Translated "Format".
   * 
   * @return translated "Format"
   */
  @DefaultStringValue("Format")
  @Key("format")
  String format();

  /**
   * Translated "Post body content type".
   * 
   * @return translated "Post body content type"
   */
  @DefaultStringValue("Post body content type")
  @Key("formatParameterLabelKey")
  String formatParameterLabelKey();

  /**
   * Translated "Data format used to send the message to the rest endpoint".
   * 
   * @return translated "Data format used to send the message to the rest endpoint"
   */
  @DefaultStringValue("Data format used to send the message to the rest endpoint")
  @Key("formatParameterTooltipKey")
  String formatParameterTooltipKey();

  /**
   * Translated "Post body content".
   * 
   * @return translated "Post body content"
   */
  @DefaultStringValue("Post body content")
  @Key("forwardParameterLabelKey")
  String forwardParameterLabelKey();

  /**
   * Translated "Choose \"rule triggering message\" if you want to forward the original message. NOTE: Choosing rule triggering message all the fields in Custom message metrics box will be ignored.".
   * 
   * @return translated "Choose \"rule triggering message\" if you want to forward the original message. NOTE: Choosing rule triggering message all the fields in Custom message metrics box will be ignored."
   */
  @DefaultStringValue("Choose \"rule triggering message\" if you want to forward the original message. NOTE: Choosing rule triggering message all the fields in Custom message metrics box will be ignored.")
  @Key("forwardParameterTooltipKey")
  String forwardParameterTooltipKey();

  /**
   * Translated "Twilio Phone Number".
   * 
   * @return translated "Twilio Phone Number"
   */
  @DefaultStringValue("Twilio Phone Number")
  @Key("fromParameterLabelKey")
  String fromParameterLabelKey();

  /**
   * Translated "A Twilio phone number must be bought before starting sending SMS.".
   * 
   * @return translated "A Twilio phone number must be bought before starting sending SMS."
   */
  @DefaultStringValue("A Twilio phone number must be bought before starting sending SMS.")
  @Key("fromParameterTooltipKey")
  String fromParameterTooltipKey();

  /**
   * Translated "Address".
   * 
   * @return translated "Address"
   */
  @DefaultStringValue("Address")
  @Key("gpsAddress")
  String gpsAddress();

  /**
   * Translated "Altitude".
   * 
   * @return translated "Altitude"
   */
  @DefaultStringValue("Altitude")
  @Key("gpsAlt")
  String gpsAlt();

  /**
   * Translated "GPS Information".
   * 
   * @return translated "GPS Information"
   */
  @DefaultStringValue("GPS Information")
  @Key("gpsInfo")
  String gpsInfo();

  /**
   * Translated "Latitude".
   * 
   * @return translated "Latitude"
   */
  @DefaultStringValue("Latitude")
  @Key("gpsLat")
  String gpsLat();

  /**
   * Translated "Longitude".
   * 
   * @return translated "Longitude"
   */
  @DefaultStringValue("Longitude")
  @Key("gpsLong")
  String gpsLong();

  /**
   * Translated "Health Check Interval (mins)".
   * 
   * @return translated "Health Check Interval (mins)"
   */
  @DefaultStringValue("Health Check Interval (mins)")
  @Key("healthCheckInterval")
  String healthCheckInterval();

  /**
   * Translated "Index Metrics By".
   * 
   * @return translated "Index Metrics By"
   */
  @DefaultStringValue("Index Metrics By")
  @Key("indexMetricsBy")
  String indexMetricsBy();

  /**
   * Translated "Index Received Data By".
   * 
   * @return translated "Index Received Data By"
   */
  @DefaultStringValue("Index Received Data By")
  @Key("indexReceivedDataBy")
  String indexReceivedDataBy();

  /**
   * Translated "Integer".
   * 
   * @return translated "Integer"
   */
  @DefaultStringValue("Integer")
  @Key("intParameterLabelKey")
  String intParameterLabelKey();

  /**
   * Translated "Invalid cron expression".
   * 
   * @return translated "Invalid cron expression"
   */
  @DefaultStringValue("Invalid cron expression")
  @Key("invalidCronExpression")
  String invalidCronExpression();

  /**
   * Translated "This value cannot be null. ".
   * 
   * @return translated "This value cannot be null. "
   */
  @DefaultStringValue("This value cannot be null. ")
  @Key("invalidNullValue")
  String invalidNullValue();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultStringValue("Created By")
  @Key("jobCreatedBy")
  String jobCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultStringValue("Created On")
  @Key("jobCreatedOn")
  String jobCreatedOn();

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultStringValue("Description")
  @Key("jobDescription")
  String jobDescription();

  /**
   * Translated "Job".
   * 
   * @return translated "Job"
   */
  @DefaultStringValue("Job")
  @Key("jobInfo")
  String jobInfo();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultStringValue("Modified By")
  @Key("jobModifiedBy")
  String jobModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultStringValue("Modified On")
  @Key("jobModifiedOn")
  String jobModifiedOn();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultStringValue("Name")
  @Key("jobName")
  String jobName();

  /**
   * Translated "Large Text".
   * 
   * @return translated "Large Text"
   */
  @DefaultStringValue("Large Text")
  @Key("largeText")
  String largeText();

  /**
   * Translated "Large Text".
   * 
   * @return translated "Large Text"
   */
  @DefaultStringValue("Large Text")
  @Key("largeTextParameterLabelKey")
  String largeTextParameterLabelKey();

  /**
   * Translated "Large Text Tooltip".
   * 
   * @return translated "Large Text Tooltip"
   */
  @DefaultStringValue("Large Text Tooltip")
  @Key("largeTextTooltip")
  String largeTextTooltip();

  /**
   * Translated "Cannot delete the last Administrator of an Account or remove its Administrator Role.".
   * 
   * @return translated "Cannot delete the last Administrator of an Account or remove its Administrator Role."
   */
  @DefaultStringValue("Cannot delete the last Administrator of an Account or remove its Administrator Role.")
  @Key("lastAdministrator")
  String lastAdministrator();

  /**
   * Translated "Login Attempts Reset After".
   * 
   * @return translated "Login Attempts Reset After"
   */
  @DefaultStringValue("Login Attempts Reset After")
  @Key("lockoutAttemptsResetAfter")
  String lockoutAttemptsResetAfter();

  /**
   * Translated "Enabled?".
   * 
   * @return translated "Enabled?"
   */
  @DefaultStringValue("Enabled?")
  @Key("lockoutEnabled")
  String lockoutEnabled();

  /**
   * Translated "Lockout Policy Info".
   * 
   * @return translated "Lockout Policy Info"
   */
  @DefaultStringValue("Lockout Policy Info")
  @Key("lockoutInfo")
  String lockoutInfo();

  /**
   * Translated "Lockout Duration".
   * 
   * @return translated "Lockout Duration"
   */
  @DefaultStringValue("Lockout Duration")
  @Key("lockoutLockDuration")
  String lockoutLockDuration();

  /**
   * Translated "Max Number Of Login Attempts".
   * 
   * @return translated "Max Number Of Login Attempts"
   */
  @DefaultStringValue("Max Number Of Login Attempts")
  @Key("lockoutMaxNumberOfFailures")
  String lockoutMaxNumberOfFailures();

  /**
   * Translated "Long".
   * 
   * @return translated "Long"
   */
  @DefaultStringValue("Long")
  @Key("longParameterLabelKey")
  String longParameterLabelKey();

  /**
   * Translated "Large (m1.large)".
   * 
   * @return translated "Large (m1.large)"
   */
  @DefaultStringValue("Large (m1.large)")
  @Key("m1_large")
  String m1_large();

  /**
   * Translated "Medium (m1.medium)".
   * 
   * @return translated "Medium (m1.medium)"
   */
  @DefaultStringValue("Medium (m1.medium)")
  @Key("m1_medium")
  String m1_medium();

  /**
   * Translated "Small (m1.small)".
   * 
   * @return translated "Small (m1.small)"
   */
  @DefaultStringValue("Small (m1.small)")
  @Key("m1_small")
  String m1_small();

  /**
   * Translated "Extra Large (m1.xlarge)".
   * 
   * @return translated "Extra Large (m1.xlarge)"
   */
  @DefaultStringValue("Extra Large (m1.xlarge)")
  @Key("m1_xlarge")
  String m1_xlarge();

  /**
   * Translated "2-Extra Large with SSD Storage (m3.2xlarge)".
   * 
   * @return translated "2-Extra Large with SSD Storage (m3.2xlarge)"
   */
  @DefaultStringValue("2-Extra Large with SSD Storage (m3.2xlarge)")
  @Key("m3_2xlarge")
  String m3_2xlarge();

  /**
   * Translated "Large with SSD Storage (m3.large)".
   * 
   * @return translated "Large with SSD Storage (m3.large)"
   */
  @DefaultStringValue("Large with SSD Storage (m3.large)")
  @Key("m3_large")
  String m3_large();

  /**
   * Translated "Medium with SSD Storage (m3.medium)".
   * 
   * @return translated "Medium with SSD Storage (m3.medium)"
   */
  @DefaultStringValue("Medium with SSD Storage (m3.medium)")
  @Key("m3_medium")
  String m3_medium();

  /**
   * Translated "Extra Large with SSD Storage (m3.xlarge)".
   * 
   * @return translated "Extra Large with SSD Storage (m3.xlarge)"
   */
  @DefaultStringValue("Extra Large with SSD Storage (m3.xlarge)")
  @Key("m3_xlarge")
  String m3_xlarge();

  /**
   * Translated "Message".
   * 
   * @return translated "Message"
   */
  @DefaultStringValue("Message")
  @Key("messageParameterLabelKey")
  String messageParameterLabelKey();

  /**
   * Translated "A message explaining the Alert.".
   * 
   * @return translated "A message explaining the Alert."
   */
  @DefaultStringValue("A message explaining the Alert.")
  @Key("messageParameterTooltipKey")
  String messageParameterTooltipKey();

  /**
   * Translated "Method".
   * 
   * @return translated "Method"
   */
  @DefaultStringValue("Method")
  @Key("methodParameterLabelKey")
  String methodParameterLabelKey();

  /**
   * Translated "The HTTP method to be used to perform the REST call. If GET is selected, the metrics parameter is ignored and only the query parameters specified in the URL will be sent. If POST is selected, depending on the \"post body content\" field selection, the rule triggering message will be forwarded or the metrics parameters will be used to compose an KapuaMessage and it will be sent as the body of the request.  ".
   * 
   * @return translated "The HTTP method to be used to perform the REST call. If GET is selected, the metrics parameter is ignored and only the query parameters specified in the URL will be sent. If POST is selected, depending on the \"post body content\" field selection, the rule triggering message will be forwarded or the metrics parameters will be used to compose an KapuaMessage and it will be sent as the body of the request.  "
   */
  @DefaultStringValue("The HTTP method to be used to perform the REST call. If GET is selected, the metrics parameter is ignored and only the query parameters specified in the URL will be sent. If POST is selected, depending on the \"post body content\" field selection, the rule triggering message will be forwarded or the metrics parameters will be used to compose an KapuaMessage and it will be sent as the body of the request.  ")
  @Key("methodParameterTooltipKey")
  String methodParameterTooltipKey();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultStringValue("Name")
  @Key("metricsNameParameterLabelKey")
  String metricsNameParameterLabelKey();

  /**
   * Translated "Custom message metrics".
   * 
   * @return translated "Custom message metrics"
   */
  @DefaultStringValue("Custom message metrics")
  @Key("metricsParameterLabelKey")
  String metricsParameterLabelKey();

  /**
   * Translated "Type".
   * 
   * @return translated "Type"
   */
  @DefaultStringValue("Type")
  @Key("metricsTypeParameterLabelKey")
  String metricsTypeParameterLabelKey();

  /**
   * Translated "Value".
   * 
   * @return translated "Value"
   */
  @DefaultStringValue("Value")
  @Key("metricsValueParameterLabelKey")
  String metricsValueParameterLabelKey();

  /**
   * Translated "ICCID".
   * 
   * @return translated "ICCID"
   */
  @DefaultStringValue("ICCID")
  @Key("modemIccid")
  String modemIccid();

  /**
   * Translated "IMEI".
   * 
   * @return translated "IMEI"
   */
  @DefaultStringValue("IMEI")
  @Key("modemImei")
  String modemImei();

  /**
   * Translated "IMSI".
   * 
   * @return translated "IMSI"
   */
  @DefaultStringValue("IMSI")
  @Key("modemImsi")
  String modemImsi();

  /**
   * Translated "Modem Information".
   * 
   * @return translated "Modem Information"
   */
  @DefaultStringValue("Modem Information")
  @Key("modemInfo")
  String modemInfo();

  /**
   * Translated "Modulus".
   * 
   * @return translated "Modulus"
   */
  @DefaultStringValue("Modulus")
  @Key("modulus")
  String modulus();

  /**
   * Translated "MQTT".
   * 
   * @return translated "MQTT"
   */
  @DefaultStringValue("MQTT")
  @Key("mqttRuleActionLabelKey")
  String mqttRuleActionLabelKey();

  /**
   * Translated "Health Check Mqtt Threshold (ms)".
   * 
   * @return translated "Health Check Mqtt Threshold (ms)"
   */
  @DefaultStringValue("Health Check Mqtt Threshold (ms)")
  @Key("mqttThreshold")
  String mqttThreshold();

  /**
   * Translated "Mutual Authentication SSL".
   * 
   * @return translated "Mutual Authentication SSL"
   */
  @DefaultStringValue("Mutual Authentication SSL")
  @Key("mutualSslConnection")
  String mutualSslConnection();

  /**
   * Translated "Name must be at least 3 characters and can contain alphanumeric characters combined with dash and/or underscore.".
   * 
   * @return translated "Name must be at least 3 characters and can contain alphanumeric characters combined with dash and/or underscore."
   */
  @DefaultStringValue("Name must be at least 3 characters and can contain alphanumeric characters combined with dash and/or underscore.")
  @Key("nameRegexMsg")
  String nameRegexMsg();

  /**
   * Translated "Name is required.".
   * 
   * @return translated "Name is required."
   */
  @DefaultStringValue("Name is required.")
  @Key("nameRequiredMsg")
  String nameRequiredMsg();

  /**
   * Translated "Must be at least 3 characters and can contain alphanumeric characters combined with dash and/or underscore.".
   * 
   * @return translated "Must be at least 3 characters and can contain alphanumeric characters combined with dash and/or underscore."
   */
  @DefaultStringValue("Must be at least 3 characters and can contain alphanumeric characters combined with dash and/or underscore.")
  @Key("nameToolTipMsg")
  String nameToolTipMsg();

  /**
   * Translated "Name must be at least 3 characters and can contain alphanumeric characters combined with dash, underscore and/or space.".
   * 
   * @return translated "Name must be at least 3 characters and can contain alphanumeric characters combined with dash, underscore and/or space."
   */
  @DefaultStringValue("Name must be at least 3 characters and can contain alphanumeric characters combined with dash, underscore and/or space.")
  @Key("name_spaceRegexMsg")
  String name_spaceRegexMsg();

  /**
   * Translated "Name is required.".
   * 
   * @return translated "Name is required."
   */
  @DefaultStringValue("Name is required.")
  @Key("name_spaceRequiredMsg")
  String name_spaceRequiredMsg();

  /**
   * Translated "Must be at least 3 characters and can contain alphanumeric characters combined with dash, underscore and/or space.".
   * 
   * @return translated "Must be at least 3 characters and can contain alphanumeric characters combined with dash, underscore and/or space."
   */
  @DefaultStringValue("Must be at least 3 characters and can contain alphanumeric characters combined with dash, underscore and/or space.")
  @Key("name_spaceToolTipMsg")
  String name_spaceToolTipMsg();

  /**
   * Translated "Name must be at least 3 characters and can contain alphanumeric characters combined with dash, underscore and/or space and/or colon.".
   * 
   * @return translated "Name must be at least 3 characters and can contain alphanumeric characters combined with dash, underscore and/or space and/or colon."
   */
  @DefaultStringValue("Name must be at least 3 characters and can contain alphanumeric characters combined with dash, underscore and/or space and/or colon.")
  @Key("name_space_colonRegexMsg")
  String name_space_colonRegexMsg();

  /**
   * Translated "Name is required.".
   * 
   * @return translated "Name is required."
   */
  @DefaultStringValue("Name is required.")
  @Key("name_space_colonRequiredMsg")
  String name_space_colonRequiredMsg();

  /**
   * Translated "Must be at least 3 characters and can contain alphanumeric characters combined with dash, underscore and/or space and/or colon.".
   * 
   * @return translated "Must be at least 3 characters and can contain alphanumeric characters combined with dash, underscore and/or space and/or colon."
   */
  @DefaultStringValue("Must be at least 3 characters and can contain alphanumeric characters combined with dash, underscore and/or space and/or colon.")
  @Key("name_space_colonToolTipMsg")
  String name_space_colonToolTipMsg();

  /**
   * Translated "Network Interface".
   * 
   * @return translated "Network Interface"
   */
  @DefaultStringValue("Network Interface")
  @Key("netConnIface")
  String netConnIface();

  /**
   * Translated "Network Interface IP Address".
   * 
   * @return translated "Network Interface IP Address"
   */
  @DefaultStringValue("Network Interface IP Address")
  @Key("netConnIfaceIp")
  String netConnIfaceIp();

  /**
   * Translated "Client IP Address".
   * 
   * @return translated "Client IP Address"
   */
  @DefaultStringValue("Client IP Address")
  @Key("netConnIp")
  String netConnIp();

  /**
   * Translated "Network Information".
   * 
   * @return translated "Network Information"
   */
  @DefaultStringValue("Network Information")
  @Key("netInfo")
  String netInfo();

  /**
   * Translated "None".
   * 
   * @return translated "None"
   */
  @DefaultStringValue("None")
  @Key("none")
  String none();

  /**
   * Translated "Double".
   * 
   * @return translated "Double"
   */
  @DefaultStringValue("Double")
  @Key("numberDouble")
  String numberDouble();

  /**
   * Translated "Double Tooltip".
   * 
   * @return translated "Double Tooltip"
   */
  @DefaultStringValue("Double Tooltip")
  @Key("numberDoubleTooltip")
  String numberDoubleTooltip();

  /**
   * Translated "Float".
   * 
   * @return translated "Float"
   */
  @DefaultStringValue("Float")
  @Key("numberFloat")
  String numberFloat();

  /**
   * Translated "Float Tooltip".
   * 
   * @return translated "Float Tooltip"
   */
  @DefaultStringValue("Float Tooltip")
  @Key("numberFloatTooltip")
  String numberFloatTooltip();

  /**
   * Translated "Integer".
   * 
   * @return translated "Integer"
   */
  @DefaultStringValue("Integer")
  @Key("numberInteger")
  String numberInteger();

  /**
   * Translated "Integer Tooltip".
   * 
   * @return translated "Integer Tooltip"
   */
  @DefaultStringValue("Integer Tooltip")
  @Key("numberIntegerTooltip")
  String numberIntegerTooltip();

  /**
   * Translated "Long".
   * 
   * @return translated "Long"
   */
  @DefaultStringValue("Long")
  @Key("numberLong")
  String numberLong();

  /**
   * Translated "Long Tooltip".
   * 
   * @return translated "Long Tooltip"
   */
  @DefaultStringValue("Long Tooltip")
  @Key("numberLongTooltip")
  String numberLongTooltip();

  /**
   * Translated "Number of Child".
   * 
   * @return translated "Number of Child"
   */
  @DefaultStringValue("Number of Child")
  @Key("numberOfChild")
  String numberOfChild();

  /**
   * Translated "Number of Devices".
   * 
   * @return translated "Number of Devices"
   */
  @DefaultStringValue("Number of Devices")
  @Key("numberOfDevices")
  String numberOfDevices();

  /**
   * Translated "Number of Rules".
   * 
   * @return translated "Number of Rules"
   */
  @DefaultStringValue("Number of Rules")
  @Key("numberOfRules")
  String numberOfRules();

  /**
   * Translated "Number of VPN Connections".
   * 
   * @return translated "Number of VPN Connections"
   */
  @DefaultStringValue("Number of VPN Connections")
  @Key("numberOfVpn")
  String numberOfVpn();

  /**
   * Translated "Numbers".
   * 
   * @return translated "Numbers"
   */
  @DefaultStringValue("Numbers")
  @Key("numbersParameterLabelKey")
  String numbersParameterLabelKey();

  /**
   * Translated "Comma-separated list of recipients' phone number. Acceptable phone numbers are: +14155551212, (415) 555-1212 or 415-555-1212. ".
   * 
   * @return translated "Comma-separated list of recipients' phone number. Acceptable phone numbers are: +14155551212, (415) 555-1212 or 415-555-1212. "
   */
  @DefaultStringValue("Comma-separated list of recipients' phone number. Acceptable phone numbers are: +14155551212, (415) 555-1212 or 415-555-1212. ")
  @Key("numbersParameterTooltipKey")
  String numbersParameterTooltipKey();

  /**
   * Translated "Address 1".
   * 
   * @return translated "Address 1"
   */
  @DefaultStringValue("Address 1")
  @Key("organizationAddress1")
  String organizationAddress1();

  /**
   * Translated "Address 2".
   * 
   * @return translated "Address 2"
   */
  @DefaultStringValue("Address 2")
  @Key("organizationAddress2")
  String organizationAddress2();

  /**
   * Translated "Address 3".
   * 
   * @return translated "Address 3"
   */
  @DefaultStringValue("Address 3")
  @Key("organizationAddress3")
  String organizationAddress3();

  /**
   * Translated "City".
   * 
   * @return translated "City"
   */
  @DefaultStringValue("City")
  @Key("organizationCity")
  String organizationCity();

  /**
   * Translated "Contact Name".
   * 
   * @return translated "Contact Name"
   */
  @DefaultStringValue("Contact Name")
  @Key("organizationContactName")
  String organizationContactName();

  /**
   * Translated "Country".
   * 
   * @return translated "Country"
   */
  @DefaultStringValue("Country")
  @Key("organizationCountry")
  String organizationCountry();

  /**
   * Translated "Email".
   * 
   * @return translated "Email"
   */
  @DefaultStringValue("Email")
  @Key("organizationEmail")
  String organizationEmail();

  /**
   * Translated "Organization Information".
   * 
   * @return translated "Organization Information"
   */
  @DefaultStringValue("Organization Information")
  @Key("organizationInfo")
  String organizationInfo();

  /**
   * Translated "Organization Name".
   * 
   * @return translated "Organization Name"
   */
  @DefaultStringValue("Organization Name")
  @Key("organizationName")
  String organizationName();

  /**
   * Translated "Phone Number".
   * 
   * @return translated "Phone Number"
   */
  @DefaultStringValue("Phone Number")
  @Key("organizationPhoneNumber")
  String organizationPhoneNumber();

  /**
   * Translated "State/Province".
   * 
   * @return translated "State/Province"
   */
  @DefaultStringValue("State/Province")
  @Key("organizationState")
  String organizationState();

  /**
   * Translated "Zip/Post Code".
   * 
   * @return translated "Zip/Post Code"
   */
  @DefaultStringValue("Zip/Post Code")
  @Key("organizationZip")
  String organizationZip();

  /**
   * Translated "Package version can contain alphanumeric characters combined with point and dash.".
   * 
   * @return translated "Package version can contain alphanumeric characters combined with point and dash."
   */
  @DefaultStringValue("Package version can contain alphanumeric characters combined with point and dash.")
  @Key("package_versionRegexMsg")
  String package_versionRegexMsg();

  /**
   * Translated "Password values do not match.".
   * 
   * @return translated "Password values do not match."
   */
  @DefaultStringValue("Password values do not match.")
  @Key("passwordDoesNotMatch")
  String passwordDoesNotMatch();

  /**
   * Translated "Password".
   * 
   * @return translated "Password"
   */
  @DefaultStringValue("Password")
  @Key("passwordParameterLabelKey")
  String passwordParameterLabelKey();

  /**
   * Translated "Password  to be used if the endpoint is protected by HTTP Basic Authentication.".
   * 
   * @return translated "Password  to be used if the endpoint is protected by HTTP Basic Authentication."
   */
  @DefaultStringValue("Password  to be used if the endpoint is protected by HTTP Basic Authentication.")
  @Key("passwordParameterTooltipKey")
  String passwordParameterTooltipKey();

  /**
   * Translated "Passwords must be {0} to 255 characters long and contain at least one lower case letter, one upper case letter, one digit and one special character. passwordToolTipMsg=Must be {0} to 255 characters long and contain at least one lower case letter, one upper case letter, one digit and one special character. Allowed special characters: # | '' ! \" £ $ % & @ / [ ] ( ) '{' '}' = ? ^ '' > < , ; . : - _ * + € ^ ` ~".
   * 
   * @return translated "Passwords must be {0} to 255 characters long and contain at least one lower case letter, one upper case letter, one digit and one special character. passwordToolTipMsg=Must be {0} to 255 characters long and contain at least one lower case letter, one upper case letter, one digit and one special character. Allowed special characters: # | '' ! \" £ $ % & @ / [ ] ( ) '{' '}' = ? ^ '' > < , ; . : - _ * + € ^ ` ~"
   */
  @DefaultStringValue("Passwords must be {0} to 255 characters long and contain at least one lower case letter, one upper case letter, one digit and one special character. passwordToolTipMsg=Must be {0} to 255 characters long and contain at least one lower case letter, one upper case letter, one digit and one special character. Allowed special characters: # | '' ! \" £ $ % & @ / [ ] ( ) '{' '}' = ? ^ '' > < , ; . : - _ * + € ^ ` ~")
  @Key("passwordRegexMsg")
  String passwordRegexMsg();

  /**
   * Translated "Password is required.".
   * 
   * @return translated "Password is required."
   */
  @DefaultStringValue("Password is required.")
  @Key("passwordRequiredMsg")
  String passwordRequiredMsg();

  /**
   * Translated "Must be {0} to 255 characters long and contain at least one lower case letter, one upper case letter, one digit and one special character.".
   * 
   * @return translated "Must be {0} to 255 characters long and contain at least one lower case letter, one upper case letter, one digit and one special character."
   */
  @DefaultStringValue("Must be {0} to 255 characters long and contain at least one lower case letter, one upper case letter, one digit and one special character.")
  @Key("passwordToolTipMsg")
  String passwordToolTipMsg();

  /**
   * Translated "Phone number contains invalid characters, multiple spaces at the beginning/between numbers or spaces at the end.".
   * 
   * @return translated "Phone number contains invalid characters, multiple spaces at the beginning/between numbers or spaces at the end."
   */
  @DefaultStringValue("Phone number contains invalid characters, multiple spaces at the beginning/between numbers or spaces at the end.")
  @Key("phoneRegexMsg")
  String phoneRegexMsg();

  /**
   * Translated "ESF Properties".
   * 
   * @return translated "ESF Properties"
   */
  @DefaultStringValue("ESF Properties")
  @Key("propsEsf")
  String propsEsf();

  /**
   * Translated "System Properties".
   * 
   * @return translated "System Properties"
   */
  @DefaultStringValue("System Properties")
  @Key("propsSys")
  String propsSys();

  /**
   * Translated "Protocol".
   * 
   * @return translated "Protocol"
   */
  @DefaultStringValue("Protocol")
  @Key("protocol")
  String protocol();

  /**
   * Translated "Active On".
   * 
   * @return translated "Active On"
   */
  @DefaultStringValue("Active On")
  @Key("provActivatesOn")
  String provActivatesOn();

  /**
   * Translated "Activation Key".
   * 
   * @return translated "Activation Key"
   */
  @DefaultStringValue("Activation Key")
  @Key("provActivationKey")
  String provActivationKey();

  /**
   * Translated "Target Client ID".
   * 
   * @return translated "Target Client ID"
   */
  @DefaultStringValue("Target Client ID")
  @Key("provClientId")
  String provClientId();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultStringValue("Created By")
  @Key("provCreatedBy")
  String provCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultStringValue("Created On")
  @Key("provCreatedOn")
  String provCreatedOn();

  /**
   * Translated "Provisioned Credentials Tight".
   * 
   * @return translated "Provisioned Credentials Tight"
   */
  @DefaultStringValue("Provisioned Credentials Tight")
  @Key("provCredentialsTight")
  String provCredentialsTight();

  /**
   * Translated "Expires On".
   * 
   * @return translated "Expires On"
   */
  @DefaultStringValue("Expires On")
  @Key("provExpiresOn")
  String provExpiresOn();

  /**
   * Translated "Provision Properties".
   * 
   * @return translated "Provision Properties"
   */
  @DefaultStringValue("Provision Properties")
  @Key("provProperties")
  String provProperties();

  /**
   * Translated "Provision Max Attempts".
   * 
   * @return translated "Provision Max Attempts"
   */
  @DefaultStringValue("Provision Max Attempts")
  @Key("provProvMaxAttempts")
  String provProvMaxAttempts();

  /**
   * Translated "Current Attempts".
   * 
   * @return translated "Current Attempts"
   */
  @DefaultStringValue("Current Attempts")
  @Key("provProvRetryCount")
  String provProvRetryCount();

  /**
   * Translated "Provision Status".
   * 
   * @return translated "Provision Status"
   */
  @DefaultStringValue("Provision Status")
  @Key("provProvStatus")
  String provProvStatus();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultStringValue("Status")
  @Key("provStatus")
  String provStatus();

  /**
   * Translated "Username".
   * 
   * @return translated "Username"
   */
  @DefaultStringValue("Username")
  @Key("provUsername")
  String provUsername();

  /**
   * Translated "Provision Request Info".
   * 
   * @return translated "Provision Request Info"
   */
  @DefaultStringValue("Provision Request Info")
  @Key("provisionInfo")
  String provisionInfo();

  /**
   * Translated "Public Key Informations".
   * 
   * @return translated "Public Key Informations"
   */
  @DefaultStringValue("Public Key Informations")
  @Key("publicKeyInfo")
  String publicKeyInfo();

  /**
   * Translated "Memory Optimized 2-Extra Large (r3.2xlarge)".
   * 
   * @return translated "Memory Optimized 2-Extra Large (r3.2xlarge)"
   */
  @DefaultStringValue("Memory Optimized 2-Extra Large (r3.2xlarge)")
  @Key("r3.2xlarge")
  String r3_2xlarge();

  /**
   * Translated "Memory Optimized 4-Extra Large (r3.4xlarge)".
   * 
   * @return translated "Memory Optimized 4-Extra Large (r3.4xlarge)"
   */
  @DefaultStringValue("Memory Optimized 4-Extra Large (r3.4xlarge)")
  @Key("r3.4xlarge")
  String r3_4xlarge();

  /**
   * Translated "Memory Optimized 8-Extra Large (r3.8xlarge)".
   * 
   * @return translated "Memory Optimized 8-Extra Large (r3.8xlarge)"
   */
  @DefaultStringValue("Memory Optimized 8-Extra Large (r3.8xlarge)")
  @Key("r3.8xlarge")
  String r3_8xlarge();

  /**
   * Translated "Memory Optimized Large (r3.large)".
   * 
   * @return translated "Memory Optimized Large (r3.large)"
   */
  @DefaultStringValue("Memory Optimized Large (r3.large)")
  @Key("r3.large")
  String r3_large();

  /**
   * Translated "Memory Optimized Extra Large (r3.xlarge)".
   * 
   * @return translated "Memory Optimized Extra Large (r3.xlarge)"
   */
  @DefaultStringValue("Memory Optimized Extra Large (r3.xlarge)")
  @Key("r3.xlarge")
  String r3_xlarge();

  /**
   * Translated "Health Rest Command Threshold (ms)".
   * 
   * @return translated "Health Rest Command Threshold (ms)"
   */
  @DefaultStringValue("Health Rest Command Threshold (ms)")
  @Key("restCommandThreshold")
  String restCommandThreshold();

  /**
   * Translated "REST".
   * 
   * @return translated "REST"
   */
  @DefaultStringValue("REST")
  @Key("restRuleActionLabelKey")
  String restRuleActionLabelKey();

  /**
   * Translated "Health Check Rest Threshold (ms)".
   * 
   * @return translated "Health Check Rest Threshold (ms)"
   */
  @DefaultStringValue("Health Check Rest Threshold (ms)")
  @Key("restThreshold")
  String restThreshold();

  /**
   * Translated "Either a Retry interval or a Cron expression must be specified".
   * 
   * @return translated "Either a Retry interval or a Cron expression must be specified"
   */
  @DefaultStringValue("Either a Retry interval or a Cron expression must be specified")
  @Key("retryIntervalOrCronRequired")
  String retryIntervalOrCronRequired();

  /**
   * Translated "Rich Text".
   * 
   * @return translated "Rich Text"
   */
  @DefaultStringValue("Rich Text")
  @Key("richText")
  String richText();

  /**
   * Translated "Rich Text Tooltip".
   * 
   * @return translated "Rich Text Tooltip"
   */
  @DefaultStringValue("Rich Text Tooltip")
  @Key("richTextTooltip")
  String richTextTooltip();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultStringValue("Created By")
  @Key("roleCreatedBy")
  String roleCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultStringValue("Created On")
  @Key("roleCreatedOn")
  String roleCreatedOn();

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultStringValue("Description")
  @Key("roleDescription")
  String roleDescription();

  /**
   * Translated "Role".
   * 
   * @return translated "Role"
   */
  @DefaultStringValue("Role")
  @Key("roleInfo")
  String roleInfo();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultStringValue("Modified By")
  @Key("roleModifiedBy")
  String roleModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultStringValue("Modified On")
  @Key("roleModifiedOn")
  String roleModifiedOn();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultStringValue("Name")
  @Key("roleName")
  String roleName();

  /**
   * Translated "Service Plan Information".
   * 
   * @return translated "Service Plan Information"
   */
  @DefaultStringValue("Service Plan Information")
  @Key("servicePlanInfo")
  String servicePlanInfo();

  /**
   * Translated "Severity".
   * 
   * @return translated "Severity"
   */
  @DefaultStringValue("Severity")
  @Key("severityParameterLabelKey")
  String severityParameterLabelKey();

  /**
   * Translated "Must be 'CRITICAL' or 'WARNING' or 'INFO'.".
   * 
   * @return translated "Must be 'CRITICAL' or 'WARNING' or 'INFO'."
   */
  @DefaultStringValue("Must be 'CRITICAL' or 'WARNING' or 'INFO'.")
  @Key("severityParameterTooltipKey")
  String severityParameterTooltipKey();

  /**
   * Translated "Simple (No SSL)".
   * 
   * @return translated "Simple (No SSL)"
   */
  @DefaultStringValue("Simple (No SSL)")
  @Key("simpleConnection")
  String simpleConnection();

  /**
   * Translated "Name must be at least 3 characters and can contain alphanumeric characters combined with dash.".
   * 
   * @return translated "Name must be at least 3 characters and can contain alphanumeric characters combined with dash."
   */
  @DefaultStringValue("Name must be at least 3 characters and can contain alphanumeric characters combined with dash.")
  @Key("simple_nameRegexMsg")
  String simple_nameRegexMsg();

  /**
   * Translated "Name is required.".
   * 
   * @return translated "Name is required."
   */
  @DefaultStringValue("Name is required.")
  @Key("simple_nameRequiredMsg")
  String simple_nameRequiredMsg();

  /**
   * Translated "Must be at least 3 characters and can contain alphanumeric characters combined with dash.".
   * 
   * @return translated "Must be at least 3 characters and can contain alphanumeric characters combined with dash."
   */
  @DefaultStringValue("Must be at least 3 characters and can contain alphanumeric characters combined with dash.")
  @Key("simple_nameToolTipMsg")
  String simple_nameToolTipMsg();

  /**
   * Translated "Twilio SMS".
   * 
   * @return translated "Twilio SMS"
   */
  @DefaultStringValue("Twilio SMS")
  @Key("smsRuleActionLabelKey")
  String smsRuleActionLabelKey();

  /**
   * Translated "Seeded Snapshot".
   * 
   * @return translated "Seeded Snapshot"
   */
  @DefaultStringValue("Seeded Snapshot")
  @Key("snapSeeded")
  String snapSeeded();

  /**
   * Translated "Only files with .xml extension are allowed. Name can contain only alphanumeric characters combined with dash and/or underscore.".
   * 
   * @return translated "Only files with .xml extension are allowed. Name can contain only alphanumeric characters combined with dash and/or underscore."
   */
  @DefaultStringValue("Only files with .xml extension are allowed. Name can contain only alphanumeric characters combined with dash and/or underscore.")
  @Key("snapshot_fileRegexMsg")
  String snapshot_fileRegexMsg();

  /**
   * Translated "Server Authentication SSL".
   * 
   * @return translated "Server Authentication SSL"
   */
  @DefaultStringValue("Server Authentication SSL")
  @Key("sslConnection")
  String sslConnection();

  /**
   * Translated "Start Date field is required".
   * 
   * @return translated "Start Date field is required"
   */
  @DefaultStringValue("Start Date field is required")
  @Key("startDateEmpty")
  String startDateEmpty();

  /**
   * Translated "The date in this files must be today or after.".
   * 
   * @return translated "The date in this files must be today or after."
   */
  @DefaultStringValue("The date in this files must be today or after.")
  @Key("startDateMinValue")
  String startDateMinValue();

  /**
   * Translated "No start time specified with start date, or time not in 15 minutes interval".
   * 
   * @return translated "No start time specified with start date, or time not in 15 minutes interval"
   */
  @DefaultStringValue("No start time specified with start date, or time not in 15 minutes interval")
  @Key("startDateWithoutStartTime")
  String startDateWithoutStartTime();

  /**
   * Translated "Start Time field is required".
   * 
   * @return translated "Start Time field is required"
   */
  @DefaultStringValue("Start Time field is required")
  @Key("startTimeEmpty")
  String startTimeEmpty();

  /**
   * Translated "No start date specified with start time".
   * 
   * @return translated "No start date specified with start time"
   */
  @DefaultStringValue("No start date specified with start time")
  @Key("startTimeWithoutStartDate")
  String startTimeWithoutStartDate();

  /**
   * Translated "The start date cannot be later than the end date".
   * 
   * @return translated "The start date cannot be later than the end date"
   */
  @DefaultStringValue("The start date cannot be later than the end date")
  @Key("startsOnDateLaterThanEndsOn")
  String startsOnDateLaterThanEndsOn();

  /**
   * Translated "The start time cannot be later than the end time".
   * 
   * @return translated "The start time cannot be later than the end time"
   */
  @DefaultStringValue("The start time cannot be later than the end time")
  @Key("startsOnTimeLaterThanEndsOn")
  String startsOnTimeLaterThanEndsOn();

  /**
   * Translated "Subject".
   * 
   * @return translated "Subject"
   */
  @DefaultStringValue("Subject")
  @Key("subjectParameterLabelKey")
  String subjectParameterLabelKey();

  /**
   * Translated "Email Subject".
   * 
   * @return translated "Email Subject"
   */
  @DefaultStringValue("Email Subject")
  @Key("subjectParameterTooltipKey")
  String subjectParameterTooltipKey();

  /**
   * Translated "Micro (t1.micro)".
   * 
   * @return translated "Micro (t1.micro)"
   */
  @DefaultStringValue("Micro (t1.micro)")
  @Key("t1_micro")
  String t1_micro();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultStringValue("Created By")
  @Key("tagCreatedBy")
  String tagCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultStringValue("Created On")
  @Key("tagCreatedOn")
  String tagCreatedOn();

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultStringValue("Description")
  @Key("tagDescription")
  String tagDescription();

  /**
   * Translated "Tag".
   * 
   * @return translated "Tag"
   */
  @DefaultStringValue("Tag")
  @Key("tagInfo")
  String tagInfo();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultStringValue("Modified By")
  @Key("tagModifiedBy")
  String tagModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultStringValue("Modified On")
  @Key("tagModifiedOn")
  String tagModifiedOn();

  /**
   * Translated "Tag Name".
   * 
   * @return translated "Tag Name"
   */
  @DefaultStringValue("Tag Name")
  @Key("tagName")
  String tagName();

  /**
   * Translated "Tag".
   * 
   * @return translated "Tag"
   */
  @DefaultStringValue("Tag")
  @Key("tagParameterLabelKey")
  String tagParameterLabelKey();

  /**
   * Translated "Hashtag # prepended to the subject that will fire the IFTTT trigger (example: ).".
   * 
   * @return translated "Hashtag # prepended to the subject that will fire the IFTTT trigger (example: )."
   */
  @DefaultStringValue("Hashtag # prepended to the subject that will fire the IFTTT trigger (example: ).")
  @Key("tagParameterTooltipKey")
  String tagParameterTooltipKey();

  /**
   * Translated "Testing".
   * 
   * @return translated "Testing"
   */
  @DefaultStringValue("Testing")
  @Key("testRuleActionLabelKey")
  String testRuleActionLabelKey();

  /**
   * Translated "Text".
   * 
   * @return translated "Text"
   */
  @DefaultStringValue("Text")
  @Key("text")
  String text();

  /**
   * Translated "Text".
   * 
   * @return translated "Text"
   */
  @DefaultStringValue("Text")
  @Key("textParameterLabelKey")
  String textParameterLabelKey();

  /**
   * Translated "Text Tooltip".
   * 
   * @return translated "Text Tooltip"
   */
  @DefaultStringValue("Text Tooltip")
  @Key("textTooltip")
  String textTooltip();

  /**
   * Translated "Time".
   * 
   * @return translated "Time"
   */
  @DefaultStringValue("Time")
  @Key("time")
  String time();

  /**
   * Translated "Time".
   * 
   * @return translated "Time"
   */
  @DefaultStringValue("Time")
  @Key("timeParameterLabelKey")
  String timeParameterLabelKey();

  /**
   * Translated "Time Tooltip".
   * 
   * @return translated "Time Tooltip"
   */
  @DefaultStringValue("Time Tooltip")
  @Key("timeTooltip")
  String timeTooltip();

  /**
   * Translated "To".
   * 
   * @return translated "To"
   */
  @DefaultStringValue("To")
  @Key("toParameterLabelKey")
  String toParameterLabelKey();

  /**
   * Translated "Recipient should be in the format of username@domain.com. Comma is used to separate multiple recipients. An alternative format is $emailTo.".
   * 
   * @return translated "Recipient should be in the format of username@domain.com. Comma is used to separate multiple recipients. An alternative format is $emailTo."
   */
  @DefaultStringValue("Recipient should be in the format of username@domain.com. Comma is used to separate multiple recipients. An alternative format is $emailTo.")
  @Key("toParameterRegexKey")
  String toParameterRegexKey();

  /**
   * Translated "Comma-separated list of recipients' email address or $emailTo.".
   * 
   * @return translated "Comma-separated list of recipients' email address or $emailTo."
   */
  @DefaultStringValue("Comma-separated list of recipients' email address or $emailTo.")
  @Key("toParameterTooltipKey")
  String toParameterTooltipKey();

  /**
   * Translated "Topic".
   * 
   * @return translated "Topic"
   */
  @DefaultStringValue("Topic")
  @Key("topicParameterLabelKey")
  String topicParameterLabelKey();

  /**
   * Translated "Total Data Usage (MB/m)".
   * 
   * @return translated "Total Data Usage (MB/m)"
   */
  @DefaultStringValue("Total Data Usage (MB/m)")
  @Key("totalDataUsage")
  String totalDataUsage();

  /**
   * Translated "TTL".
   * 
   * @return translated "TTL"
   */
  @DefaultStringValue("TTL")
  @Key("ttl")
  String ttl();

  /**
   * Translated "Twitter".
   * 
   * @return translated "Twitter"
   */
  @DefaultStringValue("Twitter")
  @Key("twitterRuleActionLabelKey")
  String twitterRuleActionLabelKey();

  /**
   * Translated "Type".
   * 
   * @return translated "Type"
   */
  @DefaultStringValue("Type")
  @Key("type")
  String type();

  /**
   * Translated "Url".
   * 
   * @return translated "Url"
   */
  @DefaultStringValue("Url")
  @Key("urlParameterLabelKey")
  String urlParameterLabelKey();

  /**
   * Translated "Invalid URL syntax.".
   * 
   * @return translated "Invalid URL syntax."
   */
  @DefaultStringValue("Invalid URL syntax.")
  @Key("urlParameterRegexKey")
  String urlParameterRegexKey();

  /**
   * Translated "The URL of the endpoint to be invoked. HTTP/HTTPs are the allowed schemes; for HTTPs, the endpoint should use a certificate signed a trusted authorized recognized by default by Java. The URL can contain query parameters and it can be parametrized using the names of the tokens selected in the Rule's statement.".
   * 
   * @return translated "The URL of the endpoint to be invoked. HTTP/HTTPs are the allowed schemes; for HTTPs, the endpoint should use a certificate signed a trusted authorized recognized by default by Java. The URL can contain query parameters and it can be parametrized using the names of the tokens selected in the Rule's statement."
   */
  @DefaultStringValue("The URL of the endpoint to be invoked. HTTP/HTTPs are the allowed schemes; for HTTPs, the endpoint should use a certificate signed a trusted authorized recognized by default by Java. The URL can contain query parameters and it can be parametrized using the names of the tokens selected in the Rule's statement.")
  @Key("urlParameterTooltipKey")
  String urlParameterTooltipKey();

  /**
   * Translated "Illegal characters in package URL path. Please check the field and try again.".
   * 
   * @return translated "Illegal characters in package URL path. Please check the field and try again."
   */
  @DefaultStringValue("Illegal characters in package URL path. Please check the field and try again.")
  @Key("urlRegexMsg")
  String urlRegexMsg();

  /**
   * Translated "us-east-1a".
   * 
   * @return translated "us-east-1a"
   */
  @DefaultStringValue("us-east-1a")
  @Key("us_east_1a")
  String us_east_1a();

  /**
   * Translated "us-east-1b".
   * 
   * @return translated "us-east-1b"
   */
  @DefaultStringValue("us-east-1b")
  @Key("us_east_1b")
  String us_east_1b();

  /**
   * Translated "us-east-1c".
   * 
   * @return translated "us-east-1c"
   */
  @DefaultStringValue("us-east-1c")
  @Key("us_east_1c")
  String us_east_1c();

  /**
   * Translated "us-east-1d".
   * 
   * @return translated "us-east-1d"
   */
  @DefaultStringValue("us-east-1d")
  @Key("us_east_1d")
  String us_east_1d();

  /**
   * Translated "us-east-1e".
   * 
   * @return translated "us-east-1e"
   */
  @DefaultStringValue("us-east-1e")
  @Key("us_east_1e")
  String us_east_1e();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultStringValue("Created By")
  @Key("userCreatedBy")
  String userCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultStringValue("Created On")
  @Key("userCreatedOn")
  String userCreatedOn();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultStringValue("Display Name")
  @Key("userDisplayName")
  String userDisplayName();

  /**
   * Translated "E-mail".
   * 
   * @return translated "E-mail"
   */
  @DefaultStringValue("E-mail")
  @Key("userEmail")
  String userEmail();

  /**
   * Translated "Expiration Date".
   * 
   * @return translated "Expiration Date"
   */
  @DefaultStringValue("Expiration Date")
  @Key("userExpirationDate")
  String userExpirationDate();

  /**
   * Translated "External Id".
   * 
   * @return translated "External Id"
   */
  @DefaultStringValue("External Id")
  @Key("userExternalId")
  String userExternalId();

  /**
   * Translated "External Username".
   * 
   * @return translated "External Username"
   */
  @DefaultStringValue("External Username")
  @Key("userExternalUsername")
  String userExternalUsername();

  /**
   * Translated "User ID".
   * 
   * @return translated "User ID"
   */
  @DefaultStringValue("User ID")
  @Key("userId")
  String userId();

  /**
   * Translated "User".
   * 
   * @return translated "User"
   */
  @DefaultStringValue("User")
  @Key("userInfo")
  String userInfo();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultStringValue("Modified By")
  @Key("userModifiedBy")
  String userModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultStringValue("Modified On")
  @Key("userModifiedOn")
  String userModifiedOn();

  /**
   * Translated "User Name".
   * 
   * @return translated "User Name"
   */
  @DefaultStringValue("User Name")
  @Key("userName")
  String userName();

  /**
   * Translated "Phone Number".
   * 
   * @return translated "Phone Number"
   */
  @DefaultStringValue("Phone Number")
  @Key("userPhoneNumber")
  String userPhoneNumber();

  /**
   * Translated "Reserved For Connection".
   * 
   * @return translated "Reserved For Connection"
   */
  @DefaultStringValue("Reserved For Connection")
  @Key("userReservedConnection")
  String userReservedConnection();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultStringValue("Status")
  @Key("userStatus")
  String userStatus();

  /**
   * Translated "User Type".
   * 
   * @return translated "User Type"
   */
  @DefaultStringValue("User Type")
  @Key("userType")
  String userType();

  /**
   * Translated "Username".
   * 
   * @return translated "Username"
   */
  @DefaultStringValue("Username")
  @Key("usernameParameterLabelKey")
  String usernameParameterLabelKey();

  /**
   * Translated "Username to be used if the endpoint is protected by HTTP Basic Authentication. ".
   * 
   * @return translated "Username to be used if the endpoint is protected by HTTP Basic Authentication. "
   */
  @DefaultStringValue("Username to be used if the endpoint is protected by HTTP Basic Authentication. ")
  @Key("usernameParameterTooltipKey")
  String usernameParameterTooltipKey();
}
