package org.eclipse.kapua.app.console.module.api.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/api/src/main/resources/org/eclipse/kapua/app/console/module/api/client/messages/ConsoleMessages.properties'.
 */
public interface ConsoleMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "Entity Tab labels".
   * 
   * @return translated "Entity Tab labels"
   */
  @DefaultMessage("Entity Tab labels")
  @Key("#")
  String _();

  /**
   * Translated "About".
   * 
   * @return translated "About"
   */
  @DefaultMessage("About")
  @Key("about")
  String about();

  /**
   * Translated "Account successfully created.".
   * 
   * @return translated "Account successfully created."
   */
  @DefaultMessage("Account successfully created.")
  @Key("accountCreatedConfirmation")
  String accountCreatedConfirmation();

  /**
   * Translated "Are you sure you want to delete account {0}?".
   * 
   * @return translated "Are you sure you want to delete account {0}?"
   */
  @DefaultMessage("Are you sure you want to delete account {0}?")
  @Key("accountDeleteConfirmation")
  String accountDeleteConfirmation(String arg0);

  /**
   * Translated "Account successfully deleted.".
   * 
   * @return translated "Account successfully deleted."
   */
  @DefaultMessage("Account successfully deleted.")
  @Key("accountDeletedConfirmation")
  String accountDeletedConfirmation();

  /**
   * Translated "Administrator Email".
   * 
   * @return translated "Administrator Email"
   */
  @DefaultMessage("Administrator Email")
  @Key("accountFormAdminEmail")
  String accountFormAdminEmail();

  /**
   * Translated "Administrator Information".
   * 
   * @return translated "Administrator Information"
   */
  @DefaultMessage("Administrator Information")
  @Key("accountFormAdminInformation")
  String accountFormAdminInformation();

  /**
   * Translated "Administrator Username".
   * 
   * @return translated "Administrator Username"
   */
  @DefaultMessage("Administrator Username")
  @Key("accountFormAdminUser")
  String accountFormAdminUser();

  /**
   * Translated "Device Connection Modes".
   * 
   * @return translated "Device Connection Modes"
   */
  @DefaultMessage("Device Connection Modes")
  @Key("accountFormAdmittedConnectionsInformation")
  String accountFormAdmittedConnectionsInformation();

  /**
   * Translated "Broker".
   * 
   * @return translated "Broker"
   */
  @DefaultMessage("Broker")
  @Key("accountFormBroker")
  String accountFormBroker();

  /**
   * Translated "Broker Cluster".
   * 
   * @return translated "Broker Cluster"
   */
  @DefaultMessage("Broker Cluster")
  @Key("accountFormBrokerCluster")
  String accountFormBrokerCluster();

  /**
   * Translated "Broker URL".
   * 
   * @return translated "Broker URL"
   */
  @DefaultMessage("Broker URL")
  @Key("accountFormBrokerDNS")
  String accountFormBrokerDNS();

  /**
   * Translated "Broker Host".
   * 
   * @return translated "Broker Host"
   */
  @DefaultMessage("Broker Host")
  @Key("accountFormBrokerHost")
  String accountFormBrokerHost();

  /**
   * Translated "Broker Image Name".
   * 
   * @return translated "Broker Image Name"
   */
  @DefaultMessage("Broker Image Name")
  @Key("accountFormBrokerImageName")
  String accountFormBrokerImageName();

  /**
   * Translated "Broker Information".
   * 
   * @return translated "Broker Information"
   */
  @DefaultMessage("Broker Information")
  @Key("accountFormBrokerInformation")
  String accountFormBrokerInformation();

  /**
   * Translated "Broker Type".
   * 
   * @return translated "Broker Type"
   */
  @DefaultMessage("Broker Type")
  @Key("accountFormBrokerType")
  String accountFormBrokerType();

  /**
   * Translated "This account cannot have child accounts".
   * 
   * @return translated "This account cannot have child accounts"
   */
  @DefaultMessage("This account cannot have child accounts")
  @Key("accountFormButtonChildCreationDisabled")
  String accountFormButtonChildCreationDisabled();

  /**
   * Translated "Confirm Password".
   * 
   * @return translated "Confirm Password"
   */
  @DefaultMessage("Confirm Password")
  @Key("accountFormConfirmPassword")
  String accountFormConfirmPassword();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultMessage("Created By")
  @Key("accountFormCreatedBy")
  String accountFormCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("accountFormCreatedOn")
  String accountFormCreatedOn();

  /**
   * Translated "Deployment Information".
   * 
   * @return translated "Deployment Information"
   */
  @DefaultMessage("Deployment Information")
  @Key("accountFormDeploymentInformation")
  String accountFormDeploymentInformation();

  /**
   * Translated "EC2 Availability Zone".
   * 
   * @return translated "EC2 Availability Zone"
   */
  @DefaultMessage("EC2 Availability Zone")
  @Key("accountFormEc2AvailabilityZone")
  String accountFormEc2AvailabilityZone();

  /**
   * Translated "EC2 Instance Type".
   * 
   * @return translated "EC2 Instance Type"
   */
  @DefaultMessage("EC2 Instance Type")
  @Key("accountFormEc2InstanceType")
  String accountFormEc2InstanceType();

  /**
   * Translated "Account Information".
   * 
   * @return translated "Account Information"
   */
  @DefaultMessage("Account Information")
  @Key("accountFormInformation")
  String accountFormInformation();

  /**
   * Translated "Lockout Policy".
   * 
   * @return translated "Lockout Policy"
   */
  @DefaultMessage("Lockout Policy")
  @Key("accountFormLockoutPolicy")
  String accountFormLockoutPolicy();

  /**
   * Translated "Attempts Reset After (seconds)".
   * 
   * @return translated "Attempts Reset After (seconds)"
   */
  @DefaultMessage("Attempts Reset After (seconds)")
  @Key("accountFormLockoutPolicyAttemptsResetAfter")
  String accountFormLockoutPolicyAttemptsResetAfter();

  /**
   * Translated "Set the time in seconds to reset login attempts counter.".
   * 
   * @return translated "Set the time in seconds to reset login attempts counter."
   */
  @DefaultMessage("Set the time in seconds to reset login attempts counter.")
  @Key("accountFormLockoutPolicyAttemptsResetAfterTooltip")
  String accountFormLockoutPolicyAttemptsResetAfterTooltip();

  /**
   * Translated "Lockout Policy Information".
   * 
   * @return translated "Lockout Policy Information"
   */
  @DefaultMessage("Lockout Policy Information")
  @Key("accountFormLockoutPolicyInformation")
  String accountFormLockoutPolicyInformation();

  /**
   * Translated "Lock Duration (seconds)".
   * 
   * @return translated "Lock Duration (seconds)"
   */
  @DefaultMessage("Lock Duration (seconds)")
  @Key("accountFormLockoutPolicyLockDuration")
  String accountFormLockoutPolicyLockDuration();

  /**
   * Translated "Set the time in seconds to lock a user after reaching the maximum number of attempts.".
   * 
   * @return translated "Set the time in seconds to lock a user after reaching the maximum number of attempts."
   */
  @DefaultMessage("Set the time in seconds to lock a user after reaching the maximum number of attempts.")
  @Key("accountFormLockoutPolicyLockDurationTooltip")
  String accountFormLockoutPolicyLockDurationTooltip();

  /**
   * Translated "Max number of attempts".
   * 
   * @return translated "Max number of attempts"
   */
  @DefaultMessage("Max number of attempts")
  @Key("accountFormLockoutPolicyMaxAttempts")
  String accountFormLockoutPolicyMaxAttempts();

  /**
   * Translated "Set the max number of attempted login before locking the account.".
   * 
   * @return translated "Set the max number of attempted login before locking the account."
   */
  @DefaultMessage("Set the max number of attempted login before locking the account.")
  @Key("accountFormLockoutPolicyMaxAttemptsTooltip")
  String accountFormLockoutPolicyMaxAttemptsTooltip();

  /**
   * Translated "Set whether an account has or not the lockout policy feature enabled.".
   * 
   * @return translated "Set whether an account has or not the lockout policy feature enabled."
   */
  @DefaultMessage("Set whether an account has or not the lockout policy feature enabled.")
  @Key("accountFormLockoutPolicyTooltip")
  String accountFormLockoutPolicyTooltip();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultMessage("Modified By")
  @Key("accountFormModifiedBy")
  String accountFormModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultMessage("Modified On")
  @Key("accountFormModifiedOn")
  String accountFormModifiedOn();

  /**
   * Translated "Mutual Authentication TLS/SSL".
   * 
   * @return translated "Mutual Authentication TLS/SSL"
   */
  @DefaultMessage("Mutual Authentication TLS/SSL")
  @Key("accountFormMutualSSL")
  String accountFormMutualSSL();

  /**
   * Translated "Disable device/broker mutual authentication using TLS/SSL".
   * 
   * @return translated "Disable device/broker mutual authentication using TLS/SSL"
   */
  @DefaultMessage("Disable device/broker mutual authentication using TLS/SSL")
  @Key("accountFormMutualSSLDisabledRadioTooltip")
  String accountFormMutualSSLDisabledRadioTooltip();

  /**
   * Translated "Enable device/broker mutual authentication using TLS/SSL".
   * 
   * @return translated "Enable device/broker mutual authentication using TLS/SSL"
   */
  @DefaultMessage("Enable device/broker mutual authentication using TLS/SSL")
  @Key("accountFormMutualSSLEnabledRadioTooltip")
  String accountFormMutualSSLEnabledRadioTooltip();

  /**
   * Translated "If Mutual Authentication TLS/SSL is enabled, visit the Device Certificates section to add the proper device certificates".
   * 
   * @return translated "If Mutual Authentication TLS/SSL is enabled, visit the Device Certificates section to add the proper device certificates"
   */
  @DefaultMessage("If Mutual Authentication TLS/SSL is enabled, visit the Device Certificates section to add the proper device certificates")
  @Key("accountFormMutualSSLExplanation")
  String accountFormMutualSSLExplanation();

  /**
   * Translated "Account Name".
   * 
   * @return translated "Account Name"
   */
  @DefaultMessage("Account Name")
  @Key("accountFormName")
  String accountFormName();

  /**
   * Translated "New Account".
   * 
   * @return translated "New Account"
   */
  @DefaultMessage("New Account")
  @Key("accountFormNew")
  String accountFormNew();

  /**
   * Translated "No TLS/SSL".
   * 
   * @return translated "No TLS/SSL"
   */
  @DefaultMessage("No TLS/SSL")
  @Key("accountFormNoSSL")
  String accountFormNoSSL();

  /**
   * Translated "Prevent the device to connect using unencrypted connection".
   * 
   * @return translated "Prevent the device to connect using unencrypted connection"
   */
  @DefaultMessage("Prevent the device to connect using unencrypted connection")
  @Key("accountFormNoSSLDisabledRadioTooltip")
  String accountFormNoSSLDisabledRadioTooltip();

  /**
   * Translated "Allows the device to connect using unencrypted connection".
   * 
   * @return translated "Allows the device to connect using unencrypted connection"
   */
  @DefaultMessage("Allows the device to connect using unencrypted connection")
  @Key("accountFormNoSSLEnabledRadioTooltip")
  String accountFormNoSSLEnabledRadioTooltip();

  /**
   * Translated "Address 1".
   * 
   * @return translated "Address 1"
   */
  @DefaultMessage("Address 1")
  @Key("accountFormOrgAddress1")
  String accountFormOrgAddress1();

  /**
   * Translated "Address 2".
   * 
   * @return translated "Address 2"
   */
  @DefaultMessage("Address 2")
  @Key("accountFormOrgAddress2")
  String accountFormOrgAddress2();

  /**
   * Translated "Address 3".
   * 
   * @return translated "Address 3"
   */
  @DefaultMessage("Address 3")
  @Key("accountFormOrgAddress3")
  String accountFormOrgAddress3();

  /**
   * Translated "City".
   * 
   * @return translated "City"
   */
  @DefaultMessage("City")
  @Key("accountFormOrgCity")
  String accountFormOrgCity();

  /**
   * Translated "Country".
   * 
   * @return translated "Country"
   */
  @DefaultMessage("Country")
  @Key("accountFormOrgCountry")
  String accountFormOrgCountry();

  /**
   * Translated "Email".
   * 
   * @return translated "Email"
   */
  @DefaultMessage("Email")
  @Key("accountFormOrgEmail")
  String accountFormOrgEmail();

  /**
   * Translated "Organization Information".
   * 
   * @return translated "Organization Information"
   */
  @DefaultMessage("Organization Information")
  @Key("accountFormOrgInformation")
  String accountFormOrgInformation();

  /**
   * Translated "More Information".
   * 
   * @return translated "More Information"
   */
  @DefaultMessage("More Information")
  @Key("accountFormOrgMoreInformation")
  String accountFormOrgMoreInformation();

  /**
   * Translated "Organization Name".
   * 
   * @return translated "Organization Name"
   */
  @DefaultMessage("Organization Name")
  @Key("accountFormOrgName")
  String accountFormOrgName();

  /**
   * Translated "Reference Person".
   * 
   * @return translated "Reference Person"
   */
  @DefaultMessage("Reference Person")
  @Key("accountFormOrgPersonName")
  String accountFormOrgPersonName();

  /**
   * Translated "Phone Number".
   * 
   * @return translated "Phone Number"
   */
  @DefaultMessage("Phone Number")
  @Key("accountFormOrgPhoneNumber")
  String accountFormOrgPhoneNumber();

  /**
   * Translated "State/Province".
   * 
   * @return translated "State/Province"
   */
  @DefaultMessage("State/Province")
  @Key("accountFormOrgState")
  String accountFormOrgState();

  /**
   * Translated "Zip/Post Code".
   * 
   * @return translated "Zip/Post Code"
   */
  @DefaultMessage("Zip/Post Code")
  @Key("accountFormOrgZipPostCode")
  String accountFormOrgZipPostCode();

  /**
   * Translated "Parent Account".
   * 
   * @return translated "Parent Account"
   */
  @DefaultMessage("Parent Account")
  @Key("accountFormParentAccount")
  String accountFormParentAccount();

  /**
   * Translated "Account Password".
   * 
   * @return translated "Account Password"
   */
  @DefaultMessage("Account Password")
  @Key("accountFormPassword")
  String accountFormPassword();

  /**
   * Translated "Provisioning Status".
   * 
   * @return translated "Provisioning Status"
   */
  @DefaultMessage("Provisioning Status")
  @Key("accountFormProvisioningStatus")
  String accountFormProvisioningStatus();

  /**
   * Translated "Rules Assistant Instance".
   * 
   * @return translated "Rules Assistant Instance"
   */
  @DefaultMessage("Rules Assistant Instance")
  @Key("accountFormRuleAssistantInstance")
  String accountFormRuleAssistantInstance();

  /**
   * Translated "Server Authentication TLS/SSL".
   * 
   * @return translated "Server Authentication TLS/SSL"
   */
  @DefaultMessage("Server Authentication TLS/SSL")
  @Key("accountFormSSL")
  String accountFormSSL();

  /**
   * Translated "Disable broker side only authentication using TLS/SSL".
   * 
   * @return translated "Disable broker side only authentication using TLS/SSL"
   */
  @DefaultMessage("Disable broker side only authentication using TLS/SSL")
  @Key("accountFormSSLDisabledRadioTooltip")
  String accountFormSSLDisabledRadioTooltip();

  /**
   * Translated "Enable broker side only authentication using TLS/SSL".
   * 
   * @return translated "Enable broker side only authentication using TLS/SSL"
   */
  @DefaultMessage("Enable broker side only authentication using TLS/SSL")
  @Key("accountFormSSLEnabledRadioTooltip")
  String accountFormSSLEnabledRadioTooltip();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("accountFormStatus")
  String accountFormStatus();

  /**
   * Translated "Edit Account: {0}".
   * 
   * @return translated "Edit Account: {0}"
   */
  @DefaultMessage("Edit Account: {0}")
  @Key("accountFormUpdate")
  String accountFormUpdate(String arg0);

  /**
   * Translated "VPN Server URL".
   * 
   * @return translated "VPN Server URL"
   */
  @DefaultMessage("VPN Server URL")
  @Key("accountFormVpnServer")
  String accountFormVpnServer();

  /**
   * Translated "Account ID".
   * 
   * @return translated "Account ID"
   */
  @DefaultMessage("Account ID")
  @Key("accountId")
  String accountId();

  /**
   * Translated "This user does not have proper permissions to view account’s settings.".
   * 
   * @return translated "This user does not have proper permissions to view account’s settings."
   */
  @DefaultMessage("This user does not have proper permissions to view account’s settings.")
  @Key("accountNoConfigSupported")
  String accountNoConfigSupported();

  /**
   * Translated "No Selected Account".
   * 
   * @return translated "No Selected Account"
   */
  @DefaultMessage("No Selected Account")
  @Key("accountNoSelectedAccount")
  String accountNoSelectedAccount();

  /**
   * Translated "Are you sure you want to re-provision the Broker instance for account {0}?".
   * 
   * @return translated "Are you sure you want to re-provision the Broker instance for account {0}?"
   */
  @DefaultMessage("Are you sure you want to re-provision the Broker instance for account {0}?")
  @Key("accountProvisionConfirmation")
  String accountProvisionConfirmation(String arg0);

  /**
   * Translated "Provisioning for Account {0} started.".
   * 
   * @return translated "Provisioning for Account {0} started."
   */
  @DefaultMessage("Provisioning for Account {0} started.")
  @Key("accountProvisionedConfirmation")
  String accountProvisionedConfirmation(String arg0);

  /**
   * Translated "<i>No child accounts</i>".
   * 
   * @return translated "<i>No child accounts</i>"
   */
  @DefaultMessage("<i>No child accounts</i>")
  @Key("accountSelectorItemNoChild")
  String accountSelectorItemNoChild();

  /**
   * Translated "<b>{0}</b>".
   * 
   * @return translated "<b>{0}</b>"
   */
  @DefaultMessage("<b>{0}</b>")
  @Key("accountSelectorItemSelectedAccount")
  String accountSelectorItemSelectedAccount(String arg0);

  /**
   * Translated "{0} - <i>Your account</i>".
   * 
   * @return translated "{0} - <i>Your account</i>"
   */
  @DefaultMessage("{0} - <i>Your account</i>")
  @Key("accountSelectorItemYourAccount")
  String accountSelectorItemYourAccount(String arg0);

  /**
   * Translated "Loading child accounts...".
   * 
   * @return translated "Loading child accounts..."
   */
  @DefaultMessage("Loading child accounts...")
  @Key("accountSelectorLoadingChildAccounts")
  String accountSelectorLoadingChildAccounts();

  /**
   * Translated "Switching to {0} account...".
   * 
   * @return translated "Switching to {0} account..."
   */
  @DefaultMessage("Switching to {0} account...")
  @Key("accountSelectorMenuMaskLoading")
  String accountSelectorMenuMaskLoading(String arg0);

  /**
   * Translated "Click to return to your main account".
   * 
   * @return translated "Click to return to your main account"
   */
  @DefaultMessage("Click to return to your main account")
  @Key("accountSelectorTooltipYourAccount")
  String accountSelectorTooltipYourAccount();

  /**
   * Translated "Service Plan".
   * 
   * @return translated "Service Plan"
   */
  @DefaultMessage("Service Plan")
  @Key("accountServicePlan")
  String accountServicePlan();

  /**
   * Translated "Children creation".
   * 
   * @return translated "Children creation"
   */
  @DefaultMessage("Children creation")
  @Key("accountServicePlanChildCreation")
  String accountServicePlanChildCreation();

  /**
   * Translated "Index Received Data by".
   * 
   * @return translated "Index Received Data by"
   */
  @DefaultMessage("Index Received Data by")
  @Key("accountServicePlanDataIndexBy")
  String accountServicePlanDataIndexBy();

  /**
   * Translated "Choose the timestamp to use to index the received data messages. Changes will apply to the newly received messages only.".
   * 
   * @return translated "Choose the timestamp to use to index the received data messages. Changes will apply to the newly received messages only."
   */
  @DefaultMessage("Choose the timestamp to use to index the received data messages. Changes will apply to the newly received messages only.")
  @Key("accountServicePlanDataIndexByTooltip")
  String accountServicePlanDataIndexByTooltip();

  /**
   * Translated "Data Storage".
   * 
   * @return translated "Data Storage"
   */
  @DefaultMessage("Data Storage")
  @Key("accountServicePlanDataStorage")
  String accountServicePlanDataStorage();

  /**
   * Translated "Is this account enabled for data storage and retention?".
   * 
   * @return translated "Is this account enabled for data storage and retention?"
   */
  @DefaultMessage("Is this account enabled for data storage and retention?")
  @Key("accountServicePlanDataStorageTooltip")
  String accountServicePlanDataStorageTooltip();

  /**
   * Translated "Data Time to Live (days)".
   * 
   * @return translated "Data Time to Live (days)"
   */
  @DefaultMessage("Data Time to Live (days)")
  @Key("accountServicePlanDataTimeToLive")
  String accountServicePlanDataTimeToLive();

  /**
   * Translated "Data retention period for this account in days.".
   * 
   * @return translated "Data retention period for this account in days."
   */
  @DefaultMessage("Data retention period for this account in days.")
  @Key("accountServicePlanDataTimeToLiveTooltip")
  String accountServicePlanDataTimeToLiveTooltip();

  /**
   * Translated "{0} - Disabled".
   * 
   * @return translated "{0} - Disabled"
   */
  @DefaultMessage("{0} - Disabled")
  @Key("accountServicePlanDisabledComboValue")
  String accountServicePlanDisabledComboValue(String arg0);

  /**
   * Translated "{0} mins - Enabled".
   * 
   * @return translated "{0} mins - Enabled"
   */
  @DefaultMessage("{0} mins - Enabled")
  @Key("accountServicePlanEnabledComboValue")
  String accountServicePlanEnabledComboValue(String arg0);

  /**
   * Translated "Expires On".
   * 
   * @return translated "Expires On"
   */
  @DefaultMessage("Expires On")
  @Key("accountServicePlanExpirationDate")
  String accountServicePlanExpirationDate();

  /**
   * Translated "Expiration date for the account or empty if the account never expires.".
   * 
   * @return translated "Expiration date for the account or empty if the account never expires."
   */
  @DefaultMessage("Expiration date for the account or empty if the account never expires.")
  @Key("accountServicePlanExpirationDateTooltip")
  String accountServicePlanExpirationDateTooltip();

  /**
   * Translated "System Health Monitoring".
   * 
   * @return translated "System Health Monitoring"
   */
  @DefaultMessage("System Health Monitoring")
  @Key("accountServicePlanHealthCheck")
  String accountServicePlanHealthCheck();

  /**
   * Translated "Health Check Interval (mins)".
   * 
   * @return translated "Health Check Interval (mins)"
   */
  @DefaultMessage("Health Check Interval (mins)")
  @Key("accountServicePlanHealthCheckInterval")
  String accountServicePlanHealthCheckInterval();

  /**
   * Translated "Select health check interval...".
   * 
   * @return translated "Select health check interval..."
   */
  @DefaultMessage("Select health check interval...")
  @Key("accountServicePlanHealthCheckIntervalEmptyText")
  String accountServicePlanHealthCheckIntervalEmptyText();

  /**
   * Translated "How frequently the services have to be monitored.".
   * 
   * @return translated "How frequently the services have to be monitored."
   */
  @DefaultMessage("How frequently the services have to be monitored.")
  @Key("accountServicePlanHealthCheckIntervalTooltip")
  String accountServicePlanHealthCheckIntervalTooltip();

  /**
   * Translated "Mqtt threshold".
   * 
   * @return translated "Mqtt threshold"
   */
  @DefaultMessage("Mqtt threshold")
  @Key("accountServicePlanHealthCheckThresholdMqtt")
  String accountServicePlanHealthCheckThresholdMqtt();

  /**
   * Translated "Rest threshold".
   * 
   * @return translated "Rest threshold"
   */
  @DefaultMessage("Rest threshold")
  @Key("accountServicePlanHealthCheckThresholdRest")
  String accountServicePlanHealthCheckThresholdRest();

  /**
   * Translated "Rest Command threshold".
   * 
   * @return translated "Rest Command threshold"
   */
  @DefaultMessage("Rest Command threshold")
  @Key("accountServicePlanHealthCheckThresholdRestCommand")
  String accountServicePlanHealthCheckThresholdRestCommand();

  /**
   * Translated "Set the threshold average value.".
   * 
   * @return translated "Set the threshold average value."
   */
  @DefaultMessage("Set the threshold average value.")
  @Key("accountServicePlanHealthCheckThresholdTooltip")
  String accountServicePlanHealthCheckThresholdTooltip();

  /**
   * Translated "Index Metrics Data by".
   * 
   * @return translated "Index Metrics Data by"
   */
  @DefaultMessage("Index Metrics Data by")
  @Key("accountServicePlanMetricsIndexBy")
  String accountServicePlanMetricsIndexBy();

  /**
   * Translated "Choose the field to use to index the metrics data. If None the metrics data will not be stored.".
   * 
   * @return translated "Choose the field to use to index the metrics data. If None the metrics data will not be stored."
   */
  @DefaultMessage("Choose the field to use to index the metrics data. If None the metrics data will not be stored.")
  @Key("accountServicePlanMetricsIndexByTooltip")
  String accountServicePlanMetricsIndexByTooltip();

  /**
   * Translated "Number of Child".
   * 
   * @return translated "Number of Child"
   */
  @DefaultMessage("Number of Child")
  @Key("accountServicePlanNumberOfChild")
  String accountServicePlanNumberOfChild();

  /**
   * Translated "Select maximum number of child accounts...".
   * 
   * @return translated "Select maximum number of child accounts..."
   */
  @DefaultMessage("Select maximum number of child accounts...")
  @Key("accountServicePlanNumberOfChildEmptyText")
  String accountServicePlanNumberOfChildEmptyText();

  /**
   * Translated "Maximum number of child that are allowed to be created for this account.".
   * 
   * @return translated "Maximum number of child that are allowed to be created for this account."
   */
  @DefaultMessage("Maximum number of child that are allowed to be created for this account.")
  @Key("accountServicePlanNumberOfChildTooltip")
  String accountServicePlanNumberOfChildTooltip();

  /**
   * Translated "Number of Device Jobs".
   * 
   * @return translated "Number of Device Jobs"
   */
  @DefaultMessage("Number of Device Jobs")
  @Key("accountServicePlanNumberOfDeviceJobs")
  String accountServicePlanNumberOfDeviceJobs();

  /**
   * Translated "Select maximum number of device jobs...".
   * 
   * @return translated "Select maximum number of device jobs..."
   */
  @DefaultMessage("Select maximum number of device jobs...")
  @Key("accountServicePlanNumberOfDeviceJobsEmptyText")
  String accountServicePlanNumberOfDeviceJobsEmptyText();

  /**
   * Translated "Maximum number of device jobs that are allowed to be created for this account.".
   * 
   * @return translated "Maximum number of device jobs that are allowed to be created for this account."
   */
  @DefaultMessage("Maximum number of device jobs that are allowed to be created for this account.")
  @Key("accountServicePlanNumberOfDeviceJobsTooltip")
  String accountServicePlanNumberOfDeviceJobsTooltip();

  /**
   * Translated "Number of Devices".
   * 
   * @return translated "Number of Devices"
   */
  @DefaultMessage("Number of Devices")
  @Key("accountServicePlanNumberOfDevices")
  String accountServicePlanNumberOfDevices();

  /**
   * Translated "Maximum number of devices that are allowed to connect for this account.".
   * 
   * @return translated "Maximum number of devices that are allowed to connect for this account."
   */
  @DefaultMessage("Maximum number of devices that are allowed to connect for this account.")
  @Key("accountServicePlanNumberOfDevicesTooltip")
  String accountServicePlanNumberOfDevicesTooltip();

  /**
   * Translated "Number of Provision Requests".
   * 
   * @return translated "Number of Provision Requests"
   */
  @DefaultMessage("Number of Provision Requests")
  @Key("accountServicePlanNumberOfProvision")
  String accountServicePlanNumberOfProvision();

  /**
   * Translated "Select maximum number of provision requests...".
   * 
   * @return translated "Select maximum number of provision requests..."
   */
  @DefaultMessage("Select maximum number of provision requests...")
  @Key("accountServicePlanNumberOfProvisionEmptyText")
  String accountServicePlanNumberOfProvisionEmptyText();

  /**
   * Translated "Maximum number of provision requests that are allowed to be created for this account.".
   * 
   * @return translated "Maximum number of provision requests that are allowed to be created for this account."
   */
  @DefaultMessage("Maximum number of provision requests that are allowed to be created for this account.")
  @Key("accountServicePlanNumberOfProvisionTooltip")
  String accountServicePlanNumberOfProvisionTooltip();

  /**
   * Translated "Number of Rules".
   * 
   * @return translated "Number of Rules"
   */
  @DefaultMessage("Number of Rules")
  @Key("accountServicePlanNumberOfRules")
  String accountServicePlanNumberOfRules();

  /**
   * Translated "Maximum number of Rules that can be defined per account; zero means no rules are allowed.".
   * 
   * @return translated "Maximum number of Rules that can be defined per account; zero means no rules are allowed."
   */
  @DefaultMessage("Maximum number of Rules that can be defined per account; zero means no rules are allowed.")
  @Key("accountServicePlanNumberOfRulesLabelTooltip")
  String accountServicePlanNumberOfRulesLabelTooltip();

  /**
   * Translated "Maximum number of Rules that can be defined per account; zero means no rules are allowed.".
   * 
   * @return translated "Maximum number of Rules that can be defined per account; zero means no rules are allowed."
   */
  @DefaultMessage("Maximum number of Rules that can be defined per account; zero means no rules are allowed.")
  @Key("accountServicePlanNumberOfRulesTooltip")
  String accountServicePlanNumberOfRulesTooltip();

  /**
   * Translated "Number of VPN Connections".
   * 
   * @return translated "Number of VPN Connections"
   */
  @DefaultMessage("Number of VPN Connections")
  @Key("accountServicePlanNumberOfVpn")
  String accountServicePlanNumberOfVpn();

  /**
   * Translated "Select maximum number of vpn connections...".
   * 
   * @return translated "Select maximum number of vpn connections..."
   */
  @DefaultMessage("Select maximum number of vpn connections...")
  @Key("accountServicePlanNumberOfVpnEmptyText")
  String accountServicePlanNumberOfVpnEmptyText();

  /**
   * Translated "Maximum number of VPN connections allowed for this account.".
   * 
   * @return translated "Maximum number of VPN connections allowed for this account."
   */
  @DefaultMessage("Maximum number of VPN connections allowed for this account.")
  @Key("accountServicePlanNumberOfVpnTooltip")
  String accountServicePlanNumberOfVpnTooltip();

  /**
   * Translated "Device Credential Strategy".
   * 
   * @return translated "Device Credential Strategy"
   */
  @DefaultMessage("Device Credential Strategy")
  @Key("accountServicePlanSecurityDevice")
  String accountServicePlanSecurityDevice();

  /**
   * Translated "Allow new not-provisioned devices".
   * 
   * @return translated "Allow new not-provisioned devices"
   */
  @DefaultMessage("Allow new not-provisioned devices")
  @Key("accountServicePlanSecurityDeviceAllowNewUnprovisioned")
  String accountServicePlanSecurityDeviceAllowNewUnprovisioned();

  /**
   * Translated "Sets whether or not let new devices connect without the provisioning process ".
   * 
   * @return translated "Sets whether or not let new devices connect without the provisioning process "
   */
  @DefaultMessage("Sets whether or not let new devices connect without the provisioning process ")
  @Key("accountServicePlanSecurityDeviceAllowNewUnprovisionedTooltip")
  String accountServicePlanSecurityDeviceAllowNewUnprovisionedTooltip();

  /**
   * Translated "Default Device Credentials Tight".
   * 
   * @return translated "Default Device Credentials Tight"
   */
  @DefaultMessage("Default Device Credentials Tight")
  @Key("accountServicePlanSecurityDeviceDefaultCredentialsTight")
  String accountServicePlanSecurityDeviceDefaultCredentialsTight();

  /**
   * Translated "Sets the default strategy to use on validating credentals. <br>- Device-bound: means that a registered device can only use only one set of credentials and cannot change them. <br>- Unbound: instead do not restrict the credential usage in any way. <br>Both strategies requires that credentials on login must be valid.".
   * 
   * @return translated "Sets the default strategy to use on validating credentals. <br>- Device-bound: means that a registered device can only use only one set of credentials and cannot change them. <br>- Unbound: instead do not restrict the credential usage in any way. <br>Both strategies requires that credentials on login must be valid."
   */
  @DefaultMessage("Sets the default strategy to use on validating credentals. <br>- Device-bound: means that a registered device can only use only one set of credentials and cannot change them. <br>- Unbound: instead do not restrict the credential usage in any way. <br>Both strategies requires that credentials on login must be valid.")
  @Key("accountServicePlanSecurityDeviceDefaultCredentialsTightTooltip")
  String accountServicePlanSecurityDeviceDefaultCredentialsTightTooltip();

  /**
   * Translated "Total data usage (MB/m)".
   * 
   * @return translated "Total data usage (MB/m)"
   */
  @DefaultMessage("Total data usage (MB/m)")
  @Key("accountServicePlanTotalRxField")
  String accountServicePlanTotalRxField();

  /**
   * Translated "Total data usage per month.  ".
   * 
   * @return translated "Total data usage per month.  "
   */
  @DefaultMessage("Total data usage per month.  ")
  @Key("accountServicePlanTotalRxFieldTooltip")
  String accountServicePlanTotalRxFieldTooltip();

  /**
   * Translated "Total Data Usage (MB/m)".
   * 
   * @return translated "Total Data Usage (MB/m)"
   */
  @DefaultMessage("Total Data Usage (MB/m)")
  @Key("accountServicePlanTotalTxField")
  String accountServicePlanTotalTxField();

  /**
   * Translated "Total data usage per month.  ".
   * 
   * @return translated "Total data usage per month.  "
   */
  @DefaultMessage("Total data usage per month.  ")
  @Key("accountServicePlanTotalTxFieldTooltip")
  String accountServicePlanTotalTxFieldTooltip();

  /**
   * Translated "Data Plan Per Device (MB/m)".
   * 
   * @return translated "Data Plan Per Device (MB/m)"
   */
  @DefaultMessage("Data Plan Per Device (MB/m)")
  @Key("accountServicePlanTxRxPerDeviceField")
  String accountServicePlanTxRxPerDeviceField();

  /**
   * Translated "Monthly data usage allowed per device.  ".
   * 
   * @return translated "Monthly data usage allowed per device.  "
   */
  @DefaultMessage("Monthly data usage allowed per device.  ")
  @Key("accountServicePlanTxRxPerDeviceFieldTooltip")
  String accountServicePlanTxRxPerDeviceFieldTooltip();

  /**
   * Translated "VPN creation".
   * 
   * @return translated "VPN creation"
   */
  @DefaultMessage("VPN creation")
  @Key("accountServicePlanVpnCreation")
  String accountServicePlanVpnCreation();

  /**
   * Translated "Users".
   * 
   * @return translated "Users"
   */
  @DefaultMessage("Users")
  @Key("accountTabUsers")
  String accountTabUsers();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("accountTableCreatedOn")
  String accountTableCreatedOn();

  /**
   * Translated "Data TTL".
   * 
   * @return translated "Data TTL"
   */
  @DefaultMessage("Data TTL")
  @Key("accountTableDataTtl")
  String accountTableDataTtl();

  /**
   * Translated "Expires On".
   * 
   * @return translated "Expires On"
   */
  @DefaultMessage("Expires On")
  @Key("accountTableExpiresOn")
  String accountTableExpiresOn();

  /**
   * Translated "Health Check Interval".
   * 
   * @return translated "Health Check Interval"
   */
  @DefaultMessage("Health Check Interval")
  @Key("accountTableHealthCheckInterval")
  String accountTableHealthCheckInterval();

  /**
   * Translated "General Info".
   * 
   * @return translated "General Info"
   */
  @DefaultMessage("General Info")
  @Key("accountTableInfoGroupHeader")
  String accountTableInfoGroupHeader();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultMessage("Modified On")
  @Key("accountTableModifiedOn")
  String accountTableModifiedOn();

  /**
   * Translated "Account Name".
   * 
   * @return translated "Account Name"
   */
  @DefaultMessage("Account Name")
  @Key("accountTableName")
  String accountTableName();

  /**
   * Translated "No Child Accounts Defined".
   * 
   * @return translated "No Child Accounts Defined"
   */
  @DefaultMessage("No Child Accounts Defined")
  @Key("accountTableNoAccounts")
  String accountTableNoAccounts();

  /**
   * Translated "Child Accounts".
   * 
   * @return translated "Child Accounts"
   */
  @DefaultMessage("Child Accounts")
  @Key("accountTableNumChildAccounts")
  String accountTableNumChildAccounts();

  /**
   * Translated "Device Jobs".
   * 
   * @return translated "Device Jobs"
   */
  @DefaultMessage("Device Jobs")
  @Key("accountTableNumDeviceJobs")
  String accountTableNumDeviceJobs();

  /**
   * Translated "Devices".
   * 
   * @return translated "Devices"
   */
  @DefaultMessage("Devices")
  @Key("accountTableNumDevices")
  String accountTableNumDevices();

  /**
   * Translated "Provision Requests".
   * 
   * @return translated "Provision Requests"
   */
  @DefaultMessage("Provision Requests")
  @Key("accountTableNumProvisionRequests")
  String accountTableNumProvisionRequests();

  /**
   * Translated "Rules".
   * 
   * @return translated "Rules"
   */
  @DefaultMessage("Rules")
  @Key("accountTableNumRules")
  String accountTableNumRules();

  /**
   * Translated "Vpn Connections".
   * 
   * @return translated "Vpn Connections"
   */
  @DefaultMessage("Vpn Connections")
  @Key("accountTableNumVpnConnections")
  String accountTableNumVpnConnections();

  /**
   * Translated "Resources".
   * 
   * @return translated "Resources"
   */
  @DefaultMessage("Resources")
  @Key("accountTableResourcesGroupHeader")
  String accountTableResourcesGroupHeader();

  /**
   * Translated "Account successfully updated.".
   * 
   * @return translated "Account successfully updated."
   */
  @DefaultMessage("Account successfully updated.")
  @Key("accountUpdatedConfirmation")
  String accountUpdatedConfirmation();

  /**
   * Translated "Summary of the resources used by the current account including the aggregated of all its child accounts. Data usage is based on the aggregate size of the messages received by the account. Each messages is computed based on its topic and payload size.".
   * 
   * @return translated "Summary of the resources used by the current account including the aggregated of all its child accounts. Data usage is based on the aggregate size of the messages received by the account. Each messages is computed based on its topic and payload size."
   */
  @DefaultMessage("Summary of the resources used by the current account including the aggregated of all its child accounts. Data usage is based on the aggregate size of the messages received by the account. Each messages is computed based on its topic and payload size.")
  @Key("accountUsadeInfoText")
  String accountUsadeInfoText();

  /**
   * Translated "Current Month".
   * 
   * @return translated "Current Month"
   */
  @DefaultMessage("Current Month")
  @Key("accountUsageBillingCurrent")
  String accountUsageBillingCurrent();

  /**
   * Translated "Billing Cycle:".
   * 
   * @return translated "Billing Cycle:"
   */
  @DefaultMessage("Billing Cycle:")
  @Key("accountUsageBillingCycle")
  String accountUsageBillingCycle();

  /**
   * Translated "Last Month".
   * 
   * @return translated "Last Month"
   */
  @DefaultMessage("Last Month")
  @Key("accountUsageBillingLast")
  String accountUsageBillingLast();

  /**
   * Translated "Available".
   * 
   * @return translated "Available"
   */
  @DefaultMessage("Available")
  @Key("accountUsageChartAvailableSeries")
  String accountUsageChartAvailableSeries();

  /**
   * Translated "Accounts".
   * 
   * @return translated "Accounts"
   */
  @DefaultMessage("Accounts")
  @Key("accountUsageChartBarAccounts")
  String accountUsageChartBarAccounts();

  /**
   * Translated "Current Month Data".
   * 
   * @return translated "Current Month Data"
   */
  @DefaultMessage("Current Month Data")
  @Key("accountUsageChartBarData")
  String accountUsageChartBarData();

  /**
   * Translated "Device Jobs".
   * 
   * @return translated "Device Jobs"
   */
  @DefaultMessage("Device Jobs")
  @Key("accountUsageChartBarDeviceJobs")
  String accountUsageChartBarDeviceJobs();

  /**
   * Translated "Devices".
   * 
   * @return translated "Devices"
   */
  @DefaultMessage("Devices")
  @Key("accountUsageChartBarDevices")
  String accountUsageChartBarDevices();

  /**
   * Translated "Provision Requests".
   * 
   * @return translated "Provision Requests"
   */
  @DefaultMessage("Provision Requests")
  @Key("accountUsageChartBarProvisionRequests")
  String accountUsageChartBarProvisionRequests();

  /**
   * Translated "Rules".
   * 
   * @return translated "Rules"
   */
  @DefaultMessage("Rules")
  @Key("accountUsageChartBarRules")
  String accountUsageChartBarRules();

  /**
   * Translated "Vpn Connections".
   * 
   * @return translated "Vpn Connections"
   */
  @DefaultMessage("Vpn Connections")
  @Key("accountUsageChartBarVpnConnections")
  String accountUsageChartBarVpnConnections();

  /**
   * Translated "Used by child accounts ".
   * 
   * @return translated "Used by child accounts "
   */
  @DefaultMessage("Used by child accounts ")
  @Key("accountUsageChartUsedByChild")
  String accountUsageChartUsedByChild();

  /**
   * Translated "Used by this account".
   * 
   * @return translated "Used by this account"
   */
  @DefaultMessage("Used by this account")
  @Key("accountUsageChartUsedByThisAccount")
  String accountUsageChartUsedByThisAccount();

  /**
   * Translated "Total Usage Consumption [%]".
   * 
   * @return translated "Total Usage Consumption [%]"
   */
  @DefaultMessage("Total Usage Consumption [%]")
  @Key("accountUsageChartXAxisTitle")
  String accountUsageChartXAxisTitle();

  /**
   * Translated "Child Used".
   * 
   * @return translated "Child Used"
   */
  @DefaultMessage("Child Used")
  @Key("accountUsageChild")
  String accountUsageChild();

  /**
   * Translated "Time Interval:".
   * 
   * @return translated "Time Interval:"
   */
  @DefaultMessage("Time Interval:")
  @Key("accountUsageDataRange")
  String accountUsageDataRange();

  /**
   * Translated "Data Used".
   * 
   * @return translated "Data Used"
   */
  @DefaultMessage("Data Used")
  @Key("accountUsageDataReceived")
  String accountUsageDataReceived();

  /**
   * Translated "Data Used (kB)".
   * 
   * @return translated "Data Used (kB)"
   */
  @DefaultMessage("Data Used (kB)")
  @Key("accountUsageDataReceivedKb")
  String accountUsageDataReceivedKb();

  /**
   * Translated "Data Sent".
   * 
   * @return translated "Data Sent"
   */
  @DefaultMessage("Data Sent")
  @Key("accountUsageDataSent")
  String accountUsageDataSent();

  /**
   * Translated "Data Sent (kB)".
   * 
   * @return translated "Data Sent (kB)"
   */
  @DefaultMessage("Data Sent (kB)")
  @Key("accountUsageDataSentKb")
  String accountUsageDataSentKb();

  /**
   * Translated "Date".
   * 
   * @return translated "Date"
   */
  @DefaultMessage("Date")
  @Key("accountUsageDate")
  String accountUsageDate();

  /**
   * Translated "Usage Details By:".
   * 
   * @return translated "Usage Details By:"
   */
  @DefaultMessage("Usage Details By:")
  @Key("accountUsageDetailsBy")
  String accountUsageDetailsBy();

  /**
   * Translated "Data Usage Details".
   * 
   * @return translated "Data Usage Details"
   */
  @DefaultMessage("Data Usage Details")
  @Key("accountUsageDetailsTab")
  String accountUsageDetailsTab();

  /**
   * Translated "Disabled".
   * 
   * @return translated "Disabled"
   */
  @DefaultMessage("Disabled")
  @Key("accountUsageDisabled")
  String accountUsageDisabled();

  /**
   * Translated "Hour".
   * 
   * @return translated "Hour"
   */
  @DefaultMessage("Hour")
  @Key("accountUsageHour")
  String accountUsageHour();

  /**
   * Translated "No Usage Data Available".
   * 
   * @return translated "No Usage Data Available"
   */
  @DefaultMessage("No Usage Data Available")
  @Key("accountUsageNoData")
  String accountUsageNoData();

  /**
   * Translated "Number of Devices".
   * 
   * @return translated "Number of Devices"
   */
  @DefaultMessage("Number of Devices")
  @Key("accountUsageNumberOfDevices")
  String accountUsageNumberOfDevices();

  /**
   * Translated "Day".
   * 
   * @return translated "Day"
   */
  @DefaultMessage("Day")
  @Key("accountUsageQueryTypeDays")
  String accountUsageQueryTypeDays();

  /**
   * Translated "Hour".
   * 
   * @return translated "Hour"
   */
  @DefaultMessage("Hour")
  @Key("accountUsageQueryTypeHour")
  String accountUsageQueryTypeHour();

  /**
   * Translated "Rules Used".
   * 
   * @return translated "Rules Used"
   */
  @DefaultMessage("Rules Used")
  @Key("accountUsageRules")
  String accountUsageRules();

  /**
   * Translated "Current Usage".
   * 
   * @return translated "Current Usage"
   */
  @DefaultMessage("Current Usage")
  @Key("accountUsageSummary")
  String accountUsageSummary();

  /**
   * Translated "Unlimited".
   * 
   * @return translated "Unlimited"
   */
  @DefaultMessage("Unlimited")
  @Key("accountUsageUnlimited")
  String accountUsageUnlimited();

  /**
   * Translated "VPN Connections Used".
   * 
   * @return translated "VPN Connections Used"
   */
  @DefaultMessage("VPN Connections Used")
  @Key("accountUsageVpn")
  String accountUsageVpn();

  /**
   * Translated "Accounts".
   * 
   * @return translated "Accounts"
   */
  @DefaultMessage("Accounts")
  @Key("accounts")
  String accounts();

  /**
   * Translated "Active".
   * 
   * @return translated "Active"
   */
  @DefaultMessage("Active")
  @Key("active")
  String active();

  /**
   * Translated "Category".
   * 
   * @return translated "Category"
   */
  @DefaultMessage("Category")
  @Key("alertCategoryColumn")
  String alertCategoryColumn();

  /**
   * Translated "Code".
   * 
   * @return translated "Code"
   */
  @DefaultMessage("Code")
  @Key("alertCodeColumn")
  String alertCodeColumn();

  /**
   * Translated "Creation Date".
   * 
   * @return translated "Creation Date"
   */
  @DefaultMessage("Creation Date")
  @Key("alertCreationDateColumn")
  String alertCreationDateColumn();

  /**
   * Translated "Are you sure you want to delete this alert?".
   * 
   * @return translated "Are you sure you want to delete this alert?"
   */
  @DefaultMessage("Are you sure you want to delete this alert?")
  @Key("alertDeleteConfirmation")
  String alertDeleteConfirmation();

  /**
   * Translated "Are you sure you want to delete these {0} alerts?".
   * 
   * @return translated "Are you sure you want to delete these {0} alerts?"
   */
  @DefaultMessage("Are you sure you want to delete these {0} alerts?")
  @Key("alertDeleteMultipleConfirmation")
  String alertDeleteMultipleConfirmation(String arg0);

  /**
   * Translated "The selected alert has been deleted.".
   * 
   * @return translated "The selected alert has been deleted."
   */
  @DefaultMessage("The selected alert has been deleted.")
  @Key("alertDeletedConfirmation")
  String alertDeletedConfirmation();

  /**
   * Translated "The selected alerts has been deleted.".
   * 
   * @return translated "The selected alerts has been deleted."
   */
  @DefaultMessage("The selected alerts has been deleted.")
  @Key("alertDeletedMultipleConfirmation")
  String alertDeletedMultipleConfirmation();

  /**
   * Translated "Message".
   * 
   * @return translated "Message"
   */
  @DefaultMessage("Message")
  @Key("alertMessageColumn")
  String alertMessageColumn();

  /**
   * Translated "Severity".
   * 
   * @return translated "Severity"
   */
  @DefaultMessage("Severity")
  @Key("alertSeverityColumn")
  String alertSeverityColumn();

  /**
   * Translated "Critical".
   * 
   * @return translated "Critical"
   */
  @DefaultMessage("Critical")
  @Key("alertSeverityCritical")
  String alertSeverityCritical();

  /**
   * Translated "Info".
   * 
   * @return translated "Info"
   */
  @DefaultMessage("Info")
  @Key("alertSeverityInfo")
  String alertSeverityInfo();

  /**
   * Translated "Warning".
   * 
   * @return translated "Warning"
   */
  @DefaultMessage("Warning")
  @Key("alertSeverityWarning")
  String alertSeverityWarning();

  /**
   * Translated "Device".
   * 
   * @return translated "Device"
   */
  @DefaultMessage("Device")
  @Key("alertSourceColumn")
  String alertSourceColumn();

  /**
   * Translated "No Results".
   * 
   * @return translated "No Results"
   */
  @DefaultMessage("No Results")
  @Key("alertTableNoAlert")
  String alertTableNoAlert();

  /**
   * Translated "Uuid".
   * 
   * @return translated "Uuid"
   */
  @DefaultMessage("Uuid")
  @Key("alertUuidColumn")
  String alertUuidColumn();

  /**
   * Translated "Fields with * are mandatory.".
   * 
   * @return translated "Fields with * are mandatory."
   */
  @DefaultMessage("Fields with * are mandatory.")
  @Key("allFieldsRequired")
  String allFieldsRequired();

  /**
   * Translated "Currently Down".
   * 
   * @return translated "Currently Down"
   */
  @DefaultMessage("Currently Down")
  @Key("alwaysFailed")
  String alwaysFailed();

  /**
   * Translated "Always Passed".
   * 
   * @return translated "Always Passed"
   */
  @DefaultMessage("Always Passed")
  @Key("alwaysPassed")
  String alwaysPassed();

  /**
   * Translated "Apply".
   * 
   * @return translated "Apply"
   */
  @DefaultMessage("Apply")
  @Key("apply")
  String apply();

  /**
   * Translated "Applying Configuration...".
   * 
   * @return translated "Applying Configuration..."
   */
  @DefaultMessage("Applying Configuration...")
  @Key("applying")
  String applying();

  /**
   * Translated "Asset".
   * 
   * @return translated "Asset"
   */
  @DefaultMessage("Asset")
  @Key("asset")
  String asset();

  /**
   * Translated "Being Deleted".
   * 
   * @return translated "Being Deleted"
   */
  @DefaultMessage("Being Deleted")
  @Key("beingDeleted")
  String beingDeleted();

  /**
   * Translated "Boolean".
   * 
   * @return translated "Boolean"
   */
  @DefaultMessage("Boolean")
  @Key("booleanType")
  String booleanType();

  /**
   * Translated "Browser Window is too small for accurate UI display.".
   * 
   * @return translated "Browser Window is too small for accurate UI display."
   */
  @DefaultMessage("Browser Window is too small for accurate UI display.")
  @Key("browserWindowTooSmall")
  String browserWindowTooSmall();

  /**
   * Translated "Add".
   * 
   * @return translated "Add"
   */
  @DefaultMessage("Add")
  @Key("buttonAdd")
  String buttonAdd();

  /**
   * Translated "Discard".
   * 
   * @return translated "Discard"
   */
  @DefaultMessage("Discard")
  @Key("buttonConfigDiscard")
  String buttonConfigDiscard();

  /**
   * Translated "Save".
   * 
   * @return translated "Save"
   */
  @DefaultMessage("Save")
  @Key("buttonConfigSave")
  String buttonConfigSave();

  /**
   * Translated "Disable".
   * 
   * @return translated "Disable"
   */
  @DefaultMessage("Disable")
  @Key("buttonDisable")
  String buttonDisable();

  /**
   * Translated "Edit".
   * 
   * @return translated "Edit"
   */
  @DefaultMessage("Edit")
  @Key("buttonEdit")
  String buttonEdit();

  /**
   * Translated "Enable".
   * 
   * @return translated "Enable"
   */
  @DefaultMessage("Enable")
  @Key("buttonEnable")
  String buttonEnable();

  /**
   * Translated "Export Data".
   * 
   * @return translated "Export Data"
   */
  @DefaultMessage("Export Data")
  @Key("buttonExport")
  String buttonExport();

  /**
   * Translated "Query".
   * 
   * @return translated "Query"
   */
  @DefaultMessage("Query")
  @Key("buttonQuery")
  String buttonQuery();

  /**
   * Translated "Refresh".
   * 
   * @return translated "Refresh"
   */
  @DefaultMessage("Refresh")
  @Key("buttonRefresh")
  String buttonRefresh();

  /**
   * Translated "Delete".
   * 
   * @return translated "Delete"
   */
  @DefaultMessage("Delete")
  @Key("buttonRemove")
  String buttonRemove();

  /**
   * Translated "Byte Array".
   * 
   * @return translated "Byte Array"
   */
  @DefaultMessage("Byte Array")
  @Key("byteArrayType")
  String byteArrayType();

  /**
   * Translated "Cancel".
   * 
   * @return translated "Cancel"
   */
  @DefaultMessage("Cancel")
  @Key("cancelButton")
  String cancelButton();

  /**
   * Translated "Change Password".
   * 
   * @return translated "Change Password"
   */
  @DefaultMessage("Change Password")
  @Key("changePassword")
  String changePassword();

  /**
   * Translated "Password changed successfully!".
   * 
   * @return translated "Password changed successfully!"
   */
  @DefaultMessage("Password changed successfully!")
  @Key("changePasswordConfirmation")
  String changePasswordConfirmation();

  /**
   * Translated "Error while changing password: {0}".
   * 
   * @return translated "Error while changing password: {0}"
   */
  @DefaultMessage("Error while changing password: {0}")
  @Key("changePasswordError")
  String changePasswordError(String arg0);

  /**
   * Translated "Invalid Old Password.".
   * 
   * @return translated "Invalid Old Password."
   */
  @DefaultMessage("Invalid Old Password.")
  @Key("changePasswordErrorWrongOldPassword")
  String changePasswordErrorWrongOldPassword();

  /**
   * Translated "Invalid Old Password or Authentication Code.".
   * 
   * @return translated "Invalid Old Password or Authentication Code."
   */
  @DefaultMessage("Invalid Old Password or Authentication Code.")
  @Key("changePasswordErrorWrongOldPasswordOrMfaCode")
  String changePasswordErrorWrongOldPasswordOrMfaCode();

  /**
   * Translated "Child Accounts".
   * 
   * @return translated "Child Accounts"
   */
  @DefaultMessage("Child Accounts")
  @Key("childaccounts")
  String childaccounts();

  /**
   * Translated "Close".
   * 
   * @return translated "Close"
   */
  @DefaultMessage("Close")
  @Key("close")
  String close();

  /**
   * Translated "Close".
   * 
   * @return translated "Close"
   */
  @DefaultMessage("Close")
  @Key("closeButton")
  String closeButton();

  /**
   * Translated "Cloud Settings".
   * 
   * @return translated "Cloud Settings"
   */
  @DefaultMessage("Cloud Settings")
  @Key("cloudSettings")
  String cloudSettings();

  /**
   * Translated "Command execution failed".
   * 
   * @return translated "Command execution failed"
   */
  @DefaultMessage("Command execution failed")
  @Key("commandExecutionFailure")
  String commandExecutionFailure();

  /**
   * Translated "Confirm".
   * 
   * @return translated "Confirm"
   */
  @DefaultMessage("Confirm")
  @Key("confirm")
  String confirm();

  /**
   * Translated "Confirm Password".
   * 
   * @return translated "Confirm Password"
   */
  @DefaultMessage("Confirm Password")
  @Key("confirmPassword")
  String confirmPassword();

  /**
   * Translated "Connected".
   * 
   * @return translated "Connected"
   */
  @DefaultMessage("Connected")
  @Key("connected")
  String connected();

  /**
   * Translated "Connections".
   * 
   * @return translated "Connections"
   */
  @DefaultMessage("Connections")
  @Key("connections")
  String connections();

  /**
   * Translated "{0} @ {1}".
   * 
   * @return translated "{0} @ {1}"
   */
  @DefaultMessage("{0} @ {1}")
  @Key("consoleHeaderUserActionButtonLabel")
  String consoleHeaderUserActionButtonLabel(String arg0,  String arg1);

  /**
   * Translated "Language preferences".
   * 
   * @return translated "Language preferences"
   */
  @DefaultMessage("Language preferences")
  @Key("consoleHeaderUserActionLanguagePreferences")
  String consoleHeaderUserActionLanguagePreferences();

  /**
   * Translated "Logout".
   * 
   * @return translated "Logout"
   */
  @DefaultMessage("Logout")
  @Key("consoleHeaderUserActionLogout")
  String consoleHeaderUserActionLogout();

  /**
   * Translated "Switch to account...".
   * 
   * @return translated "Switch to account..."
   */
  @DefaultMessage("Switch to account...")
  @Key("consoleHeaderUserActionSwitchToAccount")
  String consoleHeaderUserActionSwitchToAccount();

  /**
   * Translated "User Setting".
   * 
   * @return translated "User Setting"
   */
  @DefaultMessage("User Setting")
  @Key("consoleHeaderUserActionUserSetting")
  String consoleHeaderUserActionUserSetting();

  /**
   * Translated "Activate Multi Factor Authentication!".
   * 
   * @return translated "Activate Multi Factor Authentication!"
   */
  @DefaultMessage("Activate Multi Factor Authentication!")
  @Key("consoleHeaderUserActionWarningEnableMfa")
  String consoleHeaderUserActionWarningEnableMfa();

  /**
   * Translated "Your user is an Administrator user of account {0}.<br>It is recommended to enhance the security of your user by activating the 2 factor authentication.".
   * 
   * @return translated "Your user is an Administrator user of account {0}.<br>It is recommended to enhance the security of your user by activating the 2 factor authentication."
   */
  @DefaultMessage("Your user is an Administrator user of account {0}.<br>It is recommended to enhance the security of your user by activating the 2 factor authentication.")
  @Key("consoleHeaderUserActionWarningEnableMfaTooltip")
  String consoleHeaderUserActionWarningEnableMfaTooltip(String arg0);

  /**
   * Translated "Credentials".
   * 
   * @return translated "Credentials"
   */
  @DefaultMessage("Credentials")
  @Key("credentials")
  String credentials();

  /**
   * Translated "Dashboard".
   * 
   * @return translated "Dashboard"
   */
  @DefaultMessage("Dashboard")
  @Key("dashboard")
  String dashboard();

  /**
   * Translated "Cannot save preference. No sufficient permission. Changes made will be lost.".
   * 
   * @return translated "Cannot save preference. No sufficient permission. Changes made will be lost."
   */
  @DefaultMessage("Cannot save preference. No sufficient permission. Changes made will be lost.")
  @Key("dashboardCannotSavePreferences")
  String dashboardCannotSavePreferences();

  /**
   * Translated "Changes saved".
   * 
   * @return translated "Changes saved"
   */
  @DefaultMessage("Changes saved")
  @Key("dashboardConfirmDashboardSavedPreferences")
  String dashboardConfirmDashboardSavedPreferences();

  /**
   * Translated "Connectivity".
   * 
   * @return translated "Connectivity"
   */
  @DefaultMessage("Connectivity")
  @Key("dashboardConnectivity")
  String dashboardConnectivity();

  /**
   * Translated "Device connectivity Status".
   * 
   * @return translated "Device connectivity Status"
   */
  @DefaultMessage("Device connectivity Status")
  @Key("dashboardConnectivityDeviceChartTitle")
  String dashboardConnectivityDeviceChartTitle();

  /**
   * Translated "Change".
   * 
   * @return translated "Change"
   */
  @DefaultMessage("Change")
  @Key("dashboardDataChartChangePreferenceButton")
  String dashboardDataChartChangePreferenceButton();

  /**
   * Translated "Select a metric...".
   * 
   * @return translated "Select a metric..."
   */
  @DefaultMessage("Select a metric...")
  @Key("dashboardDataChartMetricComboEmptyText")
  String dashboardDataChartMetricComboEmptyText();

  /**
   * Translated "Please select a metric.".
   * 
   * @return translated "Please select a metric."
   */
  @DefaultMessage("Please select a metric.")
  @Key("dashboardDataChartMetricComboValidationMessage")
  String dashboardDataChartMetricComboValidationMessage();

  /**
   * Translated "Recent Data By Topic".
   * 
   * @return translated "Recent Data By Topic"
   */
  @DefaultMessage("Recent Data By Topic")
  @Key("dashboardDataChartTitle")
  String dashboardDataChartTitle();

  /**
   * Translated "Change Preferences".
   * 
   * @return translated "Change Preferences"
   */
  @DefaultMessage("Change Preferences")
  @Key("dashboardDataChartTitleDialogHeader")
  String dashboardDataChartTitleDialogHeader();

  /**
   * Translated "Metric:".
   * 
   * @return translated "Metric:"
   */
  @DefaultMessage("Metric:")
  @Key("dashboardDataChartTitleMetric")
  String dashboardDataChartTitleMetric();

  /**
   * Translated "Topic:".
   * 
   * @return translated "Topic:"
   */
  @DefaultMessage("Topic:")
  @Key("dashboardDataChartTitleTopic")
  String dashboardDataChartTitleTopic();

  /**
   * Translated "Select a topic...".
   * 
   * @return translated "Select a topic..."
   */
  @DefaultMessage("Select a topic...")
  @Key("dashboardDataChartTopicComboEmptyText")
  String dashboardDataChartTopicComboEmptyText();

  /**
   * Translated "Most Recent Data".
   * 
   * @return translated "Most Recent Data"
   */
  @DefaultMessage("Most Recent Data")
  @Key("dashboardDataLastMessageTitle")
  String dashboardDataLastMessageTitle();

  /**
   * Translated "Device".
   * 
   * @return translated "Device"
   */
  @DefaultMessage("Device")
  @Key("dashboardDataTableDeviceColumn")
  String dashboardDataTableDeviceColumn();

  /**
   * Translated "Timestamp".
   * 
   * @return translated "Timestamp"
   */
  @DefaultMessage("Timestamp")
  @Key("dashboardDataTableTimestampColumn")
  String dashboardDataTableTimestampColumn();

  /**
   * Translated "Topic".
   * 
   * @return translated "Topic"
   */
  @DefaultMessage("Topic")
  @Key("dashboardDataTableTopicColumn")
  String dashboardDataTableTopicColumn();

  /**
   * Translated "You are not allowed to see this data".
   * 
   * @return translated "You are not allowed to see this data"
   */
  @DefaultMessage("You are not allowed to see this data")
  @Key("dashboardNotAllowedSection")
  String dashboardNotAllowedSection();

  /**
   * Translated "Connected Devices".
   * 
   * @return translated "Connected Devices"
   */
  @DefaultMessage("Connected Devices")
  @Key("dashboradConnectivityDeviceChartConnectedDevice")
  String dashboradConnectivityDeviceChartConnectedDevice();

  /**
   * Translated "Disconnected Devices".
   * 
   * @return translated "Disconnected Devices"
   */
  @DefaultMessage("Disconnected Devices")
  @Key("dashboradConnectivityDeviceChartDisconnectedDevice")
  String dashboradConnectivityDeviceChartDisconnectedDevice();

  /**
   * Translated "Missing Devices".
   * 
   * @return translated "Missing Devices"
   */
  @DefaultMessage("Missing Devices")
  @Key("dashboradConnectivityDeviceChartMissingDevice")
  String dashboradConnectivityDeviceChartMissingDevice();

  /**
   * Translated "No device found".
   * 
   * @return translated "No device found"
   */
  @DefaultMessage("No device found")
  @Key("dashboradConnectivityDeviceChartNoDeviceFound")
  String dashboradConnectivityDeviceChartNoDeviceFound();

  /**
   * Translated "Data".
   * 
   * @return translated "Data"
   */
  @DefaultMessage("Data")
  @Key("data")
  String data();

  /**
   * Translated "Asset".
   * 
   * @return translated "Asset"
   */
  @DefaultMessage("Asset")
  @Key("dataAsset")
  String dataAsset();

  /**
   * Translated "By Asset".
   * 
   * @return translated "By Asset"
   */
  @DefaultMessage("By Asset")
  @Key("dataByAsset")
  String dataByAsset();

  /**
   * Translated "Select the Asset which published the data, then select one or more of the available metrics for that asset. Finally click the Query button and view the results in a tabular form or in a graph format. The Results Chart only displays numeric metrics (integer, double, float); metrics of type boolean and byte array are not included in this chart.".
   * 
   * @return translated "Select the Asset which published the data, then select one or more of the available metrics for that asset. Finally click the Query button and view the results in a tabular form or in a graph format. The Results Chart only displays numeric metrics (integer, double, float); metrics of type boolean and byte array are not included in this chart."
   */
  @DefaultMessage("Select the Asset which published the data, then select one or more of the available metrics for that asset. Finally click the Query button and view the results in a tabular form or in a graph format. The Results Chart only displays numeric metrics (integer, double, float); metrics of type boolean and byte array are not included in this chart.")
  @Key("dataByAssetFilterInfo")
  String dataByAssetFilterInfo();

  /**
   * Translated "By Topic".
   * 
   * @return translated "By Topic"
   */
  @DefaultMessage("By Topic")
  @Key("dataByTopic")
  String dataByTopic();

  /**
   * Translated "Select the Topic under which the data was published, then select one or more of the available metrics for that topic. Finally click the Query button and view the results in a tabular form or in a graph format. The Results Chart only displays numeric metrics (integer, double, float); metrics of type boolean, string and byte array are not included in this chart. ".
   * 
   * @return translated "Select the Topic under which the data was published, then select one or more of the available metrics for that topic. Finally click the Query button and view the results in a tabular form or in a graph format. The Results Chart only displays numeric metrics (integer, double, float); metrics of type boolean, string and byte array are not included in this chart. "
   */
  @DefaultMessage("Select the Topic under which the data was published, then select one or more of the available metrics for that topic. Finally click the Query button and view the results in a tabular form or in a graph format. The Results Chart only displays numeric metrics (integer, double, float); metrics of type boolean, string and byte array are not included in this chart. ")
  @Key("dataByTopicFilterInfo")
  String dataByTopicFilterInfo();

  /**
   * Translated "Results Chart".
   * 
   * @return translated "Results Chart"
   */
  @DefaultMessage("Results Chart")
  @Key("dataChart")
  String dataChart();

  /**
   * Translated "Date Range:".
   * 
   * @return translated "Date Range:"
   */
  @DefaultMessage("Date Range:")
  @Key("dataDateRange")
  String dataDateRange();

  /**
   * Translated "Custom Date Range...".
   * 
   * @return translated "Custom Date Range..."
   */
  @DefaultMessage("Custom Date Range...")
  @Key("dataDateRangeCustom")
  String dataDateRangeCustom();

  /**
   * Translated "Choose an End Date".
   * 
   * @return translated "Choose an End Date"
   */
  @DefaultMessage("Choose an End Date")
  @Key("dataDateRangeCustomEnd")
  String dataDateRangeCustomEnd();

  /**
   * Translated "Choose a Start Date".
   * 
   * @return translated "Choose a Start Date"
   */
  @DefaultMessage("Choose a Start Date")
  @Key("dataDateRangeCustomStart")
  String dataDateRangeCustomStart();

  /**
   * Translated "Select a Date Range".
   * 
   * @return translated "Select a Date Range"
   */
  @DefaultMessage("Select a Date Range")
  @Key("dataDateRangeCustomTitle")
  String dataDateRangeCustomTitle();

  /**
   * Translated "Start Date cannot be after End Date.".
   * 
   * @return translated "Start Date cannot be after End Date."
   */
  @DefaultMessage("Start Date cannot be after End Date.")
  @Key("dataDateRangeInvalidStartDate")
  String dataDateRangeInvalidStartDate();

  /**
   * Translated "Start Time cannot be after End Time.".
   * 
   * @return translated "Start Time cannot be after End Time."
   */
  @DefaultMessage("Start Time cannot be after End Time.")
  @Key("dataDateRangeInvalidStartTime")
  String dataDateRangeInvalidStartTime();

  /**
   * Translated "End Date cannot be before Start Date.".
   * 
   * @return translated "End Date cannot be before Start Date."
   */
  @DefaultMessage("End Date cannot be before Start Date.")
  @Key("dataDateRangeInvalidStopDate")
  String dataDateRangeInvalidStopDate();

  /**
   * Translated "End Time cannot be before Start Time.".
   * 
   * @return translated "End Time cannot be before Start Time."
   */
  @DefaultMessage("End Time cannot be before Start Time.")
  @Key("dataDateRangeInvalidStopTime")
  String dataDateRangeInvalidStopTime();

  /**
   * Translated "Last 12 hours".
   * 
   * @return translated "Last 12 hours"
   */
  @DefaultMessage("Last 12 hours")
  @Key("dataDateRangeLast12Hours")
  String dataDateRangeLast12Hours();

  /**
   * Translated "Last 24 hours".
   * 
   * @return translated "Last 24 hours"
   */
  @DefaultMessage("Last 24 hours")
  @Key("dataDateRangeLast24Hours")
  String dataDateRangeLast24Hours();

  /**
   * Translated "Last hour".
   * 
   * @return translated "Last hour"
   */
  @DefaultMessage("Last hour")
  @Key("dataDateRangeLastHour")
  String dataDateRangeLastHour();

  /**
   * Translated "Last 30 days".
   * 
   * @return translated "Last 30 days"
   */
  @DefaultMessage("Last 30 days")
  @Key("dataDateRangeLastMonth")
  String dataDateRangeLastMonth();

  /**
   * Translated "Last 7 days".
   * 
   * @return translated "Last 7 days"
   */
  @DefaultMessage("Last 7 days")
  @Key("dataDateRangeLastWeek")
  String dataDateRangeLastWeek();

  /**
   * Translated "Start Date".
   * 
   * @return translated "Start Date"
   */
  @DefaultMessage("Start Date")
  @Key("dataDateRangeStartDate")
  String dataDateRangeStartDate();

  /**
   * Translated "Start Time".
   * 
   * @return translated "Start Time"
   */
  @DefaultMessage("Start Time")
  @Key("dataDateRangeStartTime")
  String dataDateRangeStartTime();

  /**
   * Translated "End Date".
   * 
   * @return translated "End Date"
   */
  @DefaultMessage("End Date")
  @Key("dataDateRangeStopDate")
  String dataDateRangeStopDate();

  /**
   * Translated "End Time".
   * 
   * @return translated "End Time"
   */
  @DefaultMessage("End Time")
  @Key("dataDateRangeStopTime")
  String dataDateRangeStopTime();

  /**
   * Translated "12 Hour Ago".
   * 
   * @return translated "12 Hour Ago"
   */
  @DefaultMessage("12 Hour Ago")
  @Key("dataEnd12Hour")
  String dataEnd12Hour();

  /**
   * Translated "Custom End Date...".
   * 
   * @return translated "Custom End Date..."
   */
  @DefaultMessage("Custom End Date...")
  @Key("dataEndCustom")
  String dataEndCustom();

  /**
   * Translated "A Day Ago".
   * 
   * @return translated "A Day Ago"
   */
  @DefaultMessage("A Day Ago")
  @Key("dataEndDay")
  String dataEndDay();

  /**
   * Translated "1 Hour Ago".
   * 
   * @return translated "1 Hour Ago"
   */
  @DefaultMessage("1 Hour Ago")
  @Key("dataEndHour")
  String dataEndHour();

  /**
   * Translated "A Month Ago".
   * 
   * @return translated "A Month Ago"
   */
  @DefaultMessage("A Month Ago")
  @Key("dataEndMonth")
  String dataEndMonth();

  /**
   * Translated "Now".
   * 
   * @return translated "Now"
   */
  @DefaultMessage("Now")
  @Key("dataEndNow")
  String dataEndNow();

  /**
   * Translated "End Date Range:".
   * 
   * @return translated "End Date Range:"
   */
  @DefaultMessage("End Date Range:")
  @Key("dataEndRange")
  String dataEndRange();

  /**
   * Translated "A Week Ago".
   * 
   * @return translated "A Week Ago"
   */
  @DefaultMessage("A Week Ago")
  @Key("dataEndWeek")
  String dataEndWeek();

  /**
   * Translated "Available Assets: ".
   * 
   * @return translated "Available Assets: "
   */
  @DefaultMessage("Available Assets: ")
  @Key("dataFilterAvailableAssets")
  String dataFilterAvailableAssets();

  /**
   * Translated "Available Metrics for Asset:".
   * 
   * @return translated "Available Metrics for Asset:"
   */
  @DefaultMessage("Available Metrics for Asset:")
  @Key("dataFilterAvailableHeadersForAsset")
  String dataFilterAvailableHeadersForAsset();

  /**
   * Translated "Available Metrics for Topic: ".
   * 
   * @return translated "Available Metrics for Topic: "
   */
  @DefaultMessage("Available Metrics for Topic: ")
  @Key("dataFilterAvailableHeadersForTopic")
  String dataFilterAvailableHeadersForTopic();

  /**
   * Translated "Available Topics: ".
   * 
   * @return translated "Available Topics: "
   */
  @DefaultMessage("Available Topics: ")
  @Key("dataFilterAvailableTopics")
  String dataFilterAvailableTopics();

  /**
   * Translated "Metric".
   * 
   * @return translated "Metric"
   */
  @DefaultMessage("Metric")
  @Key("dataHeader")
  String dataHeader();

  /**
   * Translated "Metric Type".
   * 
   * @return translated "Metric Type"
   */
  @DefaultMessage("Metric Type")
  @Key("dataHeaderType")
  String dataHeaderType();

  /**
   * Translated "Last Post Date".
   * 
   * @return translated "Last Post Date"
   */
  @DefaultMessage("Last Post Date")
  @Key("dataLastPostDate")
  String dataLastPostDate();

  /**
   * Translated "No Assets".
   * 
   * @return translated "No Assets"
   */
  @DefaultMessage("No Assets")
  @Key("dataNoAsset")
  String dataNoAsset();

  /**
   * Translated "No Metrics".
   * 
   * @return translated "No Metrics"
   */
  @DefaultMessage("No Metrics")
  @Key("dataNoHeaders")
  String dataNoHeaders();

  /**
   * Translated "No Topics".
   * 
   * @return translated "No Topics"
   */
  @DefaultMessage("No Topics")
  @Key("dataNoTopics")
  String dataNoTopics();

  /**
   * Translated "Data Query by Asset".
   * 
   * @return translated "Data Query by Asset"
   */
  @DefaultMessage("Data Query by Asset")
  @Key("dataQueryByAsset")
  String dataQueryByAsset();

  /**
   * Translated "Data Query by Topic".
   * 
   * @return translated "Data Query by Topic"
   */
  @DefaultMessage("Data Query by Topic")
  @Key("dataQueryByTopic")
  String dataQueryByTopic();

  /**
   * Translated "Query for the Data to be plotted.".
   * 
   * @return translated "Query for the Data to be plotted."
   */
  @DefaultMessage("Query for the Data to be plotted.")
  @Key("dataQueryForData")
  String dataQueryForData();

  /**
   * Translated "Results Table".
   * 
   * @return translated "Results Table"
   */
  @DefaultMessage("Results Table")
  @Key("dataTable")
  String dataTable();

  /**
   * Translated "Topic".
   * 
   * @return translated "Topic"
   */
  @DefaultMessage("Topic")
  @Key("dataTopic")
  String dataTopic();

  /**
   * Translated "None".
   * 
   * @return translated "None"
   */
  @DefaultMessage("None")
  @Key("dateTimeNone")
  String dateTimeNone();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("devicePropName")
  String devicePropName();

  /**
   * Translated "Value".
   * 
   * @return translated "Value"
   */
  @DefaultMessage("Value")
  @Key("devicePropValue")
  String devicePropValue();

  /**
   * Translated "&gt;&gt; Filter".
   * 
   * @return translated "&gt;&gt; Filter"
   */
  @DefaultMessage("&gt;&gt; Filter")
  @Key("deviceTableToolbarCloseFilter")
  String deviceTableToolbarCloseFilter();

  /**
   * Translated "&lt;&lt; Filter".
   * 
   * @return translated "&lt;&lt; Filter"
   */
  @DefaultMessage("&lt;&lt; Filter")
  @Key("deviceTableToolbarOpenFilter")
  String deviceTableToolbarOpenFilter();

  /**
   * Translated "Devices".
   * 
   * @return translated "Devices"
   */
  @DefaultMessage("Devices")
  @Key("devices")
  String devices();

  /**
   * Translated "Password must be {0} to 255 characters long and must contain at least one lower case letter, one upper case letter, one digit and one special character. Allowed special characters: # | '' ! \" £ $ % & @ / [ ] ( ) '{' '}' = ? ^ '' > < , ; . : - _ * + € ^ ` ~".
   * 
   * @return translated "Password must be {0} to 255 characters long and must contain at least one lower case letter, one upper case letter, one digit and one special character. Allowed special characters: # | '' ! \" £ $ % & @ / [ ] ( ) '{' '}' = ? ^ '' > < , ; . : - _ * + € ^ ` ~"
   */
  @DefaultMessage("Password must be {0} to 255 characters long and must contain at least one lower case letter, one upper case letter, one digit and one special character. Allowed special characters: # | '' ! \" £ $ % & @ / [ ] ( ) '{' '}' = ? ^ '' > < , ; . : - _ * + € ^ ` ~")
  @Key("dialogAddTooltipCredentialPassword")
  String dialogAddTooltipCredentialPassword(String arg0);

  /**
   * Translated "Alert".
   * 
   * @return translated "Alert"
   */
  @DefaultMessage("Alert")
  @Key("dialogAlerts")
  String dialogAlerts();

  /**
   * Translated "Error".
   * 
   * @return translated "Error"
   */
  @DefaultMessage("Error")
  @Key("dialogError")
  String dialogError();

  /**
   * Translated "Info".
   * 
   * @return translated "Info"
   */
  @DefaultMessage("Info")
  @Key("dialogInfo")
  String dialogInfo();

  /**
   * Translated "No Logs!".
   * 
   * @return translated "No Logs!"
   */
  @DefaultMessage("No Logs!")
  @Key("dialogLogEmptyText")
  String dialogLogEmptyText();

  /**
   * Translated "Disabled".
   * 
   * @return translated "Disabled"
   */
  @DefaultMessage("Disabled")
  @Key("disabled")
  String disabled();

  /**
   * Translated "Disabled But Connected".
   * 
   * @return translated "Disabled But Connected"
   */
  @DefaultMessage("Disabled But Connected")
  @Key("disabledButConnected")
  String disabledButConnected();

  /**
   * Translated "Disconnected".
   * 
   * @return translated "Disconnected"
   */
  @DefaultMessage("Disconnected")
  @Key("disconnected")
  String disconnected();

  /**
   * Translated "Double".
   * 
   * @return translated "Double"
   */
  @DefaultMessage("Double")
  @Key("doubleType")
  String doubleType();

  /**
   * Translated "Download".
   * 
   * @return translated "Download"
   */
  @DefaultMessage("Download")
  @Key("download")
  String download();

  /**
   * Translated "Enabled".
   * 
   * @return translated "Enabled"
   */
  @DefaultMessage("Enabled")
  @Key("enabled")
  String enabled();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("entityTabDescriptionName")
  String entityTabDescriptionName();

  /**
   * Translated "No item selected".
   * 
   * @return translated "No item selected"
   */
  @DefaultMessage("No item selected")
  @Key("entityTabDescriptionNoSelection")
  String entityTabDescriptionNoSelection();

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("entityTabDescriptionTitle")
  String entityTabDescriptionTitle();

  /**
   * Translated "Value".
   * 
   * @return translated "Value"
   */
  @DefaultMessage("Value")
  @Key("entityTabDescriptionValue")
  String entityTabDescriptionValue();

  /**
   * Translated "Settings".
   * 
   * @return translated "Settings"
   */
  @DefaultMessage("Settings")
  @Key("entityTabSettingsTitle")
  String entityTabSettingsTitle();

  /**
   * Translated "Account Default".
   * 
   * @return translated "Account Default"
   */
  @DefaultMessage("Account Default")
  @Key("enumGwtDeviceCredentialsTightInherited")
  String enumGwtDeviceCredentialsTightInherited();

  /**
   * Translated "Unbound".
   * 
   * @return translated "Unbound"
   */
  @DefaultMessage("Unbound")
  @Key("enumGwtDeviceCredentialsTightLoose")
  String enumGwtDeviceCredentialsTightLoose();

  /**
   * Translated "Device-bound".
   * 
   * @return translated "Device-bound"
   */
  @DefaultMessage("Device-bound")
  @Key("enumGwtDeviceCredentialsTightStrict")
  String enumGwtDeviceCredentialsTightStrict();

  /**
   * Translated "Error ".
   * 
   * @return translated "Error "
   */
  @DefaultMessage("Error ")
  @Key("error")
  String error();

  /**
   * Translated "Fill With Template".
   * 
   * @return translated "Fill With Template"
   */
  @DefaultMessage("Fill With Template")
  @Key("exampleButton")
  String exampleButton();

  /**
   * Translated "Expired".
   * 
   * @return translated "Expired"
   */
  @DefaultMessage("Expired")
  @Key("expired")
  String expired();

  /**
   * Translated "Export to CSV".
   * 
   * @return translated "Export to CSV"
   */
  @DefaultMessage("Export to CSV")
  @Key("exportToCSV")
  String exportToCSV();

  /**
   * Translated "Export to Excel".
   * 
   * @return translated "Export to Excel"
   */
  @DefaultMessage("Export to Excel")
  @Key("exportToExcel")
  String exportToExcel();

  /**
   * Translated "External".
   * 
   * @return translated "External"
   */
  @DefaultMessage("External")
  @Key("external")
  String external();

  /**
   * Translated "false".
   * 
   * @return translated "false"
   */
  @DefaultMessage("false")
  @Key("falseLabel")
  String falseLabel();

  /**
   * Translated "File".
   * 
   * @return translated "File"
   */
  @DefaultMessage("File")
  @Key("fileLabel")
  String fileLabel();

  /**
   * Translated "File upload failed".
   * 
   * @return translated "File upload failed"
   */
  @DefaultMessage("File upload failed")
  @Key("fileUploadFailure")
  String fileUploadFailure();

  /**
   * Translated "the file provided is not a valid Kura Snapshot. Please review the file and try again.".
   * 
   * @return translated "the file provided is not a valid Kura Snapshot. Please review the file and try again."
   */
  @DefaultMessage("the file provided is not a valid Kura Snapshot. Please review the file and try again.")
  @Key("fileUploadInvalidShapshotFailure")
  String fileUploadInvalidShapshotFailure();

  /**
   * Translated "File was successfully uploaded.".
   * 
   * @return translated "File was successfully uploaded."
   */
  @DefaultMessage("File was successfully uploaded.")
  @Key("fileUploadSuccess")
  String fileUploadSuccess();

  /**
   * Translated "All non-empty fields will be compiled <br> and applied into the query taken into consideration in the filter.".
   * 
   * @return translated "All non-empty fields will be compiled <br> and applied into the query taken into consideration in the filter."
   */
  @DefaultMessage("All non-empty fields will be compiled <br> and applied into the query taken into consideration in the filter.")
  @Key("filteringPanelInfo")
  String filteringPanelInfo();

  /**
   * Translated "Reset".
   * 
   * @return translated "Reset"
   */
  @DefaultMessage("Reset")
  @Key("filteringPanelReset")
  String filteringPanelReset();

  /**
   * Translated "Search".
   * 
   * @return translated "Search"
   */
  @DefaultMessage("Search")
  @Key("filteringPanelSearch")
  String filteringPanelSearch();

  /**
   * Translated "Float".
   * 
   * @return translated "Float"
   */
  @DefaultMessage("Float")
  @Key("floatType")
  String floatType();

  /**
   * Translated "There are errors in the form.".
   * 
   * @return translated "There are errors in the form."
   */
  @DefaultMessage("There are errors in the form.")
  @Key("formErrors")
  String formErrors();

  /**
   * Translated "No result found".
   * 
   * @return translated "No result found"
   */
  @DefaultMessage("No result found")
  @Key("gridEmptyResult")
  String gridEmptyResult();

  /**
   * Translated "No {0}s added".
   * 
   * @return translated "No {0}s added"
   */
  @DefaultMessage("No {0}s added")
  @Key("gridNoResultAdded")
  String gridNoResultAdded(String arg0);

  /**
   * Translated "No {0}s available".
   * 
   * @return translated "No {0}s available"
   */
  @DefaultMessage("No {0}s available")
  @Key("gridNoResultAvailable")
  String gridNoResultAvailable(String arg0);

  /**
   * Translated "No {0}s found".
   * 
   * @return translated "No {0}s found"
   */
  @DefaultMessage("No {0}s found")
  @Key("gridNoResultFound")
  String gridNoResultFound(String arg0);

  /**
   * Translated "No {0}s received".
   * 
   * @return translated "No {0}s received"
   */
  @DefaultMessage("No {0}s received")
  @Key("gridNoResultReceived")
  String gridNoResultReceived(String arg0);

  /**
   * Translated "Access Groups".
   * 
   * @return translated "Access Groups"
   */
  @DefaultMessage("Access Groups")
  @Key("groups")
  String groups();

  /**
   * Translated "ID".
   * 
   * @return translated "ID"
   */
  @DefaultMessage("ID")
  @Key("id")
  String id();

  /**
   * Translated "Confirmation".
   * 
   * @return translated "Confirmation"
   */
  @DefaultMessage("Confirmation")
  @Key("info")
  String info();

  /**
   * Translated "Information".
   * 
   * @return translated "Information"
   */
  @DefaultMessage("Information")
  @Key("information")
  String information();

  /**
   * Translated "Connect Your Hardware".
   * 
   * @return translated "Connect Your Hardware"
   */
  @DefaultMessage("Connect Your Hardware")
  @Key("informationDevices")
  String informationDevices();

  /**
   * Translated "Documentation And Support".
   * 
   * @return translated "Documentation And Support"
   */
  @DefaultMessage("Documentation And Support")
  @Key("informationDocumentationAndSupport")
  String informationDocumentationAndSupport();

  /**
   * Translated "Sample Code".
   * 
   * @return translated "Sample Code"
   */
  @DefaultMessage("Sample Code")
  @Key("informationSampleCode")
  String informationSampleCode();

  /**
   * Translated "Integer".
   * 
   * @return translated "Integer"
   */
  @DefaultMessage("Integer")
  @Key("integerType")
  String integerType();

  /**
   * Translated "Internal".
   * 
   * @return translated "Internal"
   */
  @DefaultMessage("Internal")
  @Key("internal")
  String internal();

  /**
   * Translated "Is Default".
   * 
   * @return translated "Is Default"
   */
  @DefaultMessage("Is Default")
  @Key("isDefault")
  String isDefault();

  /**
   * Translated "Is Not Default".
   * 
   * @return translated "Is Not Default"
   */
  @DefaultMessage("Is Not Default")
  @Key("isNotDefault")
  String isNotDefault();

  /**
   * Translated "Change user settings and enable/disable MFA".
   * 
   * @return translated "Change user settings and enable/disable MFA"
   */
  @DefaultMessage("Change user settings and enable/disable MFA")
  @Key("labelChangeUserSettingsAndMfaSettings")
  String labelChangeUserSettingsAndMfaSettings();

  /**
   * Translated "To enhance security, please enable multi factor authentication ".
   * 
   * @return translated "To enhance security, please enable multi factor authentication "
   */
  @DefaultMessage("To enhance security, please enable multi factor authentication ")
  @Key("labelEnableMfaWelcomeScreen")
  String labelEnableMfaWelcomeScreen();

  /**
   * Translated "View user settings".
   * 
   * @return translated "View user settings"
   */
  @DefaultMessage("View user settings")
  @Key("labelShowUserSettings")
  String labelShowUserSettings();

  /**
   * Translated "Console Language Preference".
   * 
   * @return translated "Console Language Preference"
   */
  @DefaultMessage("Console Language Preference")
  @Key("languagePreferenceDialogHeader")
  String languagePreferenceDialogHeader();

  /**
   * Translated "Please select your preferred language.".
   * 
   * @return translated "Please select your preferred language."
   */
  @DefaultMessage("Please select your preferred language.")
  @Key("languagePreferenceDialogInfo")
  String languagePreferenceDialogInfo();

  /**
   * Translated "Use browser default".
   * 
   * @return translated "Use browser default"
   */
  @DefaultMessage("Use browser default")
  @Key("languagePreferenceDialogLanguageDefault")
  String languagePreferenceDialogLanguageDefault();

  /**
   * Translated "English".
   * 
   * @return translated "English"
   */
  @DefaultMessage("English")
  @Key("languagePreferenceDialogLanguageEnglish")
  String languagePreferenceDialogLanguageEnglish();

  /**
   * Translated "Italian".
   * 
   * @return translated "Italian"
   */
  @DefaultMessage("Italian")
  @Key("languagePreferenceDialogLanguageItalian")
  String languagePreferenceDialogLanguageItalian();

  /**
   * Translated "Live".
   * 
   * @return translated "Live"
   */
  @DefaultMessage("Live")
  @Key("live")
  String live();

  /**
   * Translated "Loading...".
   * 
   * @return translated "Loading..."
   */
  @DefaultMessage("Loading...")
  @Key("loading")
  String loading();

  /**
   * Translated "Locked".
   * 
   * @return translated "Locked"
   */
  @DefaultMessage("Locked")
  @Key("locked")
  String locked();

  /**
   * Translated "Logged Out".
   * 
   * @return translated "Logged Out"
   */
  @DefaultMessage("Logged Out")
  @Key("loggedOut")
  String loggedOut();

  /**
   * Translated "MFA code".
   * 
   * @return translated "MFA code"
   */
  @DefaultMessage("MFA code")
  @Key("loginCode")
  String loginCode();

  /**
   * Translated "Trust this device".
   * 
   * @return translated "Trust this device"
   */
  @DefaultMessage("Trust this device")
  @Key("loginDialogMfaBoxLabel")
  String loginDialogMfaBoxLabel();

  /**
   * Translated "Multi Factor Authentication (MFA)".
   * 
   * @return translated "Multi Factor Authentication (MFA)"
   */
  @DefaultMessage("Multi Factor Authentication (MFA)")
  @Key("loginDialogMfaTitle")
  String loginDialogMfaTitle();

  /**
   * Translated "On this user you choose to enable the multi factor authentication system to increase your security.".
   * 
   * @return translated "On this user you choose to enable the multi factor authentication system to increase your security."
   */
  @DefaultMessage("On this user you choose to enable the multi factor authentication system to increase your security.")
  @Key("loginMfa")
  String loginMfa();

  /**
   * Translated "Please insert your multi factor authentication code below. ".
   * 
   * @return translated "Please insert your multi factor authentication code below. "
   */
  @DefaultMessage("Please insert your multi factor authentication code below. ")
  @Key("loginMfa1")
  String loginMfa1();

  /**
   * Translated "SSO Login Error".
   * 
   * @return translated "SSO Login Error"
   */
  @DefaultMessage("SSO Login Error")
  @Key("loginSsoLoginError")
  String loginSsoLoginError();

  /**
   * Translated "Long".
   * 
   * @return translated "Long"
   */
  @DefaultMessage("Long")
  @Key("longType")
  String longType();

  /**
   * Translated "Cloud Administration".
   * 
   * @return translated "Cloud Administration"
   */
  @DefaultMessage("Cloud Administration")
  @Key("manageHeading")
  String manageHeading();

  /**
   * Translated "MB".
   * 
   * @return translated "MB"
   */
  @DefaultMessage("MB")
  @Key("megabyte")
  String megabyte();

  /**
   * Translated "Missing".
   * 
   * @return translated "Missing"
   */
  @DefaultMessage("Missing")
  @Key("missing")
  String missing();

  /**
   * Translated "Never".
   * 
   * @return translated "Never"
   */
  @DefaultMessage("Never")
  @Key("never")
  String never();

  /**
   * Translated "New Password".
   * 
   * @return translated "New Password"
   */
  @DefaultMessage("New Password")
  @Key("newPassword")
  String newPassword();

  /**
   * Translated "No".
   * 
   * @return translated "No"
   */
  @DefaultMessage("No")
  @Key("no")
  String no();

  /**
   * Translated "No Data".
   * 
   * @return translated "No Data"
   */
  @DefaultMessage("No Data")
  @Key("noData")
  String noData();

  /**
   * Translated "No Results".
   * 
   * @return translated "No Results"
   */
  @DefaultMessage("No Results")
  @Key("noResults")
  String noResults();

  /**
   * Translated "None".
   * 
   * @return translated "None"
   */
  @DefaultMessage("None")
  @Key("none")
  String none();

  /**
   * Translated "Not Active".
   * 
   * @return translated "Not Active"
   */
  @DefaultMessage("Not Active")
  @Key("notActive")
  String notActive();

  /**
   * Translated "Not Authorized".
   * 
   * @return translated "Not Authorized"
   */
  @DefaultMessage("Not Authorized")
  @Key("notAuthorized")
  String notAuthorized();

  /**
   * Translated "N/A".
   * 
   * @return translated "N/A"
   */
  @DefaultMessage("N/A")
  @Key("notAvailable")
  String notAvailable();

  /**
   * Translated "Not Synchronized".
   * 
   * @return translated "Not Synchronized"
   */
  @DefaultMessage("Not Synchronized")
  @Key("notSynched")
  String notSynched();

  /**
   * Translated "Number too large. Please reduce it.".
   * 
   * @return translated "Number too large. Please reduce it."
   */
  @DefaultMessage("Number too large. Please reduce it.")
  @Key("numberTooLargeErrorMessage")
  String numberTooLargeErrorMessage();

  /**
   * Translated "of".
   * 
   * @return translated "of"
   */
  @DefaultMessage("of")
  @Key("of")
  String of();

  /**
   * Translated "Ok".
   * 
   * @return translated "Ok"
   */
  @DefaultMessage("Ok")
  @Key("ok")
  String ok();

  /**
   * Translated "Old Password".
   * 
   * @return translated "Old Password"
   */
  @DefaultMessage("Old Password")
  @Key("oldPassword")
  String oldPassword();

  /**
   * Translated "Overview".
   * 
   * @return translated "Overview"
   */
  @DefaultMessage("Overview")
  @Key("overview")
  String overview();

  /**
   * Translated "Install/Upgrade".
   * 
   * @return translated "Install/Upgrade"
   */
  @DefaultMessage("Install/Upgrade")
  @Key("packageAddButton")
  String packageAddButton();

  /**
   * Translated "Uninstall".
   * 
   * @return translated "Uninstall"
   */
  @DefaultMessage("Uninstall")
  @Key("packageDeleteButton")
  String packageDeleteButton();

  /**
   * Translated "First page".
   * 
   * @return translated "First page"
   */
  @DefaultMessage("First page")
  @Key("pagingToolbarFirstPage")
  String pagingToolbarFirstPage();

  /**
   * Translated "Last page".
   * 
   * @return translated "Last page"
   */
  @DefaultMessage("Last page")
  @Key("pagingToolbarLastPage")
  String pagingToolbarLastPage();

  /**
   * Translated "Next page".
   * 
   * @return translated "Next page"
   */
  @DefaultMessage("Next page")
  @Key("pagingToolbarNextPage")
  String pagingToolbarNextPage();

  /**
   * Translated "No result to show".
   * 
   * @return translated "No result to show"
   */
  @DefaultMessage("No result to show")
  @Key("pagingToolbarNoResult")
  String pagingToolbarNoResult();

  /**
   * Translated "of".
   * 
   * @return translated "of"
   */
  @DefaultMessage("of")
  @Key("pagingToolbarOf")
  String pagingToolbarOf();

  /**
   * Translated "Page".
   * 
   * @return translated "Page"
   */
  @DefaultMessage("Page")
  @Key("pagingToolbarPage")
  String pagingToolbarPage();

  /**
   * Translated "Previous page".
   * 
   * @return translated "Previous page"
   */
  @DefaultMessage("Previous page")
  @Key("pagingToolbarPrevPage")
  String pagingToolbarPrevPage();

  /**
   * Translated "Refresh page".
   * 
   * @return translated "Refresh page"
   */
  @DefaultMessage("Refresh page")
  @Key("pagingToolbarRefresh")
  String pagingToolbarRefresh();

  /**
   * Translated "of".
   * 
   * @return translated "of"
   */
  @DefaultMessage("of")
  @Key("pagingToolbarShowingMid")
  String pagingToolbarShowingMid();

  /**
   * Translated "results".
   * 
   * @return translated "results"
   */
  @DefaultMessage("results")
  @Key("pagingToolbarShowingPost")
  String pagingToolbarShowingPost();

  /**
   * Translated "Displaying".
   * 
   * @return translated "Displaying"
   */
  @DefaultMessage("Displaying")
  @Key("pagingToolbarShowingPre")
  String pagingToolbarShowingPre();

  /**
   * Translated "Password field is mandatory.".
   * 
   * @return translated "Password field is mandatory."
   */
  @DefaultMessage("Password field is mandatory.")
  @Key("passwordFieldRequired")
  String passwordFieldRequired();

  /**
   * Translated "Alert".
   * 
   * @return translated "Alert"
   */
  @DefaultMessage("Alert")
  @Key("popupAlert")
  String popupAlert();

  /**
   * Translated "Error".
   * 
   * @return translated "Error"
   */
  @DefaultMessage("Error")
  @Key("popupError")
  String popupError();

  /**
   * Translated "Info".
   * 
   * @return translated "Info"
   */
  @DefaultMessage("Info")
  @Key("popupInfo")
  String popupInfo();

  /**
   * Translated "Data by Asset".
   * 
   * @return translated "Data by Asset"
   */
  @DefaultMessage("Data by Asset")
  @Key("queryByAsset")
  String queryByAsset();

  /**
   * Translated "Data by Topic".
   * 
   * @return translated "Data by Topic"
   */
  @DefaultMessage("Data by Topic")
  @Key("queryByTopic")
  String queryByTopic();

  /**
   * Translated "Characters not allowed: {0}".
   * 
   * @return translated "Characters not allowed: {0}"
   */
  @DefaultMessage("Characters not allowed: {0}")
  @Key("regexValidatorErrorMessage")
  String regexValidatorErrorMessage(String arg0);

  /**
   * Translated "Reset".
   * 
   * @return translated "Reset"
   */
  @DefaultMessage("Reset")
  @Key("reset")
  String reset();

  /**
   * Translated "Reset Login Values".
   * 
   * @return translated "Reset Login Values"
   */
  @DefaultMessage("Reset Login Values")
  @Key("resetLoginValuesButton")
  String resetLoginValuesButton();

  /**
   * Translated "Roles".
   * 
   * @return translated "Roles"
   */
  @DefaultMessage("Roles")
  @Key("roles")
  String roles();

  /**
   * Translated "Rollback".
   * 
   * @return translated "Rollback"
   */
  @DefaultMessage("Rollback")
  @Key("rollback")
  String rollback();

  /**
   * Translated "Rolling back...".
   * 
   * @return translated "Rolling back..."
   */
  @DefaultMessage("Rolling back...")
  @Key("rollingBack")
  String rollingBack();

  /**
   * Translated "Schedule".
   * 
   * @return translated "Schedule"
   */
  @DefaultMessage("Schedule")
  @Key("scheduleButton")
  String scheduleButton();

  /**
   * Translated "Your form is expired.".
   * 
   * @return translated "Your form is expired."
   */
  @DefaultMessage("Your form is expired.")
  @Key("securityInvalidXSRFToken")
  String securityInvalidXSRFToken();

  /**
   * Translated "Error during the security token creation process.".
   * 
   * @return translated "Error during the security token creation process."
   */
  @DefaultMessage("Error during the security token creation process.")
  @Key("securityTokenError")
  String securityTokenError();

  /**
   * Translated "Select All Text".
   * 
   * @return translated "Select All Text"
   */
  @DefaultMessage("Select All Text")
  @Key("selectAllTextButton")
  String selectAllTextButton();

  /**
   * Translated "Selected".
   * 
   * @return translated "Selected"
   */
  @DefaultMessage("Selected")
  @Key("selected")
  String selected();

  /**
   * Translated "Settings".
   * 
   * @return translated "Settings"
   */
  @DefaultMessage("Settings")
  @Key("settings")
  String settings();

  /**
   * Translated "The Administrator password has not been validated.".
   * 
   * @return translated "The Administrator password has not been validated."
   */
  @DefaultMessage("The Administrator password has not been validated.")
  @Key("settingsAdminPasswordsDoNotMatchError")
  String settingsAdminPasswordsDoNotMatchError();

  /**
   * Translated "Confirm Password".
   * 
   * @return translated "Confirm Password"
   */
  @DefaultMessage("Confirm Password")
  @Key("settingsAdminPwdConfirm")
  String settingsAdminPwdConfirm();

  /**
   * Translated "Current Password".
   * 
   * @return translated "Current Password"
   */
  @DefaultMessage("Current Password")
  @Key("settingsAdminPwdCurrent")
  String settingsAdminPwdCurrent();

  /**
   * Translated "New Password".
   * 
   * @return translated "New Password"
   */
  @DefaultMessage("New Password")
  @Key("settingsAdminPwdNew")
  String settingsAdminPwdNew();

  /**
   * Translated "The Administrator password has been changed.".
   * 
   * @return translated "The Administrator password has been changed."
   */
  @DefaultMessage("The Administrator password has been changed.")
  @Key("settingsAdministratorPasswordChanged")
  String settingsAdministratorPasswordChanged();

  /**
   * Translated "Administrator Password Management".
   * 
   * @return translated "Administrator Password Management"
   */
  @DefaultMessage("Administrator Password Management")
  @Key("settingsChangeAdminPassword")
  String settingsChangeAdminPassword();

  /**
   * Translated "SMTP configuration".
   * 
   * @return translated "SMTP configuration"
   */
  @DefaultMessage("SMTP configuration")
  @Key("settingsChangeSMTPConfiguration")
  String settingsChangeSMTPConfiguration();

  /**
   * Translated "Current SSL Certificate &amp; Key".
   * 
   * @return translated "Current SSL Certificate &amp; Key"
   */
  @DefaultMessage("Current SSL Certificate &amp; Key")
  @Key("settingsCurrentSSLCertificateAndKey")
  String settingsCurrentSSLCertificateAndKey();

  /**
   * Translated "Account Info".
   * 
   * @return translated "Account Info"
   */
  @DefaultMessage("Account Info")
  @Key("settingsDescriptionTitle")
  String settingsDescriptionTitle();

  /**
   * Translated "Install New Certificate".
   * 
   * @return translated "Install New Certificate"
   */
  @DefaultMessage("Install New Certificate")
  @Key("settingsInstallSSLCertificate")
  String settingsInstallSSLCertificate();

  /**
   * Translated "Also Monit configuration has been changed.".
   * 
   * @return translated "Also Monit configuration has been changed."
   */
  @DefaultMessage("Also Monit configuration has been changed.")
  @Key("settingsMonitConfigurationChanged")
  String settingsMonitConfigurationChanged();

  /**
   * Translated "New SSL Certificate &amp; Key".
   * 
   * @return translated "New SSL Certificate &amp; Key"
   */
  @DefaultMessage("New SSL Certificate &amp; Key")
  @Key("settingsNewSSLCertificateAndKey")
  String settingsNewSSLCertificateAndKey();

  /**
   * Translated "The SMTP configuration has been changed.".
   * 
   * @return translated "The SMTP configuration has been changed."
   */
  @DefaultMessage("The SMTP configuration has been changed.")
  @Key("settingsSMTPConfigurationChanged")
  String settingsSMTPConfigurationChanged();

  /**
   * Translated "Confirm SMTP Password".
   * 
   * @return translated "Confirm SMTP Password"
   */
  @DefaultMessage("Confirm SMTP Password")
  @Key("settingsSMTPConfirmPassword")
  String settingsSMTPConfirmPassword();

  /**
   * Translated "SMTP From Address".
   * 
   * @return translated "SMTP From Address"
   */
  @DefaultMessage("SMTP From Address")
  @Key("settingsSMTPFromAddress")
  String settingsSMTPFromAddress();

  /**
   * Translated "SMTP Server".
   * 
   * @return translated "SMTP Server"
   */
  @DefaultMessage("SMTP Server")
  @Key("settingsSMTPHost")
  String settingsSMTPHost();

  /**
   * Translated "SMTP Password".
   * 
   * @return translated "SMTP Password"
   */
  @DefaultMessage("SMTP Password")
  @Key("settingsSMTPPassword")
  String settingsSMTPPassword();

  /**
   * Translated "SMTP Port".
   * 
   * @return translated "SMTP Port"
   */
  @DefaultMessage("SMTP Port")
  @Key("settingsSMTPPort")
  String settingsSMTPPort();

  /**
   * Translated "Use SSL".
   * 
   * @return translated "Use SSL"
   */
  @DefaultMessage("Use SSL")
  @Key("settingsSMTPUseSSL")
  String settingsSMTPUseSSL();

  /**
   * Translated "Use TLS".
   * 
   * @return translated "Use TLS"
   */
  @DefaultMessage("Use TLS")
  @Key("settingsSMTPUseTLS")
  String settingsSMTPUseTLS();

  /**
   * Translated "SMTP Username".
   * 
   * @return translated "SMTP Username"
   */
  @DefaultMessage("SMTP Username")
  @Key("settingsSMTPUsername")
  String settingsSMTPUsername();

  /**
   * Translated "<br><b>The certificate you just uploaded has not been installed yet.<br>To install, click the button below.<br><br>Please, notice that the web server Tomcat will be restarted. Hence, you will have to reload the Console page.</b><br><br><br>".
   * 
   * @return translated "<br><b>The certificate you just uploaded has not been installed yet.<br>To install, click the button below.<br><br>Please, notice that the web server Tomcat will be restarted. Hence, you will have to reload the Console page.</b><br><br><br>"
   */
  @DefaultMessage("<br><b>The certificate you just uploaded has not been installed yet.<br>To install, click the button below.<br><br>Please, notice that the web server Tomcat will be restarted. Hence, you will have to reload the Console page.</b><br><br><br>")
  @Key("settingsSSLCertificateInstallMessage")
  String settingsSSLCertificateInstallMessage();

  /**
   * Translated "The new SSL Certificate and Key have been installed.".
   * 
   * @return translated "The new SSL Certificate and Key have been installed."
   */
  @DefaultMessage("The new SSL Certificate and Key have been installed.")
  @Key("settingsSSLConfigurationChanged")
  String settingsSSLConfigurationChanged();

  /**
   * Translated "The SSL Certificate and Key files have been uploaded.".
   * 
   * @return translated "The SSL Certificate and Key files have been uploaded."
   */
  @DefaultMessage("The SSL Certificate and Key files have been uploaded.")
  @Key("settingsSSLFileUploaded")
  String settingsSSLFileUploaded();

  /**
   * Translated "Upload New Certificate".
   * 
   * @return translated "Upload New Certificate"
   */
  @DefaultMessage("Upload New Certificate")
  @Key("settingsSSLUploadButton")
  String settingsSSLUploadButton();

  /**
   * Translated "Account Settings".
   * 
   * @return translated "Account Settings"
   */
  @DefaultMessage("Account Settings")
  @Key("settingsTabTitle")
  String settingsTabTitle();

  /**
   * Translated "Show details".
   * 
   * @return translated "Show details"
   */
  @DefaultMessage("Show details")
  @Key("showDetails")
  String showDetails();

  /**
   * Translated "Sometimes Failed".
   * 
   * @return translated "Sometimes Failed"
   */
  @DefaultMessage("Sometimes Failed")
  @Key("sometimesFailed")
  String sometimesFailed();

  /**
   * Translated "No {0}s to show".
   * 
   * @return translated "No {0}s to show"
   */
  @DefaultMessage("No {0}s to show")
  @Key("specificPagingToolbarNoResult")
  String specificPagingToolbarNoResult(String arg0);

  /**
   * Translated "{0}s".
   * 
   * @return translated "{0}s"
   */
  @DefaultMessage("{0}s")
  @Key("specificPagingToolbarShowingPost")
  String specificPagingToolbarShowingPost(String arg0);

  /**
   * Translated "Please specify end date.".
   * 
   * @return translated "Please specify end date."
   */
  @DefaultMessage("Please specify end date.")
  @Key("specifyEndDate")
  String specifyEndDate();

  /**
   * Translated "Please specify end time.".
   * 
   * @return translated "Please specify end time."
   */
  @DefaultMessage("Please specify end time.")
  @Key("specifyEndTime")
  String specifyEndTime();

  /**
   * Translated "SSO in progress".
   * 
   * @return translated "SSO in progress"
   */
  @DefaultMessage("SSO in progress")
  @Key("ssoWaitDialog.text")
  String ssoWaitDialog_text();

  /**
   * Translated "Please wait…".
   * 
   * @return translated "Please wait…"
   */
  @DefaultMessage("Please wait…")
  @Key("ssoWaitDialog.title")
  String ssoWaitDialog_title();

  /**
   * Translated "String".
   * 
   * @return translated "String"
   */
  @DefaultMessage("String")
  @Key("stringType")
  String stringType();

  /**
   * Translated "Submit".
   * 
   * @return translated "Submit"
   */
  @DefaultMessage("Submit")
  @Key("submitButton")
  String submitButton();

  /**
   * Translated "Success".
   * 
   * @return translated "Success"
   */
  @DefaultMessage("Success")
  @Key("success")
  String success();

  /**
   * Translated "Suspended".
   * 
   * @return translated "Suspended"
   */
  @DefaultMessage("Suspended")
  @Key("suspended")
  String suspended();

  /**
   * Translated "Welcome, {0}.".
   * 
   * @return translated "Welcome, {0}."
   */
  @DefaultMessage("Welcome, {0}.")
  @Key("swelcome")
  String swelcome(String arg0);

  /**
   * Translated "Sync".
   * 
   * @return translated "Sync"
   */
  @DefaultMessage("Sync")
  @Key("syncButton")
  String syncButton();

  /**
   * Translated "Synchronizing...".
   * 
   * @return translated "Synchronizing..."
   */
  @DefaultMessage("Synchronizing...")
  @Key("syncing")
  String syncing();

  /**
   * Translated "Certificate".
   * 
   * @return translated "Certificate"
   */
  @DefaultMessage("Certificate")
  @Key("tabCertificate")
  String tabCertificate();

  /**
   * Translated "No {0}s selected".
   * 
   * @return translated "No {0}s selected"
   */
  @DefaultMessage("No {0}s selected")
  @Key("tabDescriptionNoItemSelected")
  String tabDescriptionNoItemSelected(String arg0);

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("tabGeneral")
  String tabGeneral();

  /**
   * Translated "Health Check Logs".
   * 
   * @return translated "Health Check Logs"
   */
  @DefaultMessage("Health Check Logs")
  @Key("tabHealthCheckLogs")
  String tabHealthCheckLogs();

  /**
   * Translated "Map".
   * 
   * @return translated "Map"
   */
  @DefaultMessage("Map")
  @Key("tabMap")
  String tabMap();

  /**
   * Translated "VPN".
   * 
   * @return translated "VPN"
   */
  @DefaultMessage("VPN")
  @Key("tabRemoteAccess")
  String tabRemoteAccess();

  /**
   * Translated "Table".
   * 
   * @return translated "Table"
   */
  @DefaultMessage("Table")
  @Key("tabTable")
  String tabTable();

  /**
   * Translated "Usages".
   * 
   * @return translated "Usages"
   */
  @DefaultMessage("Usages")
  @Key("tabUsage")
  String tabUsage();

  /**
   * Translated "Classname".
   * 
   * @return translated "Classname"
   */
  @DefaultMessage("Classname")
  @Key("taskClassname")
  String taskClassname();

  /**
   * Translated "Completed On".
   * 
   * @return translated "Completed On"
   */
  @DefaultMessage("Completed On")
  @Key("taskCompletedOn")
  String taskCompletedOn();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("taskCreatedOn")
  String taskCreatedOn();

  /**
   * Translated "Are you sure you want to delete task with ID {0}?".
   * 
   * @return translated "Are you sure you want to delete task with ID {0}?"
   */
  @DefaultMessage("Are you sure you want to delete task with ID {0}?")
  @Key("taskDeleteConfirmation")
  String taskDeleteConfirmation(String arg0);

  /**
   * Translated "The task {0} has been deleted.".
   * 
   * @return translated "The task {0} has been deleted."
   */
  @DefaultMessage("The task {0} has been deleted.")
  @Key("taskDeletedConfirmation")
  String taskDeletedConfirmation(String arg0);

  /**
   * Translated "Log".
   * 
   * @return translated "Log"
   */
  @DefaultMessage("Log")
  @Key("taskLog")
  String taskLog();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("taskName")
  String taskName();

  /**
   * Translated "Refresh Log".
   * 
   * @return translated "Refresh Log"
   */
  @DefaultMessage("Refresh Log")
  @Key("taskRefreshButton")
  String taskRefreshButton();

  /**
   * Translated "The task {0} has been queued again.".
   * 
   * @return translated "The task {0} has been queued again."
   */
  @DefaultMessage("The task {0} has been queued again.")
  @Key("taskRetriedConfirmation")
  String taskRetriedConfirmation(String arg0);

  /**
   * Translated "Retry".
   * 
   * @return translated "Retry"
   */
  @DefaultMessage("Retry")
  @Key("taskRetryButton")
  String taskRetryButton();

  /**
   * Translated "Are you sure you want to retry task named {0}?".
   * 
   * @return translated "Are you sure you want to retry task named {0}?"
   */
  @DefaultMessage("Are you sure you want to retry task named {0}?")
  @Key("taskRetryConfirmation")
  String taskRetryConfirmation(String arg0);

  /**
   * Translated "Started On".
   * 
   * @return translated "Started On"
   */
  @DefaultMessage("Started On")
  @Key("taskStartedOn")
  String taskStartedOn();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("taskStatus")
  String taskStatus();

  /**
   * Translated "No Tasks Defined".
   * 
   * @return translated "No Tasks Defined"
   */
  @DefaultMessage("No Tasks Defined")
  @Key("taskTableNoTasks")
  String taskTableNoTasks();

  /**
   * Translated "Timestamp".
   * 
   * @return translated "Timestamp"
   */
  @DefaultMessage("Timestamp")
  @Key("timestamp")
  String timestamp();

  /**
   * Translated "Today {0}".
   * 
   * @return translated "Today {0}"
   */
  @DefaultMessage("Today {0}")
  @Key("today")
  String today(String arg0);

  /**
   * Translated "Tomorrow {0}".
   * 
   * @return translated "Tomorrow {0}"
   */
  @DefaultMessage("Tomorrow {0}")
  @Key("tomorrow")
  String tomorrow(String arg0);

  /**
   * Translated "Topic".
   * 
   * @return translated "Topic"
   */
  @DefaultMessage("Topic")
  @Key("topic")
  String topic();

  /**
   * Translated "true".
   * 
   * @return translated "true"
   */
  @DefaultMessage("true")
  @Key("trueLabel")
  String trueLabel();

  /**
   * Translated "Under Provisioning".
   * 
   * @return translated "Under Provisioning"
   */
  @DefaultMessage("Under Provisioning")
  @Key("underProvisioning")
  String underProvisioning();

  /**
   * Translated "Unknown".
   * 
   * @return translated "Unknown"
   */
  @DefaultMessage("Unknown")
  @Key("unknown")
  String unknown();

  /**
   * Translated "Unlimited".
   * 
   * @return translated "Unlimited"
   */
  @DefaultMessage("Unlimited")
  @Key("unlimited")
  String unlimited();

  /**
   * Translated "There are unsaved changes. Do you want to discard them and continue?".
   * 
   * @return translated "There are unsaved changes. Do you want to discard them and continue?"
   */
  @DefaultMessage("There are unsaved changes. Do you want to discard them and continue?")
  @Key("unsavedChanges")
  String unsavedChanges();

  /**
   * Translated "Update".
   * 
   * @return translated "Update"
   */
  @DefaultMessage("Update")
  @Key("updateButton")
  String updateButton();

  /**
   * Translated "Upload and Apply".
   * 
   * @return translated "Upload and Apply"
   */
  @DefaultMessage("Upload and Apply")
  @Key("upload")
  String upload();

  /**
   * Translated "Upload".
   * 
   * @return translated "Upload"
   */
  @DefaultMessage("Upload")
  @Key("uploadButton")
  String uploadButton();

  /**
   * Translated "URL".
   * 
   * @return translated "URL"
   */
  @DefaultMessage("URL")
  @Key("urlLabel")
  String urlLabel();

  /**
   * Translated "Usages".
   * 
   * @return translated "Usages"
   */
  @DefaultMessage("Usages")
  @Key("usages")
  String usages();

  /**
   * Translated "Administrator".
   * 
   * @return translated "Administrator"
   */
  @DefaultMessage("Administrator")
  @Key("userAdministrator")
  String userAdministrator();

  /**
   * Translated "Forget trusted devices".
   * 
   * @return translated "Forget trusted devices"
   */
  @DefaultMessage("Forget trusted devices")
  @Key("userButtonTrustReset")
  String userButtonTrustReset();

  /**
   * Translated "You cannot delete yourself.".
   * 
   * @return translated "You cannot delete yourself."
   */
  @DefaultMessage("You cannot delete yourself.")
  @Key("userCannotDeleteItself")
  String userCannotDeleteItself();

  /**
   * Translated "The user {0} has been created.".
   * 
   * @return translated "The user {0} has been created."
   */
  @DefaultMessage("The user {0} has been created.")
  @Key("userCreatedConfirmation")
  String userCreatedConfirmation(String arg0);

  /**
   * Translated "Are you sure you want to delete user {0}?".
   * 
   * @return translated "Are you sure you want to delete user {0}?"
   */
  @DefaultMessage("Are you sure you want to delete user {0}?")
  @Key("userDeleteConfirmation")
  String userDeleteConfirmation(String arg0);

  /**
   * Translated "The user {0} has been deleted.".
   * 
   * @return translated "The user {0} has been deleted."
   */
  @DefaultMessage("The user {0} has been deleted.")
  @Key("userDeletedConfirmation")
  String userDeletedConfirmation(String arg0);

  /**
   * Translated "Email".
   * 
   * @return translated "Email"
   */
  @DefaultMessage("Email")
  @Key("userEmail")
  String userEmail();

  /**
   * Translated "Access".
   * 
   * @return translated "Access"
   */
  @DefaultMessage("Access")
  @Key("userFormAccess")
  String userFormAccess();

  /**
   * Translated "Multi factor authentication".
   * 
   * @return translated "Multi factor authentication"
   */
  @DefaultMessage("Multi factor authentication")
  @Key("userFormBarcode")
  String userFormBarcode();

  /**
   * Translated "Confirm Password".
   * 
   * @return translated "Confirm Password"
   */
  @DefaultMessage("Confirm Password")
  @Key("userFormConfirmPassword")
  String userFormConfirmPassword();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultMessage("Display Name")
  @Key("userFormDisplayName")
  String userFormDisplayName();

  /**
   * Translated "Email".
   * 
   * @return translated "Email"
   */
  @DefaultMessage("Email")
  @Key("userFormEmail")
  String userFormEmail();

  /**
   * Translated "Help".
   * 
   * @return translated "Help"
   */
  @DefaultMessage("Help")
  @Key("userFormHelp")
  String userFormHelp();

  /**
   * Translated "Information".
   * 
   * @return translated "Information"
   */
  @DefaultMessage("Information")
  @Key("userFormInfo")
  String userFormInfo();

  /**
   * Translated "User Information".
   * 
   * @return translated "User Information"
   */
  @DefaultMessage("User Information")
  @Key("userFormInformation")
  String userFormInformation();

  /**
   * Translated "Locked".
   * 
   * @return translated "Locked"
   */
  @DefaultMessage("Locked")
  @Key("userFormLocked")
  String userFormLocked();

  /**
   * Translated "Locked On".
   * 
   * @return translated "Locked On"
   */
  @DefaultMessage("Locked On")
  @Key("userFormLockedOn")
  String userFormLockedOn();

  /**
   * Translated "You can decide to trust this device. Afterwards you will not be asked to enter MFA codes upon login for the next 30 days.".
   * 
   * @return translated "You can decide to trust this device. Afterwards you will not be asked to enter MFA codes upon login for the next 30 days."
   */
  @DefaultMessage("You can decide to trust this device. Afterwards you will not be asked to enter MFA codes upon login for the next 30 days.")
  @Key("userFormLockedTooltip")
  String userFormLockedTooltip();

  /**
   * Translated "Failed Login Attempts".
   * 
   * @return translated "Failed Login Attempts"
   */
  @DefaultMessage("Failed Login Attempts")
  @Key("userFormLoginAttempts")
  String userFormLoginAttempts();

  /**
   * Translated "Attempts Reset On".
   * 
   * @return translated "Attempts Reset On"
   */
  @DefaultMessage("Attempts Reset On")
  @Key("userFormLoginAttemptsResetOn")
  String userFormLoginAttemptsResetOn();

  /**
   * Translated "Last Login On".
   * 
   * @return translated "Last Login On"
   */
  @DefaultMessage("Last Login On")
  @Key("userFormLoginOn")
  String userFormLoginOn();

  /**
   * Translated "Username".
   * 
   * @return translated "Username"
   */
  @DefaultMessage("Username")
  @Key("userFormName")
  String userFormName();

  /**
   * Translated "New User".
   * 
   * @return translated "New User"
   */
  @DefaultMessage("New User")
  @Key("userFormNew")
  String userFormNew();

  /**
   * Translated "Password".
   * 
   * @return translated "Password"
   */
  @DefaultMessage("Password")
  @Key("userFormPassword")
  String userFormPassword();

  /**
   * Translated "Note: if the credentials are used by devices, update them accordingly in the device configuration.".
   * 
   * @return translated "Note: if the credentials are used by devices, update them accordingly in the device configuration."
   */
  @DefaultMessage("Note: if the credentials are used by devices, update them accordingly in the device configuration.")
  @Key("userFormPasswordTooltip")
  String userFormPasswordTooltip();

  /**
   * Translated "Permissions:".
   * 
   * @return translated "Permissions:"
   */
  @DefaultMessage("Permissions:")
  @Key("userFormPermissions")
  String userFormPermissions();

  /**
   * Translated "Administrator".
   * 
   * @return translated "Administrator"
   */
  @DefaultMessage("Administrator")
  @Key("userFormPermissionsAdministrator")
  String userFormPermissionsAdministrator();

  /**
   * Translated "Administrators have all permissions granted. There must be at least one Administrator per Account. ".
   * 
   * @return translated "Administrators have all permissions granted. There must be at least one Administrator per Account. "
   */
  @DefaultMessage("Administrators have all permissions granted. There must be at least one Administrator per Account. ")
  @Key("userFormPermissionsAdministratorToolTip")
  String userFormPermissionsAdministratorToolTip();

  /**
   * Translated "Role".
   * 
   * @return translated "Role"
   */
  @DefaultMessage("Role")
  @Key("userFormPermissionsRole")
  String userFormPermissionsRole();

  /**
   * Translated "Phone Number".
   * 
   * @return translated "Phone Number"
   */
  @DefaultMessage("Phone Number")
  @Key("userFormPhoneNumber")
  String userFormPhoneNumber();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("userFormStatus")
  String userFormStatus();

  /**
   * Translated "Unlock On".
   * 
   * @return translated "Unlock On"
   */
  @DefaultMessage("Unlock On")
  @Key("userFormUnlockOn")
  String userFormUnlockOn();

  /**
   * Translated "Update User: {0}".
   * 
   * @return translated "Update User: {0}"
   */
  @DefaultMessage("Update User: {0}")
  @Key("userFormUpdate")
  String userFormUpdate(String arg0);

  /**
   * Translated "Locked On".
   * 
   * @return translated "Locked On"
   */
  @DefaultMessage("Locked On")
  @Key("userLockedOn")
  String userLockedOn();

  /**
   * Translated "Login Attempts".
   * 
   * @return translated "Login Attempts"
   */
  @DefaultMessage("Login Attempts")
  @Key("userLoginAttempts")
  String userLoginAttempts();

  /**
   * Translated "Attempts Reset On".
   * 
   * @return translated "Attempts Reset On"
   */
  @DefaultMessage("Attempts Reset On")
  @Key("userLoginAttemptsResetOn")
  String userLoginAttemptsResetOn();

  /**
   * Translated "Username".
   * 
   * @return translated "Username"
   */
  @DefaultMessage("Username")
  @Key("userName")
  String userName();

  /**
   * Translated "Permissions".
   * 
   * @return translated "Permissions"
   */
  @DefaultMessage("Permissions")
  @Key("userPermissions")
  String userPermissions();

  /**
   * Translated "Enabled".
   * 
   * @return translated "Enabled"
   */
  @DefaultMessage("Enabled")
  @Key("userPermissionsEnabled")
  String userPermissionsEnabled();

  /**
   * Translated "Permission".
   * 
   * @return translated "Permission"
   */
  @DefaultMessage("Permission")
  @Key("userPermissionsPermissionName")
  String userPermissionsPermissionName();

  /**
   * Translated "No Users Defined".
   * 
   * @return translated "No Users Defined"
   */
  @DefaultMessage("No Users Defined")
  @Key("userTableNoUsers")
  String userTableNoUsers();

  /**
   * Translated "Reset login attempts".
   * 
   * @return translated "Reset login attempts"
   */
  @DefaultMessage("Reset login attempts")
  @Key("userTableResetValuesAction")
  String userTableResetValuesAction();

  /**
   * Translated "Unlocking User".
   * 
   * @return translated "Unlocking User"
   */
  @DefaultMessage("Unlocking User")
  @Key("userTableUnlockAction")
  String userTableUnlockAction();

  /**
   * Translated "Unlock On".
   * 
   * @return translated "Unlock On"
   */
  @DefaultMessage("Unlock On")
  @Key("userUnlockOn")
  String userUnlockOn();

  /**
   * Translated "The selected user has been unlocked or reset.".
   * 
   * @return translated "The selected user has been unlocked or reset."
   */
  @DefaultMessage("The selected user has been unlocked or reset.")
  @Key("userUnlockedConfirmation")
  String userUnlockedConfirmation();

  /**
   * Translated "The user {0} has been updated.".
   * 
   * @return translated "The user {0} has been updated."
   */
  @DefaultMessage("The user {0} has been updated.")
  @Key("userUpdatedConfirmation")
  String userUpdatedConfirmation(String arg0);

  /**
   * Translated "Username and password are mandatory fields.".
   * 
   * @return translated "Username and password are mandatory fields."
   */
  @DefaultMessage("Username and password are mandatory fields.")
  @Key("usernameAndPasswordRequired")
  String usernameAndPasswordRequired();

  /**
   * Translated "Username field is mandatory.".
   * 
   * @return translated "Username field is mandatory."
   */
  @DefaultMessage("Username field is mandatory.")
  @Key("usernameFieldRequired")
  String usernameFieldRequired();

  /**
   * Translated "Users".
   * 
   * @return translated "Users"
   */
  @DefaultMessage("Users")
  @Key("users")
  String users();

  /**
   * Translated "Validate".
   * 
   * @return translated "Validate"
   */
  @DefaultMessage("Validate")
  @Key("validateButton")
  String validateButton();

  /**
   * Translated "Please Wait...".
   * 
   * @return translated "Please Wait..."
   */
  @DefaultMessage("Please Wait...")
  @Key("waitMsg")
  String waitMsg();

  /**
   * Translated "Waiting for device...".
   * 
   * @return translated "Waiting for device..."
   */
  @DefaultMessage("Waiting for device...")
  @Key("waiting")
  String waiting();

  /**
   * Translated "Warning".
   * 
   * @return translated "Warning"
   */
  @DefaultMessage("Warning")
  @Key("warning")
  String warning();

  /**
   * Translated "Welcome".
   * 
   * @return translated "Welcome"
   */
  @DefaultMessage("Welcome")
  @Key("welcome")
  String welcome();

  /**
   * Translated "Yes".
   * 
   * @return translated "Yes"
   */
  @DefaultMessage("Yes")
  @Key("yes")
  String yes();

  /**
   * Translated "Yesterday {0}".
   * 
   * @return translated "Yesterday {0}"
   */
  @DefaultMessage("Yesterday {0}")
  @Key("yesterday")
  String yesterday(String arg0);

  /**
   * Translated "You are not allowed to {0} this {1}. Required permission:  {2}.".
   * 
   * @return translated "You are not allowed to {0} this {1}. Required permission:  {2}."
   */
  @DefaultMessage("You are not allowed to {0} this {1}. Required permission:  {2}.")
  @Key("youDontHavePermissionTo")
  String youDontHavePermissionTo(String arg0,  String arg1,  String arg2);
}
