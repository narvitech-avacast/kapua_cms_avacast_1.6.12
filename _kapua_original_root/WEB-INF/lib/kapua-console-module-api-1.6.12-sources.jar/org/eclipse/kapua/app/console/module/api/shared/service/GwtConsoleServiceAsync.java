package org.eclipse.kapua.app.console.module.api.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtConsoleServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.api.shared.service.GwtConsoleService
     */
    void getCustomEntityViews( AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.api.client.ui.view.descriptor.MainViewDescriptor>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.api.shared.service.GwtConsoleService
     */
    void getCustomTabsForView( java.lang.String viewClass, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.api.client.ui.view.descriptor.TabDescriptor>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.api.shared.service.GwtConsoleService
     */
    void updateComponentConfiguration( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String scopeId, java.lang.String parentScopeId, org.eclipse.kapua.app.console.module.api.shared.model.GwtConfigComponent configComponent, AsyncCallback<Void> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtConsoleServiceAsync instance;

        public static final GwtConsoleServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtConsoleServiceAsync) GWT.create( GwtConsoleService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "console" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
