package org.eclipse.kapua.app.console.module.job.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtJobStepServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobStepService
     */
    void query( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStepQuery gwtJobQuery, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStep>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobStepService
     */
    void findByJobId( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, java.lang.String scopeId, java.lang.String jobId, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStep>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobStepService
     */
    void create( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStepCreator gwtJobStepCreator, AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStep> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobStepService
     */
    void find( java.lang.String scopeId, java.lang.String jobStepId, AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStep> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobStepService
     */
    void delete( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String gwtScopeId, java.lang.String gwtJobStepId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobStepService
     */
    void update( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStep gwtJobStep, AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStep> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobStepService
     */
    void getJobStepPropertyLengthMax( AsyncCallback<java.lang.Integer> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobStepService
     */
    void trickGwt( AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStepProperty> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtJobStepServiceAsync instance;

        public static final GwtJobStepServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtJobStepServiceAsync) GWT.create( GwtJobStepService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "jobStep" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
