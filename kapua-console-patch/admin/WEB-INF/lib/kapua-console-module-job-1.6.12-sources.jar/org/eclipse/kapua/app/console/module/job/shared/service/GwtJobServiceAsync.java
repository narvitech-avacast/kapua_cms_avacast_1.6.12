package org.eclipse.kapua.app.console.module.job.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtJobServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobService
     */
    void query( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.job.shared.model.GwtJobQuery gwtJobQuery, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.job.shared.model.GwtJob>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobService
     */
    void create( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, org.eclipse.kapua.app.console.module.job.shared.model.GwtJobCreator gwtJobCreator, AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.GwtJob> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobService
     */
    void find( java.lang.String accountId, java.lang.String jobId, AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.GwtJob> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobService
     */
    void update( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, org.eclipse.kapua.app.console.module.job.shared.model.GwtJob gwtJob, AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.GwtJob> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobService
     */
    void delete( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, java.lang.String accountId, java.lang.String gwtJobId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobService
     */
    void deleteForced( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, java.lang.String accountId, java.lang.String gwtJobId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobService
     */
    void findJobDescription( java.lang.String gwtScopeId, java.lang.String gwtJobId, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.api.shared.model.GwtGroupedNVPair>> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtJobServiceAsync instance;

        public static final GwtJobServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtJobServiceAsync) GWT.create( GwtJobService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "job" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
