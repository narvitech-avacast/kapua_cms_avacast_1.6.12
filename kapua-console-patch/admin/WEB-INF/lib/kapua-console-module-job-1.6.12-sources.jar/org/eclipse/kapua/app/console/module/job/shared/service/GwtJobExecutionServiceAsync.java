package org.eclipse.kapua.app.console.module.job.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtJobExecutionServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobExecutionService
     */
    void findByJobId( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, java.lang.String scopeId, java.lang.String jobId, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobExecution>> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtJobExecutionServiceAsync instance;

        public static final GwtJobExecutionServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtJobExecutionServiceAsync) GWT.create( GwtJobExecutionService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "jobExecution" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
