package org.eclipse.kapua.app.console.module.job.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtTriggerDefinitionServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtTriggerDefinitionService
     */
    void findAll( AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.job.shared.model.scheduler.definition.GwtTriggerDefinition>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtTriggerDefinitionService
     */
    void find( java.lang.String triggerDefinitionId, AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.scheduler.definition.GwtTriggerDefinition> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtTriggerDefinitionService
     */
    void trickGwt( AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.scheduler.GwtTriggerProperty> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtTriggerDefinitionServiceAsync instance;

        public static final GwtTriggerDefinitionServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtTriggerDefinitionServiceAsync) GWT.create( GwtTriggerDefinitionService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "triggerDefinition" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
