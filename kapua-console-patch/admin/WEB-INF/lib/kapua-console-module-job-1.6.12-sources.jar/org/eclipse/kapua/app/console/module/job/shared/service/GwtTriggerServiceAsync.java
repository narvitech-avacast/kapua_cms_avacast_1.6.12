package org.eclipse.kapua.app.console.module.job.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtTriggerServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtTriggerService
     */
    void findByJobId( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, java.lang.String gwtScopeId, java.lang.String gwtJobId, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.job.shared.model.scheduler.GwtTrigger>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtTriggerService
     */
    void create( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, org.eclipse.kapua.app.console.module.job.shared.model.scheduler.GwtTriggerCreator gwtTriggerCreator, AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.scheduler.GwtTrigger> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtTriggerService
     */
    void delete( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String gwtScopeId, java.lang.String gwtTriggerId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtTriggerService
     */
    void validateCronExpression( java.lang.String cronExpression, AsyncCallback<java.lang.Boolean> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtTriggerService
     */
    void trickGwt( AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.scheduler.GwtTriggerProperty> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtTriggerServiceAsync instance;

        public static final GwtTriggerServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtTriggerServiceAsync) GWT.create( GwtTriggerService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "trigger" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
