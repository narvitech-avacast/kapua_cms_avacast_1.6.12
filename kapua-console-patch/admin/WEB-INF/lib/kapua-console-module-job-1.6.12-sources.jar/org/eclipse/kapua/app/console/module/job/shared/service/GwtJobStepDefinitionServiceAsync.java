package org.eclipse.kapua.app.console.module.job.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtJobStepDefinitionServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobStepDefinitionService
     */
    void findAll( AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStepDefinition>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobStepDefinitionService
     */
    void find( java.lang.String jobStepDefinitionId, AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStepDefinition> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobStepDefinitionService
     */
    void trickGwt( AsyncCallback<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStepProperty> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtJobStepDefinitionServiceAsync instance;

        public static final GwtJobStepDefinitionServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtJobStepDefinitionServiceAsync) GWT.create( GwtJobStepDefinitionService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "jobStepDefinition" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
