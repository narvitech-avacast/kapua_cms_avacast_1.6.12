package org.eclipse.kapua.app.console.module.job.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtJobTargetServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobTargetService
     */
    void query( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.job.shared.model.GwtJobTargetQuery gwtJobQuery, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobTarget>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobTargetService
     */
    void findByJobId( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, java.lang.String scopeId, java.lang.String jobId, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobTarget>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobTargetService
     */
    void findByJobId( java.lang.String scopeId, java.lang.String jobId, boolean fetchDetails, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobTarget>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobTargetService
     */
    void create( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String scopeId, java.lang.String jobId, java.util.List<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobTargetCreator> gwtJobTargetCreatorList, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.job.shared.model.GwtJobTarget>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobTargetService
     */
    void delete( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String accountId, java.lang.String gwtJobTargetId, AsyncCallback<Void> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtJobTargetServiceAsync instance;

        public static final GwtJobTargetServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtJobTargetServiceAsync) GWT.create( GwtJobTargetService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "jobTarget" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
