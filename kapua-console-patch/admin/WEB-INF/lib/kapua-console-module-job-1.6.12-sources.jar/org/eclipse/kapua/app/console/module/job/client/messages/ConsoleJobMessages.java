package org.eclipse.kapua.app.console.module.job.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/job/src/main/resources/org/eclipse/kapua/app/console/module/job/client/messages/ConsoleJobMessages.properties'.
 */
public interface ConsoleJobMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "All".
   * 
   * @return translated "All"
   */
  @DefaultMessage("All")
  @Key("allTargets")
  String allTargets();

  /**
   * Translated "Apply to targets".
   * 
   * @return translated "Apply to targets"
   */
  @DefaultMessage("Apply to targets")
  @Key("applyToTargets")
  String applyToTargets();

  /**
   * Translated "Job successfully created.".
   * 
   * @return translated "Job successfully created."
   */
  @DefaultMessage("Job successfully created.")
  @Key("dialogAddConfirmation")
  String dialogAddConfirmation();

  /**
   * Translated "Error while creating job: {0}".
   * 
   * @return translated "Error while creating job: {0}"
   */
  @DefaultMessage("Error while creating job: {0}")
  @Key("dialogAddError")
  String dialogAddError(String arg0);

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("dialogAddFieldDescription")
  String dialogAddFieldDescription();

  /**
   * Translated "Enter a job description for detailed information about the job.".
   * 
   * @return translated "Enter a job description for detailed information about the job."
   */
  @DefaultMessage("Enter a job description for detailed information about the job.")
  @Key("dialogAddFieldDescriptionTooltip")
  String dialogAddFieldDescriptionTooltip();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("dialogAddFieldName")
  String dialogAddFieldName();

  /**
   * Translated "Job name must be at least 3 characters long and can contain alphanumeric characters combined with dash and/or underscore and/or colon.".
   * 
   * @return translated "Job name must be at least 3 characters long and can contain alphanumeric characters combined with dash and/or underscore and/or colon."
   */
  @DefaultMessage("Job name must be at least 3 characters long and can contain alphanumeric characters combined with dash and/or underscore and/or colon.")
  @Key("dialogAddFieldNameTooltip")
  String dialogAddFieldNameTooltip();

  /**
   * Translated "New Job".
   * 
   * @return translated "New Job"
   */
  @DefaultMessage("New Job")
  @Key("dialogAddHeader")
  String dialogAddHeader();

  /**
   * Translated "Create a new job providing a name and an optional description.".
   * 
   * @return translated "Create a new job providing a name and an optional description."
   */
  @DefaultMessage("Create a new job providing a name and an optional description.")
  @Key("dialogAddInfo")
  String dialogAddInfo();

  /**
   * Translated "Schedule successfully created.".
   * 
   * @return translated "Schedule successfully created."
   */
  @DefaultMessage("Schedule successfully created.")
  @Key("dialogAddScheduleConfirmation")
  String dialogAddScheduleConfirmation();

  /**
   * Translated "The entered CRON schedule must be in UTC.".
   * 
   * @return translated "The entered CRON schedule must be in UTC."
   */
  @DefaultMessage("The entered CRON schedule must be in UTC.")
  @Key("dialogAddScheduleCronDescriptionLabel")
  String dialogAddScheduleCronDescriptionLabel();

  /**
   * Translated "Cron expression".
   * 
   * @return translated "Cron expression"
   */
  @DefaultMessage("Cron expression")
  @Key("dialogAddScheduleCronScheduleLabel")
  String dialogAddScheduleCronScheduleLabel();

  /**
   * Translated "Enter a valid retry interval in CRON format.".
   * 
   * @return translated "Enter a valid retry interval in CRON format."
   */
  @DefaultMessage("Enter a valid retry interval in CRON format.")
  @Key("dialogAddScheduleCronTooltip")
  String dialogAddScheduleCronTooltip();

  /**
   * Translated "Unable to validate CRON expression. Please check the CRON format and try again.".
   * 
   * @return translated "Unable to validate CRON expression. Please check the CRON format and try again."
   */
  @DefaultMessage("Unable to validate CRON expression. Please check the CRON format and try again.")
  @Key("dialogAddScheduleCronUnableToValidate")
  String dialogAddScheduleCronUnableToValidate();

  /**
   * Translated "Select Date".
   * 
   * @return translated "Select Date"
   */
  @DefaultMessage("Select Date")
  @Key("dialogAddScheduleDatePlaceholder")
  String dialogAddScheduleDatePlaceholder();

  /**
   * Translated "Schedule definition".
   * 
   * @return translated "Schedule definition"
   */
  @DefaultMessage("Schedule definition")
  @Key("dialogAddScheduleDefinitionCombo")
  String dialogAddScheduleDefinitionCombo();

  /**
   * Translated "Select A schedule definition...".
   * 
   * @return translated "Select A schedule definition..."
   */
  @DefaultMessage("Select A schedule definition...")
  @Key("dialogAddScheduleDefinitionComboEmpty")
  String dialogAddScheduleDefinitionComboEmpty();

  /**
   * Translated "Select a schedule definition.".
   * 
   * @return translated "Select a schedule definition."
   */
  @DefaultMessage("Select a schedule definition.")
  @Key("dialogAddScheduleDefinitionComboTooltip")
  String dialogAddScheduleDefinitionComboTooltip();

  /**
   * Translated "Ends on:".
   * 
   * @return translated "Ends on:"
   */
  @DefaultMessage("Ends on:")
  @Key("dialogAddScheduleEndsOnLabel")
  String dialogAddScheduleEndsOnLabel();

  /**
   * Translated "Time".
   * 
   * @return translated "Time"
   */
  @DefaultMessage("Time")
  @Key("dialogAddScheduleEndsOnTimeLabel")
  String dialogAddScheduleEndsOnTimeLabel();

  /**
   * Translated "Select a specific end time for the job.".
   * 
   * @return translated "Select a specific end time for the job."
   */
  @DefaultMessage("Select a specific end time for the job.")
  @Key("dialogAddScheduleEndsOnTimeTooltip")
  String dialogAddScheduleEndsOnTimeTooltip();

  /**
   * Translated "Select a specific end date for the job.".
   * 
   * @return translated "Select a specific end date for the job."
   */
  @DefaultMessage("Select a specific end date for the job.")
  @Key("dialogAddScheduleEndsOnTooltip")
  String dialogAddScheduleEndsOnTooltip();

  /**
   * Translated "Error while creating schedule: {0}".
   * 
   * @return translated "Error while creating schedule: {0}"
   */
  @DefaultMessage("Error while creating schedule: {0}")
  @Key("dialogAddScheduleError")
  String dialogAddScheduleError(String arg0);

  /**
   * Translated "Add Schedule".
   * 
   * @return translated "Add Schedule"
   */
  @DefaultMessage("Add Schedule")
  @Key("dialogAddScheduleHeader")
  String dialogAddScheduleHeader();

  /**
   * Translated "Add a new schedule for the selected job.".
   * 
   * @return translated "Add a new schedule for the selected job."
   */
  @DefaultMessage("Add a new schedule for the selected job.")
  @Key("dialogAddScheduleInfo")
  String dialogAddScheduleInfo();

  /**
   * Translated "Enter a unique schedule name.".
   * 
   * @return translated "Enter a unique schedule name."
   */
  @DefaultMessage("Enter a unique schedule name.")
  @Key("dialogAddScheduleNameTooltip")
  String dialogAddScheduleNameTooltip();

  /**
   * Translated "Retry interval [s]".
   * 
   * @return translated "Retry interval [s]"
   */
  @DefaultMessage("Retry interval [s]")
  @Key("dialogAddScheduleRetryIntervalLabel")
  String dialogAddScheduleRetryIntervalLabel();

  /**
   * Translated "Enter a valid retry interval for the job in seconds.".
   * 
   * @return translated "Enter a valid retry interval for the job in seconds."
   */
  @DefaultMessage("Enter a valid retry interval for the job in seconds.")
  @Key("dialogAddScheduleRetryIntervalTooltip")
  String dialogAddScheduleRetryIntervalTooltip();

  /**
   * Translated "Schedule name".
   * 
   * @return translated "Schedule name"
   */
  @DefaultMessage("Schedule name")
  @Key("dialogAddScheduleScheduleNameLabel")
  String dialogAddScheduleScheduleNameLabel();

  /**
   * Translated "The date in this field must be {0} or later.".
   * 
   * @return translated "The date in this field must be {0} or later."
   */
  @DefaultMessage("The date in this field must be {0} or later.")
  @Key("dialogAddScheduleStartsOnDateMin")
  String dialogAddScheduleStartsOnDateMin(String arg0);

  /**
   * Translated "Starts on:".
   * 
   * @return translated "Starts on:"
   */
  @DefaultMessage("Starts on:")
  @Key("dialogAddScheduleStartsOnLabel")
  String dialogAddScheduleStartsOnLabel();

  /**
   * Translated "Time".
   * 
   * @return translated "Time"
   */
  @DefaultMessage("Time")
  @Key("dialogAddScheduleStartsOnTimeLabel")
  String dialogAddScheduleStartsOnTimeLabel();

  /**
   * Translated "Select a specific start time for the job.".
   * 
   * @return translated "Select a specific start time for the job."
   */
  @DefaultMessage("Select a specific start time for the job.")
  @Key("dialogAddScheduleStartsOnTimeTooltip")
  String dialogAddScheduleStartsOnTimeTooltip();

  /**
   * Translated "Select a specific start date for the job.".
   * 
   * @return translated "Select a specific start date for the job."
   */
  @DefaultMessage("Select a specific start date for the job.")
  @Key("dialogAddScheduleStartsOnTooltip")
  String dialogAddScheduleStartsOnTooltip();

  /**
   * Translated "Select Time".
   * 
   * @return translated "Select Time"
   */
  @DefaultMessage("Select Time")
  @Key("dialogAddScheduleTimePlaceholder")
  String dialogAddScheduleTimePlaceholder();

  /**
   * Translated "Step successfully created.".
   * 
   * @return translated "Step successfully created."
   */
  @DefaultMessage("Step successfully created.")
  @Key("dialogAddStepConfirmation")
  String dialogAddStepConfirmation();

  /**
   * Translated "Step definition".
   * 
   * @return translated "Step definition"
   */
  @DefaultMessage("Step definition")
  @Key("dialogAddStepDefinitionCombo")
  String dialogAddStepDefinitionCombo();

  /**
   * Translated "Select A Step Definition".
   * 
   * @return translated "Select A Step Definition"
   */
  @DefaultMessage("Select A Step Definition")
  @Key("dialogAddStepDefinitionComboEmpty")
  String dialogAddStepDefinitionComboEmpty();

  /**
   * Translated "Select a job step definition.".
   * 
   * @return translated "Select a job step definition."
   */
  @DefaultMessage("Select a job step definition.")
  @Key("dialogAddStepDefinitionComboTooltip")
  String dialogAddStepDefinitionComboTooltip();

  /**
   * Translated "Job step description".
   * 
   * @return translated "Job step description"
   */
  @DefaultMessage("Job step description")
  @Key("dialogAddStepDescriptionEmpty")
  String dialogAddStepDescriptionEmpty();

  /**
   * Translated "Enter a job step description for detailed information about the step.".
   * 
   * @return translated "Enter a job step description for detailed information about the step."
   */
  @DefaultMessage("Enter a job step description for detailed information about the step.")
  @Key("dialogAddStepDescriptionTooltip")
  String dialogAddStepDescriptionTooltip();

  /**
   * Translated "Error while adding step: {0}".
   * 
   * @return translated "Error while adding step: {0}"
   */
  @DefaultMessage("Error while adding step: {0}")
  @Key("dialogAddStepError")
  String dialogAddStepError(String arg0);

  /**
   * Translated "Error while fetching step definitions: {0}".
   * 
   * @return translated "Error while fetching step definitions: {0}"
   */
  @DefaultMessage("Error while fetching step definitions: {0}")
  @Key("dialogAddStepErrorFetchStepDefinitions")
  String dialogAddStepErrorFetchStepDefinitions(String arg0);

  /**
   * Translated "Add Step".
   * 
   * @return translated "Add Step"
   */
  @DefaultMessage("Add Step")
  @Key("dialogAddStepHeader")
  String dialogAddStepHeader();

  /**
   * Translated "Add a new step to the selected job.".
   * 
   * @return translated "Add a new step to the selected job."
   */
  @DefaultMessage("Add a new step to the selected job.")
  @Key("dialogAddStepInfo")
  String dialogAddStepInfo();

  /**
   * Translated "Job step description".
   * 
   * @return translated "Job step description"
   */
  @DefaultMessage("Job step description")
  @Key("dialogAddStepJobDescriptionLabel")
  String dialogAddStepJobDescriptionLabel();

  /**
   * Translated "Job step name".
   * 
   * @return translated "Job step name"
   */
  @DefaultMessage("Job step name")
  @Key("dialogAddStepJobNameLabel")
  String dialogAddStepJobNameLabel();

  /**
   * Translated "Job step name".
   * 
   * @return translated "Job step name"
   */
  @DefaultMessage("Job step name")
  @Key("dialogAddStepNameEmpty")
  String dialogAddStepNameEmpty();

  /**
   * Translated "Enter a unique Job step name.".
   * 
   * @return translated "Enter a unique Job step name."
   */
  @DefaultMessage("Enter a unique Job step name.")
  @Key("dialogAddStepNameTooltip")
  String dialogAddStepNameTooltip();

  /**
   * Translated "Enter a timeout in milliseconds. This is timeout between pressing the Start button and actual job execution.".
   * 
   * @return translated "Enter a timeout in milliseconds. This is timeout between pressing the Start button and actual job execution."
   */
  @DefaultMessage("Enter a timeout in milliseconds. This is timeout between pressing the Start button and actual job execution.")
  @Key("dialogAddStepTimeoutTooltip")
  String dialogAddStepTimeoutTooltip();

  /**
   * Translated "All available targets successfully added.".
   * 
   * @return translated "All available targets successfully added."
   */
  @DefaultMessage("All available targets successfully added.")
  @Key("dialogAddTargetConfirmation")
  String dialogAddTargetConfirmation();

  /**
   * Translated "No new targets found to be added.".
   * 
   * @return translated "No new targets found to be added."
   */
  @DefaultMessage("No new targets found to be added.")
  @Key("dialogAddTargetEmpty")
  String dialogAddTargetEmpty();

  /**
   * Translated "Error adding targets: {0}".
   * 
   * @return translated "Error adding targets: {0}"
   */
  @DefaultMessage("Error adding targets: {0}")
  @Key("dialogAddTargetError")
  String dialogAddTargetError(String arg0);

  /**
   * Translated "Add Targets".
   * 
   * @return translated "Add Targets"
   */
  @DefaultMessage("Add Targets")
  @Key("dialogAddTargetHeader")
  String dialogAddTargetHeader();

  /**
   * Translated "Select the targets that should be added to the job. Duplicate targets will not be added twice.".
   * 
   * @return translated "Select the targets that should be added to the job. Duplicate targets will not be added twice."
   */
  @DefaultMessage("Select the targets that should be added to the job. Duplicate targets will not be added twice.")
  @Key("dialogAddTargetInfo")
  String dialogAddTargetInfo();

  /**
   * Translated "Trigger Properties".
   * 
   * @return translated "Trigger Properties"
   */
  @DefaultMessage("Trigger Properties")
  @Key("dialogAddTriggerPropertiesFieldSetHeading")
  String dialogAddTriggerPropertiesFieldSetHeading();

  /**
   * Translated "Job successfully deleted.".
   * 
   * @return translated "Job successfully deleted."
   */
  @DefaultMessage("Job successfully deleted.")
  @Key("dialogDeleteConfirmation")
  String dialogDeleteConfirmation();

  /**
   * Translated "Job delete failed: {0}".
   * 
   * @return translated "Job delete failed: {0}"
   */
  @DefaultMessage("Job delete failed: {0}")
  @Key("dialogDeleteError")
  String dialogDeleteError(String arg0);

  /**
   * Translated "Delete Job: {0}".
   * 
   * @return translated "Delete Job: {0}"
   */
  @DefaultMessage("Delete Job: {0}")
  @Key("dialogDeleteForcedDialogHeader")
  String dialogDeleteForcedDialogHeader(String arg0);

  /**
   * Translated "Delete the selected job forcibly? This can lead to errors in the Job Engine and related components. Use only on critical situations.".
   * 
   * @return translated "Delete the selected job forcibly? This can lead to errors in the Job Engine and related components. Use only on critical situations."
   */
  @DefaultMessage("Delete the selected job forcibly? This can lead to errors in the Job Engine and related components. Use only on critical situations.")
  @Key("dialogDeleteForcedDialogInfo")
  String dialogDeleteForcedDialogInfo();

  /**
   * Translated "Selected job could not be deleted! Please check console log for errors.".
   * 
   * @return translated "Selected job could not be deleted! Please check console log for errors."
   */
  @DefaultMessage("Selected job could not be deleted! Please check console log for errors.")
  @Key("dialogDeleteForcedErrorMessage")
  String dialogDeleteForcedErrorMessage();

  /**
   * Translated "Job successfully deleted.".
   * 
   * @return translated "Job successfully deleted."
   */
  @DefaultMessage("Job successfully deleted.")
  @Key("dialogDeleteForcedStoppedMessage")
  String dialogDeleteForcedStoppedMessage();

  /**
   * Translated "Delete Job: {0}".
   * 
   * @return translated "Delete Job: {0}"
   */
  @DefaultMessage("Delete Job: {0}")
  @Key("dialogDeleteHeader")
  String dialogDeleteHeader(String arg0);

  /**
   * Translated "Are you sure you want to delete selected job and all associated entities?".
   * 
   * @return translated "Are you sure you want to delete selected job and all associated entities?"
   */
  @DefaultMessage("Are you sure you want to delete selected job and all associated entities?")
  @Key("dialogDeleteInfo")
  String dialogDeleteInfo();

  /**
   * Translated "Schedule successfully deleted.".
   * 
   * @return translated "Schedule successfully deleted."
   */
  @DefaultMessage("Schedule successfully deleted.")
  @Key("dialogDeleteScheduleConfirmation")
  String dialogDeleteScheduleConfirmation();

  /**
   * Translated "Error removing schedule: {0}".
   * 
   * @return translated "Error removing schedule: {0}"
   */
  @DefaultMessage("Error removing schedule: {0}")
  @Key("dialogDeleteScheduleError")
  String dialogDeleteScheduleError(String arg0);

  /**
   * Translated "Delete Schedule: {0}".
   * 
   * @return translated "Delete Schedule: {0}"
   */
  @DefaultMessage("Delete Schedule: {0}")
  @Key("dialogDeleteScheduleHeader")
  String dialogDeleteScheduleHeader(String arg0);

  /**
   * Translated "Are you sure you want to delete the selected schedule?".
   * 
   * @return translated "Are you sure you want to delete the selected schedule?"
   */
  @DefaultMessage("Are you sure you want to delete the selected schedule?")
  @Key("dialogDeleteScheduleInfo")
  String dialogDeleteScheduleInfo();

  /**
   * Translated "Step successfully deleted.".
   * 
   * @return translated "Step successfully deleted."
   */
  @DefaultMessage("Step successfully deleted.")
  @Key("dialogDeleteStepConfirmation")
  String dialogDeleteStepConfirmation();

  /**
   * Translated "Error removing step: {0}".
   * 
   * @return translated "Error removing step: {0}"
   */
  @DefaultMessage("Error removing step: {0}")
  @Key("dialogDeleteStepError")
  String dialogDeleteStepError(String arg0);

  /**
   * Translated "Delete Step: {0}".
   * 
   * @return translated "Delete Step: {0}"
   */
  @DefaultMessage("Delete Step: {0}")
  @Key("dialogDeleteStepHeader")
  String dialogDeleteStepHeader(String arg0);

  /**
   * Translated "Remove step from the job?".
   * 
   * @return translated "Remove step from the job?"
   */
  @DefaultMessage("Remove step from the job?")
  @Key("dialogDeleteStepInfo")
  String dialogDeleteStepInfo();

  /**
   * Translated "Targets successfully deleted.".
   * 
   * @return translated "Targets successfully deleted."
   */
  @DefaultMessage("Targets successfully deleted.")
  @Key("dialogDeleteTargetConfirmation")
  String dialogDeleteTargetConfirmation();

  /**
   * Translated "Error removing target: {0}".
   * 
   * @return translated "Error removing target: {0}"
   */
  @DefaultMessage("Error removing target: {0}")
  @Key("dialogDeleteTargetError")
  String dialogDeleteTargetError(String arg0);

  /**
   * Translated "Remove Target: {0}".
   * 
   * @return translated "Remove Target: {0}"
   */
  @DefaultMessage("Remove Target: {0}")
  @Key("dialogDeleteTargetHeader")
  String dialogDeleteTargetHeader(String arg0);

  /**
   * Translated "Are you sure you want to remove the selected target?".
   * 
   * @return translated "Are you sure you want to remove the selected target?"
   */
  @DefaultMessage("Are you sure you want to remove the selected target?")
  @Key("dialogDeleteTargetInfo")
  String dialogDeleteTargetInfo();

  /**
   * Translated "Job successfully updated.".
   * 
   * @return translated "Job successfully updated."
   */
  @DefaultMessage("Job successfully updated.")
  @Key("dialogEditConfirmation")
  String dialogEditConfirmation();

  /**
   * Translated "Job edit failed: {0}".
   * 
   * @return translated "Job edit failed: {0}"
   */
  @DefaultMessage("Job edit failed: {0}")
  @Key("dialogEditError")
  String dialogEditError(String arg0);

  /**
   * Translated "Edit Job: {0}".
   * 
   * @return translated "Edit Job: {0}"
   */
  @DefaultMessage("Edit Job: {0}")
  @Key("dialogEditHeader")
  String dialogEditHeader(String arg0);

  /**
   * Translated "Edit job''s data.".
   * 
   * @return translated "Edit job''s data."
   */
  @DefaultMessage("Edit job''s data.")
  @Key("dialogEditInfo")
  String dialogEditInfo();

  /**
   * Translated "Cannot load job: {0}".
   * 
   * @return translated "Cannot load job: {0}"
   */
  @DefaultMessage("Cannot load job: {0}")
  @Key("dialogEditLoadFailed")
  String dialogEditLoadFailed(String arg0);

  /**
   * Translated "Job schedule edited successfully.".
   * 
   * @return translated "Job schedule edited successfully."
   */
  @DefaultMessage("Job schedule edited successfully.")
  @Key("dialogEditScheduleConfirmation")
  String dialogEditScheduleConfirmation();

  /**
   * Translated "Job schedule edit failed: {0}".
   * 
   * @return translated "Job schedule edit failed: {0}"
   */
  @DefaultMessage("Job schedule edit failed: {0}")
  @Key("dialogEditScheduleError")
  String dialogEditScheduleError(String arg0);

  /**
   * Translated "Edit job schedule: {0}".
   * 
   * @return translated "Edit job schedule: {0}"
   */
  @DefaultMessage("Edit job schedule: {0}")
  @Key("dialogEditScheduleHeader")
  String dialogEditScheduleHeader(String arg0);

  /**
   * Translated "Edit job schedule data.".
   * 
   * @return translated "Edit job schedule data."
   */
  @DefaultMessage("Edit job schedule data.")
  @Key("dialogEditScheduleInfo")
  String dialogEditScheduleInfo();

  /**
   * Translated "Cannot load job schedule: {0}".
   * 
   * @return translated "Cannot load job schedule: {0}"
   */
  @DefaultMessage("Cannot load job schedule: {0}")
  @Key("dialogEditScheduleLoadFailed")
  String dialogEditScheduleLoadFailed(String arg0);

  /**
   * Translated "Step successfully updated.".
   * 
   * @return translated "Step successfully updated."
   */
  @DefaultMessage("Step successfully updated.")
  @Key("dialogEditStepConfirmation")
  String dialogEditStepConfirmation();

  /**
   * Translated "Edit Step".
   * 
   * @return translated "Edit Step"
   */
  @DefaultMessage("Edit Step")
  @Key("dialogEditStepHeader")
  String dialogEditStepHeader();

  /**
   * Translated "Cannot load step: {0}".
   * 
   * @return translated "Cannot load step: {0}"
   */
  @DefaultMessage("Cannot load step: {0}")
  @Key("dialogEditStepLoadFailed")
  String dialogEditStepLoadFailed(String arg0);

  /**
   * Translated "Error retrieving targets: {0}".
   * 
   * @return translated "Error retrieving targets: {0}"
   */
  @DefaultMessage("Error retrieving targets: {0}")
  @Key("dialogGetTargetError")
  String dialogGetTargetError(String arg0);

  /**
   * Translated "Export to CSV".
   * 
   * @return translated "Export to CSV"
   */
  @DefaultMessage("Export to CSV")
  @Key("exportToCSV")
  String exportToCSV();

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("filterFieldJobDescriptionLabel")
  String filterFieldJobDescriptionLabel();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("filterFieldJobNameLabel")
  String filterFieldJobNameLabel();

  /**
   * Translated "Job Filter".
   * 
   * @return translated "Job Filter"
   */
  @DefaultMessage("Job Filter")
  @Key("filterHeader")
  String filterHeader();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultMessage("Created By")
  @Key("gridJobColumnHeaderCreatedBy")
  String gridJobColumnHeaderCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("gridJobColumnHeaderCreatedOn")
  String gridJobColumnHeaderCreatedOn();

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("gridJobColumnHeaderDescription")
  String gridJobColumnHeaderDescription();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridJobColumnHeaderId")
  String gridJobColumnHeaderId();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("gridJobColumnHeaderName")
  String gridJobColumnHeaderName();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("gridJobColumnHeaderStatus")
  String gridJobColumnHeaderStatus();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("gridJobExecutionColumnHeaderStatus")
  String gridJobExecutionColumnHeaderStatus();

  /**
   * Translated "Ended on".
   * 
   * @return translated "Ended on"
   */
  @DefaultMessage("Ended on")
  @Key("gridJobExecutionsColumnHeaderEndedOnFormatted")
  String gridJobExecutionsColumnHeaderEndedOnFormatted();

  /**
   * Translated "Started on".
   * 
   * @return translated "Started on"
   */
  @DefaultMessage("Started on")
  @Key("gridJobExecutionsColumnHeaderStartedOnFormatted")
  String gridJobExecutionsColumnHeaderStartedOnFormatted();

  /**
   * Translated "Ends on".
   * 
   * @return translated "Ends on"
   */
  @DefaultMessage("Ends on")
  @Key("gridJobSchedulesColumnHeaderEndsOnFormatted")
  String gridJobSchedulesColumnHeaderEndsOnFormatted();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("gridJobSchedulesColumnHeaderName")
  String gridJobSchedulesColumnHeaderName();

  /**
   * Translated "Starts on".
   * 
   * @return translated "Starts on"
   */
  @DefaultMessage("Starts on")
  @Key("gridJobSchedulesColumnHeaderStartsOnFormatted")
  String gridJobSchedulesColumnHeaderStartsOnFormatted();

  /**
   * Translated "Schedule Type".
   * 
   * @return translated "Schedule Type"
   */
  @DefaultMessage("Schedule Type")
  @Key("gridJobSchedulesColumnHeaderTriggerDefinitionName")
  String gridJobSchedulesColumnHeaderTriggerDefinitionName();

  /**
   * Translated "Value".
   * 
   * @return translated "Value"
   */
  @DefaultMessage("Value")
  @Key("gridJobSchedulesColumnHeaderValue")
  String gridJobSchedulesColumnHeaderValue();

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("gridJobStepColumnHeaderDescription")
  String gridJobStepColumnHeaderDescription();

  /**
   * Translated "Definition name".
   * 
   * @return translated "Definition name"
   */
  @DefaultMessage("Definition name")
  @Key("gridJobStepColumnHeaderJobDefinitionName")
  String gridJobStepColumnHeaderJobDefinitionName();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("gridJobStepColumnHeaderJobName")
  String gridJobStepColumnHeaderJobName();

  /**
   * Translated "Step Index".
   * 
   * @return translated "Step Index"
   */
  @DefaultMessage("Step Index")
  @Key("gridJobStepColumnHeaderStepIndex")
  String gridJobStepColumnHeaderStepIndex();

  /**
   * Translated "Executions".
   * 
   * @return translated "Executions"
   */
  @DefaultMessage("Executions")
  @Key("gridJobTabExecutionsLabel")
  String gridJobTabExecutionsLabel();

  /**
   * Translated "Schedules".
   * 
   * @return translated "Schedules"
   */
  @DefaultMessage("Schedules")
  @Key("gridJobTabSchedulesLabel")
  String gridJobTabSchedulesLabel();

  /**
   * Translated "Steps".
   * 
   * @return translated "Steps"
   */
  @DefaultMessage("Steps")
  @Key("gridJobTabStepsLabel")
  String gridJobTabStepsLabel();

  /**
   * Translated "Targets".
   * 
   * @return translated "Targets"
   */
  @DefaultMessage("Targets")
  @Key("gridJobTabTargetsLabel")
  String gridJobTabTargetsLabel();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultMessage("Display Name")
  @Key("gridJobTargetColumnHeaderDisplayName")
  String gridJobTargetColumnHeaderDisplayName();

  /**
   * Translated "Client ID".
   * 
   * @return translated "Client ID"
   */
  @DefaultMessage("Client ID")
  @Key("gridJobTargetColumnHeaderJobClientId")
  String gridJobTargetColumnHeaderJobClientId();

  /**
   * Translated "Job Id".
   * 
   * @return translated "Job Id"
   */
  @DefaultMessage("Job Id")
  @Key("gridJobTargetColumnHeaderJobId")
  String gridJobTargetColumnHeaderJobId();

  /**
   * Translated "Step Index".
   * 
   * @return translated "Step Index"
   */
  @DefaultMessage("Step Index")
  @Key("gridJobTargetColumnHeaderJobStepIndex")
  String gridJobTargetColumnHeaderJobStepIndex();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("gridJobTargetColumnHeaderStatus")
  String gridJobTargetColumnHeaderStatus();

  /**
   * Translated "Status Message".
   * 
   * @return translated "Status Message"
   */
  @DefaultMessage("Status Message")
  @Key("gridJobTargetColumnHeaderStatusMessage")
  String gridJobTargetColumnHeaderStatusMessage();

  /**
   * Translated "Force Delete".
   * 
   * @return translated "Force Delete"
   */
  @DefaultMessage("Force Delete")
  @Key("jobDeleteForcedButton")
  String jobDeleteForcedButton();

  /**
   * Translated "Log".
   * 
   * @return translated "Log"
   */
  @DefaultMessage("Log")
  @Key("jobExecutionLogButton")
  String jobExecutionLogButton();

  /**
   * Translated "Job Execution Log".
   * 
   * @return translated "Job Execution Log"
   */
  @DefaultMessage("Job Execution Log")
  @Key("jobExecutionLogDialogHeader")
  String jobExecutionLogDialogHeader();

  /**
   * Translated "Stop".
   * 
   * @return translated "Stop"
   */
  @DefaultMessage("Stop")
  @Key("jobExecutionStopButton")
  String jobExecutionStopButton();

  /**
   * Translated "Stop job execution: {0}".
   * 
   * @return translated "Stop job execution: {0}"
   */
  @DefaultMessage("Stop job execution: {0}")
  @Key("jobExecutionStopDialogHeader")
  String jobExecutionStopDialogHeader(String arg0);

  /**
   * Translated "Stop the selected job execution?".
   * 
   * @return translated "Stop the selected job execution?"
   */
  @DefaultMessage("Stop the selected job execution?")
  @Key("jobExecutionStopDialogInfo")
  String jobExecutionStopDialogInfo();

  /**
   * Translated "Selected job execution could not be stopped. Either job execution has not been started or it could not be stopped. Please check console log for errors.".
   * 
   * @return translated "Selected job execution could not be stopped. Either job execution has not been started or it could not be stopped. Please check console log for errors."
   */
  @DefaultMessage("Selected job execution could not be stopped. Either job execution has not been started or it could not be stopped. Please check console log for errors.")
  @Key("jobExecutionStopErrorMessage")
  String jobExecutionStopErrorMessage();

  /**
   * Translated "Job execution successfully stopped.".
   * 
   * @return translated "Job execution successfully stopped."
   */
  @DefaultMessage("Job execution successfully stopped.")
  @Key("jobExecutionStopStoppedMessage")
  String jobExecutionStopStoppedMessage();

  /**
   * Translated "Restart".
   * 
   * @return translated "Restart"
   */
  @DefaultMessage("Restart")
  @Key("jobRestartButton")
  String jobRestartButton();

  /**
   * Translated "Restart Job: {0}".
   * 
   * @return translated "Restart Job: {0}"
   */
  @DefaultMessage("Restart Job: {0}")
  @Key("jobRestartDialogHeader")
  String jobRestartDialogHeader(String arg0);

  /**
   * Translated "Restart the selected job?<br><br>Please note that restarting the job, all the targets will restart the processing from the first step, regardless of their current step.".
   * 
   * @return translated "Restart the selected job?<br><br>Please note that restarting the job, all the targets will restart the processing from the first step, regardless of their current step."
   */
  @DefaultMessage("Restart the selected job?<br><br>Please note that restarting the job, all the targets will restart the processing from the first step, regardless of their current step.")
  @Key("jobRestartDialogInfo")
  String jobRestartDialogInfo();

  /**
   * Translated "Error restarting job: {0}".
   * 
   * @return translated "Error restarting job: {0}"
   */
  @DefaultMessage("Error restarting job: {0}")
  @Key("jobRestartErrorMessage")
  String jobRestartErrorMessage(String arg0);

  /**
   * Translated "Job successfully restarted.".
   * 
   * @return translated "Job successfully restarted."
   */
  @DefaultMessage("Job successfully restarted.")
  @Key("jobRestartRestartedMessage")
  String jobRestartRestartedMessage();

  /**
   * Translated "Restart".
   * 
   * @return translated "Restart"
   */
  @DefaultMessage("Restart")
  @Key("jobRestartTargetButton")
  String jobRestartTargetButton();

  /**
   * Translated "Restart Job {0} for target {1}".
   * 
   * @return translated "Restart Job {0} for target {1}"
   */
  @DefaultMessage("Restart Job {0} for target {1}")
  @Key("jobRestartTargetDialogHeader")
  String jobRestartTargetDialogHeader(String arg0,  String arg1);

  /**
   * Translated "Restart the selected job for the selected target?<br><br>Please note that restarting the job, the target will restart the processing from the first step, regardless of its current step.".
   * 
   * @return translated "Restart the selected job for the selected target?<br><br>Please note that restarting the job, the target will restart the processing from the first step, regardless of its current step."
   */
  @DefaultMessage("Restart the selected job for the selected target?<br><br>Please note that restarting the job, the target will restart the processing from the first step, regardless of its current step.")
  @Key("jobRestartTargetDialogInfo")
  String jobRestartTargetDialogInfo();

  /**
   * Translated "Error restarting job: {0}".
   * 
   * @return translated "Error restarting job: {0}"
   */
  @DefaultMessage("Error restarting job: {0}")
  @Key("jobRestartTargetErrorMessage")
  String jobRestartTargetErrorMessage(String arg0);

  /**
   * Translated "Job successfully restarted.".
   * 
   * @return translated "Job successfully restarted."
   */
  @DefaultMessage("Job successfully restarted.")
  @Key("jobRestartTargetRestartedMessage")
  String jobRestartTargetRestartedMessage();

  /**
   * Translated "Start".
   * 
   * @return translated "Start"
   */
  @DefaultMessage("Start")
  @Key("jobStartButton")
  String jobStartButton();

  /**
   * Translated "Start Job: {0}".
   * 
   * @return translated "Start Job: {0}"
   */
  @DefaultMessage("Start Job: {0}")
  @Key("jobStartDialogHeader")
  String jobStartDialogHeader(String arg0);

  /**
   * Translated "Start the selected job?".
   * 
   * @return translated "Start the selected job?"
   */
  @DefaultMessage("Start the selected job?")
  @Key("jobStartDialogInfo")
  String jobStartDialogInfo();

  /**
   * Translated "Error starting job: {0}".
   * 
   * @return translated "Error starting job: {0}"
   */
  @DefaultMessage("Error starting job: {0}")
  @Key("jobStartErrorMessage")
  String jobStartErrorMessage(String arg0);

  /**
   * Translated "Job successfully started.".
   * 
   * @return translated "Job successfully started."
   */
  @DefaultMessage("Job successfully started.")
  @Key("jobStartStartedMessage")
  String jobStartStartedMessage();

  /**
   * Translated "Start".
   * 
   * @return translated "Start"
   */
  @DefaultMessage("Start")
  @Key("jobStartTargetButton")
  String jobStartTargetButton();

  /**
   * Translated "Start Job {0} for target {1}".
   * 
   * @return translated "Start Job {0} for target {1}"
   */
  @DefaultMessage("Start Job {0} for target {1}")
  @Key("jobStartTargetDialogHeader")
  String jobStartTargetDialogHeader(String arg0,  String arg1);

  /**
   * Translated "Start the selected job for the selected target?".
   * 
   * @return translated "Start the selected job for the selected target?"
   */
  @DefaultMessage("Start the selected job for the selected target?")
  @Key("jobStartTargetDialogInfo")
  String jobStartTargetDialogInfo();

  /**
   * Translated "Error starting job: {0}".
   * 
   * @return translated "Error starting job: {0}"
   */
  @DefaultMessage("Error starting job: {0}")
  @Key("jobStartTargetErrorMessage")
  String jobStartTargetErrorMessage(String arg0);

  /**
   * Translated "Job successfully started.".
   * 
   * @return translated "Job successfully started."
   */
  @DefaultMessage("Job successfully started.")
  @Key("jobStartTargetStartedMessage")
  String jobStartTargetStartedMessage();

  /**
   * Translated "Job Step Properties".
   * 
   * @return translated "Job Step Properties"
   */
  @DefaultMessage("Job Step Properties")
  @Key("jobStepPropertiesFieldSetHeading")
  String jobStepPropertiesFieldSetHeading();

  /**
   * Translated "Stop".
   * 
   * @return translated "Stop"
   */
  @DefaultMessage("Stop")
  @Key("jobStopButton")
  String jobStopButton();

  /**
   * Translated "Stop Job: {0}".
   * 
   * @return translated "Stop Job: {0}"
   */
  @DefaultMessage("Stop Job: {0}")
  @Key("jobStopDialogHeader")
  String jobStopDialogHeader(String arg0);

  /**
   * Translated "Stop the selected job?".
   * 
   * @return translated "Stop the selected job?"
   */
  @DefaultMessage("Stop the selected job?")
  @Key("jobStopDialogInfo")
  String jobStopDialogInfo();

  /**
   * Translated "Selected job could not be stopped. Either job has not been started or it could not be stopped. Please check console log for errors.".
   * 
   * @return translated "Selected job could not be stopped. Either job has not been started or it could not be stopped. Please check console log for errors."
   */
  @DefaultMessage("Selected job could not be stopped. Either job has not been started or it could not be stopped. Please check console log for errors.")
  @Key("jobStopErrorMessage")
  String jobStopErrorMessage();

  /**
   * Translated "Job successfully stopped.".
   * 
   * @return translated "Job successfully stopped."
   */
  @DefaultMessage("Job successfully stopped.")
  @Key("jobStopStoppedMessage")
  String jobStopStoppedMessage();

  /**
   * Translated "Batch Jobs".
   * 
   * @return translated "Batch Jobs"
   */
  @DefaultMessage("Batch Jobs")
  @Key("mainMenuJobs")
  String mainMenuJobs();

  /**
   * Translated "Selected only".
   * 
   * @return translated "Selected only"
   */
  @DefaultMessage("Selected only")
  @Key("selectedTargets")
  String selectedTargets();

  /**
   * Translated "Remove".
   * 
   * @return translated "Remove"
   */
  @DefaultMessage("Remove")
  @Key("tabTargetsDeleteButton")
  String tabTargetsDeleteButton();
}
