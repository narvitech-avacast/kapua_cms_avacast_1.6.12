package org.eclipse.kapua.app.console.module.job.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtJobEngineServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobEngineService
     */
    void start( java.lang.String gwtScopeId, java.lang.String gwtJobId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobEngineService
     */
    void start( java.lang.String gwtScopeId, java.lang.String gwtJobId, org.eclipse.kapua.app.console.module.job.shared.model.GwtJobStartOptions gwtJobStartOptions, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobEngineService
     */
    void stop( java.lang.String gwtScopeId, java.lang.String gwtJobId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobEngineService
     */
    void stopExecution( java.lang.String gwtScopeId, java.lang.String gwtJobId, java.lang.String gwtJobExecutionId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobEngineService
     */
    void restart( java.lang.String gwtScopeId, java.lang.String gwtJobId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.job.shared.service.GwtJobEngineService
     */
    void restart( java.lang.String gwtScopeId, java.lang.String gwtJobId, java.lang.String gwtJobTargetId, AsyncCallback<Void> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtJobEngineServiceAsync instance;

        public static final GwtJobEngineServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtJobEngineServiceAsync) GWT.create( GwtJobEngineService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "jobEngine" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
