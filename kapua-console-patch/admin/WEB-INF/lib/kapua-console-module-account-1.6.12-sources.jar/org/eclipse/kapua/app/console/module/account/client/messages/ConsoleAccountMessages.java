package org.eclipse.kapua.app.console.module.account.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/account/src/main/resources/org/eclipse/kapua/app/console/module/account/client/messages/ConsoleAccountMessages.properties'.
 */
public interface ConsoleAccountMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "New Child Account".
   * 
   * @return translated "New Child Account"
   */
  @DefaultMessage("New Child Account")
  @Key("accountAddDialogHeader")
  String accountAddDialogHeader();

  /**
   * Translated "Create a new account providing a unique name, organization name and e-mail.".
   * 
   * @return translated "Create a new account providing a unique name, organization name and e-mail."
   */
  @DefaultMessage("Create a new account providing a unique name, organization name and e-mail.")
  @Key("accountAddDialogInfoMessage")
  String accountAddDialogInfoMessage();

  /**
   * Translated "Account successfully created.".
   * 
   * @return translated "Account successfully created."
   */
  @DefaultMessage("Account successfully created.")
  @Key("accountCreatedConfirmation")
  String accountCreatedConfirmation();

  /**
   * Translated "Delete Child Account: {0}".
   * 
   * @return translated "Delete Child Account: {0}"
   */
  @DefaultMessage("Delete Child Account: {0}")
  @Key("accountDeleteDialogHeader")
  String accountDeleteDialogHeader(String arg0);

  /**
   * Translated "This account cannot be deleted. Delete its children first.".
   * 
   * @return translated "This account cannot be deleted. Delete its children first."
   */
  @DefaultMessage("This account cannot be deleted. Delete its children first.")
  @Key("accountDeleteErrorMessage")
  String accountDeleteErrorMessage();

  /**
   * Translated "Are you sure you want to delete the selected Child Account?".
   * 
   * @return translated "Are you sure you want to delete the selected Child Account?"
   */
  @DefaultMessage("Are you sure you want to delete the selected Child Account?")
  @Key("accountDeleteInfoMessage")
  String accountDeleteInfoMessage();

  /**
   * Translated "Child Account successfully deleted.".
   * 
   * @return translated "Child Account successfully deleted."
   */
  @DefaultMessage("Child Account successfully deleted.")
  @Key("accountDeletedConfirmation")
  String accountDeletedConfirmation();

  /**
   * Translated "Edit Account: {0}".
   * 
   * @return translated "Edit Account: {0}"
   */
  @DefaultMessage("Edit Account: {0}")
  @Key("accountEditDialogHeader")
  String accountEditDialogHeader(String arg0);

  /**
   * Translated "Edit account''s general information and organization information.".
   * 
   * @return translated "Edit account''s general information and organization information."
   */
  @DefaultMessage("Edit account''s general information and organization information.")
  @Key("accountEditInfoMessage")
  String accountEditInfoMessage();

  /**
   * Translated "Expiration Date".
   * 
   * @return translated "Expiration Date"
   */
  @DefaultMessage("Expiration Date")
  @Key("accountFilterExpirationDateLabel")
  String accountFilterExpirationDateLabel();

  /**
   * Translated "Account Name".
   * 
   * @return translated "Account Name"
   */
  @DefaultMessage("Account Name")
  @Key("accountFilterNameLabel")
  String accountFilterNameLabel();

  /**
   * Translated "Address 1".
   * 
   * @return translated "Address 1"
   */
  @DefaultMessage("Address 1")
  @Key("accountFilterOrgAddress1")
  String accountFilterOrgAddress1();

  /**
   * Translated "Address 2".
   * 
   * @return translated "Address 2"
   */
  @DefaultMessage("Address 2")
  @Key("accountFilterOrgAddress2")
  String accountFilterOrgAddress2();

  /**
   * Translated "Address 3".
   * 
   * @return translated "Address 3"
   */
  @DefaultMessage("Address 3")
  @Key("accountFilterOrgAddress3")
  String accountFilterOrgAddress3();

  /**
   * Translated "City".
   * 
   * @return translated "City"
   */
  @DefaultMessage("City")
  @Key("accountFilterOrgCity")
  String accountFilterOrgCity();

  /**
   * Translated "Contact Name".
   * 
   * @return translated "Contact Name"
   */
  @DefaultMessage("Contact Name")
  @Key("accountFilterOrgContactName")
  String accountFilterOrgContactName();

  /**
   * Translated "Country".
   * 
   * @return translated "Country"
   */
  @DefaultMessage("Country")
  @Key("accountFilterOrgCountry")
  String accountFilterOrgCountry();

  /**
   * Translated "Organization Email".
   * 
   * @return translated "Organization Email"
   */
  @DefaultMessage("Organization Email")
  @Key("accountFilterOrgEmailLabel")
  String accountFilterOrgEmailLabel();

  /**
   * Translated "Organization Name".
   * 
   * @return translated "Organization Name"
   */
  @DefaultMessage("Organization Name")
  @Key("accountFilterOrgNameLabel")
  String accountFilterOrgNameLabel();

  /**
   * Translated "Phone Number".
   * 
   * @return translated "Phone Number"
   */
  @DefaultMessage("Phone Number")
  @Key("accountFilterOrgPhoneNumber")
  String accountFilterOrgPhoneNumber();

  /**
   * Translated "State/Province".
   * 
   * @return translated "State/Province"
   */
  @DefaultMessage("State/Province")
  @Key("accountFilterOrgStateProvince")
  String accountFilterOrgStateProvince();

  /**
   * Translated "Zip/Post code".
   * 
   * @return translated "Zip/Post code"
   */
  @DefaultMessage("Zip/Post code")
  @Key("accountFilterOrgZipPostCode")
  String accountFilterOrgZipPostCode();

  /**
   * Translated "Administrator Email".
   * 
   * @return translated "Administrator Email"
   */
  @DefaultMessage("Administrator Email")
  @Key("accountFormAdminEmail")
  String accountFormAdminEmail();

  /**
   * Translated "Administrator Information".
   * 
   * @return translated "Administrator Information"
   */
  @DefaultMessage("Administrator Information")
  @Key("accountFormAdminInformation")
  String accountFormAdminInformation();

  /**
   * Translated "Administrator Username".
   * 
   * @return translated "Administrator Username"
   */
  @DefaultMessage("Administrator Username")
  @Key("accountFormAdminUser")
  String accountFormAdminUser();

  /**
   * Translated "Broker".
   * 
   * @return translated "Broker"
   */
  @DefaultMessage("Broker")
  @Key("accountFormBroker")
  String accountFormBroker();

  /**
   * Translated "Broker Cluster".
   * 
   * @return translated "Broker Cluster"
   */
  @DefaultMessage("Broker Cluster")
  @Key("accountFormBrokerCluster")
  String accountFormBrokerCluster();

  /**
   * Translated "Broker Host".
   * 
   * @return translated "Broker Host"
   */
  @DefaultMessage("Broker Host")
  @Key("accountFormBrokerHost")
  String accountFormBrokerHost();

  /**
   * Translated "Broker Image Name".
   * 
   * @return translated "Broker Image Name"
   */
  @DefaultMessage("Broker Image Name")
  @Key("accountFormBrokerImageName")
  String accountFormBrokerImageName();

  /**
   * Translated "Broker Information".
   * 
   * @return translated "Broker Information"
   */
  @DefaultMessage("Broker Information")
  @Key("accountFormBrokerInformation")
  String accountFormBrokerInformation();

  /**
   * Translated "This account cannot have child accounts".
   * 
   * @return translated "This account cannot have child accounts"
   */
  @DefaultMessage("This account cannot have child accounts")
  @Key("accountFormButtonChildCreationDisabled")
  String accountFormButtonChildCreationDisabled();

  /**
   * Translated "Confirm Password".
   * 
   * @return translated "Confirm Password"
   */
  @DefaultMessage("Confirm Password")
  @Key("accountFormConfirmPassword")
  String accountFormConfirmPassword();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultMessage("Created By")
  @Key("accountFormCreatedBy")
  String accountFormCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("accountFormCreatedOn")
  String accountFormCreatedOn();

  /**
   * Translated "Deployment Information".
   * 
   * @return translated "Deployment Information"
   */
  @DefaultMessage("Deployment Information")
  @Key("accountFormDeploymentInformation")
  String accountFormDeploymentInformation();

  /**
   * Translated "Expiration Date".
   * 
   * @return translated "Expiration Date"
   */
  @DefaultMessage("Expiration Date")
  @Key("accountFormExpirationDate")
  String accountFormExpirationDate();

  /**
   * Translated "Set the expiration date for the account. It should be in format DD/MM/YYYY.".
   * 
   * @return translated "Set the expiration date for the account. It should be in format DD/MM/YYYY."
   */
  @DefaultMessage("Set the expiration date for the account. It should be in format DD/MM/YYYY.")
  @Key("accountFormExpirationDateTooltip")
  String accountFormExpirationDateTooltip();

  /**
   * Translated "Account Information".
   * 
   * @return translated "Account Information"
   */
  @DefaultMessage("Account Information")
  @Key("accountFormInformation")
  String accountFormInformation();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultMessage("Modified By")
  @Key("accountFormModifiedBy")
  String accountFormModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultMessage("Modified On")
  @Key("accountFormModifiedOn")
  String accountFormModifiedOn();

  /**
   * Translated "Account Name".
   * 
   * @return translated "Account Name"
   */
  @DefaultMessage("Account Name")
  @Key("accountFormName")
  String accountFormName();

  /**
   * Translated "No Expiration".
   * 
   * @return translated "No Expiration"
   */
  @DefaultMessage("No Expiration")
  @Key("accountFormNoExpiration")
  String accountFormNoExpiration();

  /**
   * Translated "Address 1".
   * 
   * @return translated "Address 1"
   */
  @DefaultMessage("Address 1")
  @Key("accountFormOrgAddress1")
  String accountFormOrgAddress1();

  /**
   * Translated "Enter an address for more complete profile of the account.".
   * 
   * @return translated "Enter an address for more complete profile of the account."
   */
  @DefaultMessage("Enter an address for more complete profile of the account.")
  @Key("accountFormOrgAddress1Tooltip")
  String accountFormOrgAddress1Tooltip();

  /**
   * Translated "Address 2".
   * 
   * @return translated "Address 2"
   */
  @DefaultMessage("Address 2")
  @Key("accountFormOrgAddress2")
  String accountFormOrgAddress2();

  /**
   * Translated "Enter a second address, if necessary, for more complete profile of the account.".
   * 
   * @return translated "Enter a second address, if necessary, for more complete profile of the account."
   */
  @DefaultMessage("Enter a second address, if necessary, for more complete profile of the account.")
  @Key("accountFormOrgAddress2Tooltip")
  String accountFormOrgAddress2Tooltip();

  /**
   * Translated "Address 3".
   * 
   * @return translated "Address 3"
   */
  @DefaultMessage("Address 3")
  @Key("accountFormOrgAddress3")
  String accountFormOrgAddress3();

  /**
   * Translated "Enter a third address, if necessary, for more complete profile of the account.".
   * 
   * @return translated "Enter a third address, if necessary, for more complete profile of the account."
   */
  @DefaultMessage("Enter a third address, if necessary, for more complete profile of the account.")
  @Key("accountFormOrgAddress3Tooltip")
  String accountFormOrgAddress3Tooltip();

  /**
   * Translated "City".
   * 
   * @return translated "City"
   */
  @DefaultMessage("City")
  @Key("accountFormOrgCity")
  String accountFormOrgCity();

  /**
   * Translated "Enter a city for more complete profile of the account.".
   * 
   * @return translated "Enter a city for more complete profile of the account."
   */
  @DefaultMessage("Enter a city for more complete profile of the account.")
  @Key("accountFormOrgCityTooltip")
  String accountFormOrgCityTooltip();

  /**
   * Translated "Contact Name".
   * 
   * @return translated "Contact Name"
   */
  @DefaultMessage("Contact Name")
  @Key("accountFormOrgContactName")
  String accountFormOrgContactName();

  /**
   * Translated "Enter a contact name for more complete profile of the account.".
   * 
   * @return translated "Enter a contact name for more complete profile of the account."
   */
  @DefaultMessage("Enter a contact name for more complete profile of the account.")
  @Key("accountFormOrgContactNameTooltip")
  String accountFormOrgContactNameTooltip();

  /**
   * Translated "Country".
   * 
   * @return translated "Country"
   */
  @DefaultMessage("Country")
  @Key("accountFormOrgCountry")
  String accountFormOrgCountry();

  /**
   * Translated "Enter a country for more complete profile of the account. ".
   * 
   * @return translated "Enter a country for more complete profile of the account. "
   */
  @DefaultMessage("Enter a country for more complete profile of the account. ")
  @Key("accountFormOrgCountryTooltip")
  String accountFormOrgCountryTooltip();

  /**
   * Translated "Email".
   * 
   * @return translated "Email"
   */
  @DefaultMessage("Email")
  @Key("accountFormOrgEmail")
  String accountFormOrgEmail();

  /**
   * Translated "Enter an email for more complete profile of the account. Email should be in format username@domain.com.".
   * 
   * @return translated "Enter an email for more complete profile of the account. Email should be in format username@domain.com."
   */
  @DefaultMessage("Enter an email for more complete profile of the account. Email should be in format username@domain.com.")
  @Key("accountFormOrgEmailTooltip")
  String accountFormOrgEmailTooltip();

  /**
   * Translated "Organization Information".
   * 
   * @return translated "Organization Information"
   */
  @DefaultMessage("Organization Information")
  @Key("accountFormOrgInformation")
  String accountFormOrgInformation();

  /**
   * Translated "Organization Name".
   * 
   * @return translated "Organization Name"
   */
  @DefaultMessage("Organization Name")
  @Key("accountFormOrgName")
  String accountFormOrgName();

  /**
   * Translated "Enter an organization name for more complete profile of the account.".
   * 
   * @return translated "Enter an organization name for more complete profile of the account."
   */
  @DefaultMessage("Enter an organization name for more complete profile of the account.")
  @Key("accountFormOrgNameTooltip")
  String accountFormOrgNameTooltip();

  /**
   * Translated "Phone Number".
   * 
   * @return translated "Phone Number"
   */
  @DefaultMessage("Phone Number")
  @Key("accountFormOrgPhoneNumber")
  String accountFormOrgPhoneNumber();

  /**
   * Translated "Enter a phone number for more complete profile of the account. It can contain only digits and an optional \"+\" sign at the beginning.".
   * 
   * @return translated "Enter a phone number for more complete profile of the account. It can contain only digits and an optional \"+\" sign at the beginning."
   */
  @DefaultMessage("Enter a phone number for more complete profile of the account. It can contain only digits and an optional \"+\" sign at the beginning.")
  @Key("accountFormOrgPhoneNumberTooltip")
  String accountFormOrgPhoneNumberTooltip();

  /**
   * Translated "Primary Contact".
   * 
   * @return translated "Primary Contact"
   */
  @DefaultMessage("Primary Contact")
  @Key("accountFormOrgPrimaryContact")
  String accountFormOrgPrimaryContact();

  /**
   * Translated "State/Province".
   * 
   * @return translated "State/Province"
   */
  @DefaultMessage("State/Province")
  @Key("accountFormOrgState")
  String accountFormOrgState();

  /**
   * Translated "Enter a state/province for more complete profile of the account.".
   * 
   * @return translated "Enter a state/province for more complete profile of the account."
   */
  @DefaultMessage("Enter a state/province for more complete profile of the account.")
  @Key("accountFormOrgStateTooltip")
  String accountFormOrgStateTooltip();

  /**
   * Translated "Zip/Post Code".
   * 
   * @return translated "Zip/Post Code"
   */
  @DefaultMessage("Zip/Post Code")
  @Key("accountFormOrgZipPostCode")
  String accountFormOrgZipPostCode();

  /**
   * Translated "Enter a ZIP/Postal code for more complete profile of the account.".
   * 
   * @return translated "Enter a ZIP/Postal code for more complete profile of the account."
   */
  @DefaultMessage("Enter a ZIP/Postal code for more complete profile of the account.")
  @Key("accountFormOrgZipPostCodeTooltip")
  String accountFormOrgZipPostCodeTooltip();

  /**
   * Translated "Parent Account".
   * 
   * @return translated "Parent Account"
   */
  @DefaultMessage("Parent Account")
  @Key("accountFormParentAccount")
  String accountFormParentAccount();

  /**
   * Translated "Account''s unique name.".
   * 
   * @return translated "Account''s unique name."
   */
  @DefaultMessage("Account''s unique name.")
  @Key("accountFormParentAccountNameEditDialogTooltip")
  String accountFormParentAccountNameEditDialogTooltip();

  /**
   * Translated "Account name must be at least 3 characters long and can contain alphanumeric characters combined with dash.".
   * 
   * @return translated "Account name must be at least 3 characters long and can contain alphanumeric characters combined with dash."
   */
  @DefaultMessage("Account name must be at least 3 characters long and can contain alphanumeric characters combined with dash.")
  @Key("accountFormParentAccountNameTooltip")
  String accountFormParentAccountNameTooltip();

  /**
   * Translated "Account''s parent account.".
   * 
   * @return translated "Account''s parent account."
   */
  @DefaultMessage("Account''s parent account.")
  @Key("accountFormParentAccountTooltip")
  String accountFormParentAccountTooltip();

  /**
   * Translated "Account Password".
   * 
   * @return translated "Account Password"
   */
  @DefaultMessage("Account Password")
  @Key("accountFormPassword")
  String accountFormPassword();

  /**
   * Translated "Rules Assistant Instance".
   * 
   * @return translated "Rules Assistant Instance"
   */
  @DefaultMessage("Rules Assistant Instance")
  @Key("accountFormRuleAssistantInstance")
  String accountFormRuleAssistantInstance();

  /**
   * Translated "Address 1".
   * 
   * @return translated "Address 1"
   */
  @DefaultMessage("Address 1")
  @Key("accountTableAddress1")
  String accountTableAddress1();

  /**
   * Translated "Address 2".
   * 
   * @return translated "Address 2"
   */
  @DefaultMessage("Address 2")
  @Key("accountTableAddress2")
  String accountTableAddress2();

  /**
   * Translated "Address 3".
   * 
   * @return translated "Address 3"
   */
  @DefaultMessage("Address 3")
  @Key("accountTableAddress3")
  String accountTableAddress3();

  /**
   * Translated "City".
   * 
   * @return translated "City"
   */
  @DefaultMessage("City")
  @Key("accountTableCity")
  String accountTableCity();

  /**
   * Translated "Contact Name".
   * 
   * @return translated "Contact Name"
   */
  @DefaultMessage("Contact Name")
  @Key("accountTableContactName")
  String accountTableContactName();

  /**
   * Translated "Country".
   * 
   * @return translated "Country"
   */
  @DefaultMessage("Country")
  @Key("accountTableCountry")
  String accountTableCountry();

  /**
   * Translated "Expiration Date".
   * 
   * @return translated "Expiration Date"
   */
  @DefaultMessage("Expiration Date")
  @Key("accountTableExpirationDate")
  String accountTableExpirationDate();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultMessage("Modified By")
  @Key("accountTableModifiedBy")
  String accountTableModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultMessage("Modified On")
  @Key("accountTableModifiedOn")
  String accountTableModifiedOn();

  /**
   * Translated "Account Name".
   * 
   * @return translated "Account Name"
   */
  @DefaultMessage("Account Name")
  @Key("accountTableName")
  String accountTableName();

  /**
   * Translated "Organization Email".
   * 
   * @return translated "Organization Email"
   */
  @DefaultMessage("Organization Email")
  @Key("accountTableOrgEmail")
  String accountTableOrgEmail();

  /**
   * Translated "Organization Name".
   * 
   * @return translated "Organization Name"
   */
  @DefaultMessage("Organization Name")
  @Key("accountTableOrgName")
  String accountTableOrgName();

  /**
   * Translated "Phone Number".
   * 
   * @return translated "Phone Number"
   */
  @DefaultMessage("Phone Number")
  @Key("accountTablePhoneNumber")
  String accountTablePhoneNumber();

  /**
   * Translated "State/Province".
   * 
   * @return translated "State/Province"
   */
  @DefaultMessage("State/Province")
  @Key("accountTableStateProvince")
  String accountTableStateProvince();

  /**
   * Translated "Zip/Post Code".
   * 
   * @return translated "Zip/Post Code"
   */
  @DefaultMessage("Zip/Post Code")
  @Key("accountTableZipPostCode")
  String accountTableZipPostCode();

  /**
   * Translated "Account successfully updated.".
   * 
   * @return translated "Account successfully updated."
   */
  @DefaultMessage("Account successfully updated.")
  @Key("accountUpdatedConfirmation")
  String accountUpdatedConfirmation();

  /**
   * Translated "Child Accounts".
   * 
   * @return translated "Child Accounts"
   */
  @DefaultMessage("Child Accounts")
  @Key("childAccounts")
  String childAccounts();

  /**
   * Translated "The expiration date conflicts with either its parent expiration date or one of its children expiration date".
   * 
   * @return translated "The expiration date conflicts with either its parent expiration date or one of its children expiration date"
   */
  @DefaultMessage("The expiration date conflicts with either its parent expiration date or one of its children expiration date")
  @Key("conflictingExpirationDate")
  String conflictingExpirationDate();

  /**
   * Translated "Enabled".
   * 
   * @return translated "Enabled"
   */
  @DefaultMessage("Enabled")
  @Key("enabled")
  String enabled();

  /**
   * Translated "Account Filter".
   * 
   * @return translated "Account Filter"
   */
  @DefaultMessage("Account Filter")
  @Key("filterHeader")
  String filterHeader();

  /**
   * Translated "Confirmation".
   * 
   * @return translated "Confirmation"
   */
  @DefaultMessage("Confirmation")
  @Key("info")
  String info();

  /**
   * Translated "The expiration date can not be set for an admin account.".
   * 
   * @return translated "The expiration date can not be set for an admin account."
   */
  @DefaultMessage("The expiration date can not be set for an admin account.")
  @Key("notAllowedExpirationDate")
  String notAllowedExpirationDate();

  /**
   * Translated "Settings".
   * 
   * @return translated "Settings"
   */
  @DefaultMessage("Settings")
  @Key("settings")
  String settings();
}
