package org.eclipse.kapua.app.console.module.authentication.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/authentication/src/main/resources/org/eclipse/kapua/app/console/module/authentication/client/messages/ConsoleCredentialMessages.properties'.
 */
public interface ConsoleCredentialMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "Please confirm the new password.".
   * 
   * @return translated "Please confirm the new password."
   */
  @DefaultMessage("Please confirm the new password.")
  @Key("credentialConfirmPasswordRequired")
  String credentialConfirmPasswordRequired();

  /**
   * Translated "Please select credentials status".
   * 
   * @return translated "Please select credentials status"
   */
  @DefaultMessage("Please select credentials status")
  @Key("credentialStatusPlaceHolder")
  String credentialStatusPlaceHolder();

  /**
   * Translated "Credential type is required.".
   * 
   * @return translated "Credential type is required."
   */
  @DefaultMessage("Credential type is required.")
  @Key("credentialTypeBlankText")
  String credentialTypeBlankText();

  /**
   * Translated "Please Select Credential Type".
   * 
   * @return translated "Please Select Credential Type"
   */
  @DefaultMessage("Please Select Credential Type")
  @Key("credentialTypePlaceHolder")
  String credentialTypePlaceHolder();

  /**
   * Translated "API key successfully created.".
   * 
   * @return translated "API key successfully created."
   */
  @DefaultMessage("API key successfully created.")
  @Key("dialogAddConfirmationAPI")
  String dialogAddConfirmationAPI();

  /**
   * Translated "The API Key has been created. Please write it down and keep it somewhere safe, since this is the last time you will be able to read it.\n\nAPI Key:\n\n{0}".
   * 
   * @return translated "The API Key has been created. Please write it down and keep it somewhere safe, since this is the last time you will be able to read it.\n\nAPI Key:\n\n{0}"
   */
  @DefaultMessage("The API Key has been created. Please write it down and keep it somewhere safe, since this is the last time you will be able to read it.\n\nAPI Key:\n\n{0}")
  @Key("dialogAddConfirmationApiKey")
  String dialogAddConfirmationApiKey(String arg0);

  /**
   * Translated "Password successfully created.".
   * 
   * @return translated "Password successfully created."
   */
  @DefaultMessage("Password successfully created.")
  @Key("dialogAddConfirmationPassword")
  String dialogAddConfirmationPassword();

  /**
   * Translated "Credentials creation failed: {0}".
   * 
   * @return translated "Credentials creation failed: {0}"
   */
  @DefaultMessage("Credentials creation failed: {0}")
  @Key("dialogAddError")
  String dialogAddError(String arg0);

  /**
   * Translated "Error retrieving subjects: {0}".
   * 
   * @return translated "Error retrieving subjects: {0}"
   */
  @DefaultMessage("Error retrieving subjects: {0}")
  @Key("dialogAddErrorSubjects")
  String dialogAddErrorSubjects(String arg0);

  /**
   * Translated "Confirm Password".
   * 
   * @return translated "Confirm Password"
   */
  @DefaultMessage("Confirm Password")
  @Key("dialogAddFieldConfirmPassword")
  String dialogAddFieldConfirmPassword();

  /**
   * Translated "Credential Type".
   * 
   * @return translated "Credential Type"
   */
  @DefaultMessage("Credential Type")
  @Key("dialogAddFieldCredentialType")
  String dialogAddFieldCredentialType();

  /**
   * Translated "Select the type of the credential you wish to add.".
   * 
   * @return translated "Select the type of the credential you wish to add."
   */
  @DefaultMessage("Select the type of the credential you wish to add.")
  @Key("dialogAddFieldCredentialTypeTooltip")
  String dialogAddFieldCredentialTypeTooltip();

  /**
   * Translated "Enabled".
   * 
   * @return translated "Enabled"
   */
  @DefaultMessage("Enabled")
  @Key("dialogAddFieldEnabled")
  String dialogAddFieldEnabled();

  /**
   * Translated "Expiration Date".
   * 
   * @return translated "Expiration Date"
   */
  @DefaultMessage("Expiration Date")
  @Key("dialogAddFieldExpirationDate")
  String dialogAddFieldExpirationDate();

  /**
   * Translated "Set the expiration date for the API_KEY. It should be in format DD/MM/YYY.".
   * 
   * @return translated "Set the expiration date for the API_KEY. It should be in format DD/MM/YYY."
   */
  @DefaultMessage("Set the expiration date for the API_KEY. It should be in format DD/MM/YYY.")
  @Key("dialogAddFieldExpirationDateApiKeyTooltip")
  String dialogAddFieldExpirationDateApiKeyTooltip();

  /**
   * Translated "Set the expiration date for the password. It should be in format DD/MM/YYYY.".
   * 
   * @return translated "Set the expiration date for the password. It should be in format DD/MM/YYYY."
   */
  @DefaultMessage("Set the expiration date for the password. It should be in format DD/MM/YYYY.")
  @Key("dialogAddFieldExpirationDatePasswordTooltip")
  String dialogAddFieldExpirationDatePasswordTooltip();

  /**
   * Translated "Set the expiration date for the credential. It should be in format DD/MM/YYYY.".
   * 
   * @return translated "Set the expiration date for the credential. It should be in format DD/MM/YYYY."
   */
  @DefaultMessage("Set the expiration date for the credential. It should be in format DD/MM/YYYY.")
  @Key("dialogAddFieldExpirationDateTooltip")
  String dialogAddFieldExpirationDateTooltip();

  /**
   * Translated "Password".
   * 
   * @return translated "Password"
   */
  @DefaultMessage("Password")
  @Key("dialogAddFieldPassword")
  String dialogAddFieldPassword();

  /**
   * Translated "Username".
   * 
   * @return translated "Username"
   */
  @DefaultMessage("Username")
  @Key("dialogAddFieldSubject")
  String dialogAddFieldSubject();

  /**
   * Translated "Subject Type".
   * 
   * @return translated "Subject Type"
   */
  @DefaultMessage("Subject Type")
  @Key("dialogAddFieldSubjectType")
  String dialogAddFieldSubjectType();

  /**
   * Translated "New Credentials".
   * 
   * @return translated "New Credentials"
   */
  @DefaultMessage("New Credentials")
  @Key("dialogAddHeader")
  String dialogAddHeader();

  /**
   * Translated "Create a new credential and associate it to the selected user. Passwords are manually inserted, while API Keys will be generated automatically.".
   * 
   * @return translated "Create a new credential and associate it to the selected user. Passwords are manually inserted, while API Keys will be generated automatically."
   */
  @DefaultMessage("Create a new credential and associate it to the selected user. Passwords are manually inserted, while API Keys will be generated automatically.")
  @Key("dialogAddInfo")
  String dialogAddInfo();

  /**
   * Translated "No Expiration".
   * 
   * @return translated "No Expiration"
   */
  @DefaultMessage("No Expiration")
  @Key("dialogAddNoExpiration")
  String dialogAddNoExpiration();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("dialogAddStatus")
  String dialogAddStatus();

  /**
   * Translated "Select if the API_KEY should be enabled or disabled.".
   * 
   * @return translated "Select if the API_KEY should be enabled or disabled."
   */
  @DefaultMessage("Select if the API_KEY should be enabled or disabled.")
  @Key("dialogAddStatusApiKeyTooltip")
  String dialogAddStatusApiKeyTooltip();

  /**
   * Translated "Select if the password should be enabled or disabled.".
   * 
   * @return translated "Select if the password should be enabled or disabled."
   */
  @DefaultMessage("Select if the password should be enabled or disabled.")
  @Key("dialogAddStatusPasswordTooltip")
  String dialogAddStatusPasswordTooltip();

  /**
   * Translated "Select if the credential should be enabled or disabled.".
   * 
   * @return translated "Select if the credential should be enabled or disabled."
   */
  @DefaultMessage("Select if the credential should be enabled or disabled.")
  @Key("dialogAddStatusTooltip")
  String dialogAddStatusTooltip();

  /**
   * Translated "Password must be {0} to 255 characters long and must contain at least one lower case letter, one upper case letter, one digit and one special character. Allowed special characters: # | '' ! \" £ $ % & @ / [ ] ( ) '{' '}' = ? ^ '' > < , ; . : - _ * + € ^ ` ~".
   * 
   * @return translated "Password must be {0} to 255 characters long and must contain at least one lower case letter, one upper case letter, one digit and one special character. Allowed special characters: # | '' ! \" £ $ % & @ / [ ] ( ) '{' '}' = ? ^ '' > < , ; . : - _ * + € ^ ` ~"
   */
  @DefaultMessage("Password must be {0} to 255 characters long and must contain at least one lower case letter, one upper case letter, one digit and one special character. Allowed special characters: # | '' ! \" £ $ % & @ / [ ] ( ) '{' '}' = ? ^ '' > < , ; . : - _ * + € ^ ` ~")
  @Key("dialogAddTooltipCredentialPassword")
  String dialogAddTooltipCredentialPassword(String arg0);

  /**
   * Translated "API Key confirmation".
   * 
   * @return translated "API Key confirmation"
   */
  @DefaultMessage("API Key confirmation")
  @Key("dialogConfirmationAPI")
  String dialogConfirmationAPI();

  /**
   * Translated "API key successfully deleted.".
   * 
   * @return translated "API key successfully deleted."
   */
  @DefaultMessage("API key successfully deleted.")
  @Key("dialogDeleteConfirmationAPI")
  String dialogDeleteConfirmationAPI();

  /**
   * Translated "Password successfully deleted.".
   * 
   * @return translated "Password successfully deleted."
   */
  @DefaultMessage("Password successfully deleted.")
  @Key("dialogDeleteConfirmationPassword")
  String dialogDeleteConfirmationPassword();

  /**
   * Translated "API Key delete failed: {0}".
   * 
   * @return translated "API Key delete failed: {0}"
   */
  @DefaultMessage("API Key delete failed: {0}")
  @Key("dialogDeleteErrorAPI")
  String dialogDeleteErrorAPI(String arg0);

  /**
   * Translated "Password delete failed: {0}".
   * 
   * @return translated "Password delete failed: {0}"
   */
  @DefaultMessage("Password delete failed: {0}")
  @Key("dialogDeleteErrorPassword")
  String dialogDeleteErrorPassword(String arg0);

  /**
   * Translated "Delete API Key".
   * 
   * @return translated "Delete API Key"
   */
  @DefaultMessage("Delete API Key")
  @Key("dialogDeleteHeaderAPI")
  String dialogDeleteHeaderAPI();

  /**
   * Translated "Delete Password".
   * 
   * @return translated "Delete Password"
   */
  @DefaultMessage("Delete Password")
  @Key("dialogDeleteHeaderPassword")
  String dialogDeleteHeaderPassword();

  /**
   * Translated "Are you sure you want to delete the selected API Key?".
   * 
   * @return translated "Are you sure you want to delete the selected API Key?"
   */
  @DefaultMessage("Are you sure you want to delete the selected API Key?")
  @Key("dialogDeleteInfoAPI")
  String dialogDeleteInfoAPI();

  /**
   * Translated "Are you sure you want to delete the selected password?".
   * 
   * @return translated "Are you sure you want to delete the selected password?"
   */
  @DefaultMessage("Are you sure you want to delete the selected password?")
  @Key("dialogDeleteInfoPassword")
  String dialogDeleteInfoPassword();

  /**
   * Translated "Edit API Key: {0}".
   * 
   * @return translated "Edit API Key: {0}"
   */
  @DefaultMessage("Edit API Key: {0}")
  @Key("dialogEditApiKeyHeader")
  String dialogEditApiKeyHeader(String arg0);

  /**
   * Translated "Modify the API key for the selected user.".
   * 
   * @return translated "Modify the API key for the selected user."
   */
  @DefaultMessage("Modify the API key for the selected user.")
  @Key("dialogEditApiKeyInfo")
  String dialogEditApiKeyInfo();

  /**
   * Translated "API key successfully updated.".
   * 
   * @return translated "API key successfully updated."
   */
  @DefaultMessage("API key successfully updated.")
  @Key("dialogEditConfirmationAPI")
  String dialogEditConfirmationAPI();

  /**
   * Translated "Password successfully updated.".
   * 
   * @return translated "Password successfully updated."
   */
  @DefaultMessage("Password successfully updated.")
  @Key("dialogEditConfirmationPassword")
  String dialogEditConfirmationPassword();

  /**
   * Translated "Credentials edit failed: {0}".
   * 
   * @return translated "Credentials edit failed: {0}"
   */
  @DefaultMessage("Credentials edit failed: {0}")
  @Key("dialogEditError")
  String dialogEditError(String arg0);

  /**
   * Translated "Confirm New Password".
   * 
   * @return translated "Confirm New Password"
   */
  @DefaultMessage("Confirm New Password")
  @Key("dialogEditFieldConfirmNewPassword")
  String dialogEditFieldConfirmNewPassword();

  /**
   * Translated "New Password".
   * 
   * @return translated "New Password"
   */
  @DefaultMessage("New Password")
  @Key("dialogEditFieldNewPassword")
  String dialogEditFieldNewPassword();

  /**
   * Translated "Edit Credential: {0}".
   * 
   * @return translated "Edit Credential: {0}"
   */
  @DefaultMessage("Edit Credential: {0}")
  @Key("dialogEditHeader")
  String dialogEditHeader(String arg0);

  /**
   * Translated "Modify the credential for the selected user.".
   * 
   * @return translated "Modify the credential for the selected user."
   */
  @DefaultMessage("Modify the credential for the selected user.")
  @Key("dialogEditInfo")
  String dialogEditInfo();

  /**
   * Translated "Cannot load credentials: {0}".
   * 
   * @return translated "Cannot load credentials: {0}"
   */
  @DefaultMessage("Cannot load credentials: {0}")
  @Key("dialogEditLoadFailed")
  String dialogEditLoadFailed(String arg0);

  /**
   * Translated "These credentials are locked until {0}".
   * 
   * @return translated "These credentials are locked until {0}"
   */
  @DefaultMessage("These credentials are locked until {0}")
  @Key("dialogEditLockedUntil")
  String dialogEditLockedUntil(String arg0);

  /**
   * Translated "Edit Password: {0}".
   * 
   * @return translated "Edit Password: {0}"
   */
  @DefaultMessage("Edit Password: {0}")
  @Key("dialogEditPasswordHeader")
  String dialogEditPasswordHeader(String arg0);

  /**
   * Translated "Modify the password for the selected user.".
   * 
   * @return translated "Modify the password for the selected user."
   */
  @DefaultMessage("Modify the password for the selected user.")
  @Key("dialogEditPasswordInfo")
  String dialogEditPasswordInfo();

  /**
   * Translated "Reset password: {0}".
   * 
   * @return translated "Reset password: {0}"
   */
  @DefaultMessage("Reset password: {0}")
  @Key("dialogPasswordResetHeader")
  String dialogPasswordResetHeader(String arg0);

  /**
   * Translated "Reset the password for the selected user.".
   * 
   * @return translated "Reset the password for the selected user."
   */
  @DefaultMessage("Reset the password for the selected user.")
  @Key("dialogResetPassword")
  String dialogResetPassword();

  /**
   * Translated "Reset Password: {0}".
   * 
   * @return translated "Reset Password: {0}"
   */
  @DefaultMessage("Reset Password: {0}")
  @Key("dialogResetPasswordHeader")
  String dialogResetPasswordHeader(String arg0);

  /**
   * Translated "Credentials successfully unlocked.".
   * 
   * @return translated "Credentials successfully unlocked."
   */
  @DefaultMessage("Credentials successfully unlocked.")
  @Key("dialogUnlockConfirmation")
  String dialogUnlockConfirmation();

  /**
   * Translated "Credentials unlock failed: {0}".
   * 
   * @return translated "Credentials unlock failed: {0}"
   */
  @DefaultMessage("Credentials unlock failed: {0}")
  @Key("dialogUnlockError")
  String dialogUnlockError(String arg0);

  /**
   * Translated "Unlock Credential: {0}".
   * 
   * @return translated "Unlock Credential: {0}"
   */
  @DefaultMessage("Unlock Credential: {0}")
  @Key("dialogUnlockHeader")
  String dialogUnlockHeader(String arg0);

  /**
   * Translated "Are you sure you want to unlock selected credential?".
   * 
   * @return translated "Are you sure you want to unlock selected credential?"
   */
  @DefaultMessage("Are you sure you want to unlock selected credential?")
  @Key("dialogUnlockInfo")
  String dialogUnlockInfo();

  /**
   * Translated "Are you sure you want to disable Multi Factor Authentication for user {0}?\n\nDisabling MFA, all the codes generated by the current QR Code and Scratch Codes will be discarded and not recognized by the system anymore.\n\n This action cannot be reverted.".
   * 
   * @return translated "Are you sure you want to disable Multi Factor Authentication for user {0}?\n\nDisabling MFA, all the codes generated by the current QR Code and Scratch Codes will be discarded and not recognized by the system anymore.\n\n This action cannot be reverted."
   */
  @DefaultMessage("Are you sure you want to disable Multi Factor Authentication for user {0}?\n\nDisabling MFA, all the codes generated by the current QR Code and Scratch Codes will be discarded and not recognized by the system anymore.\n\n This action cannot be reverted.")
  @Key("disableMfaConfirmation")
  String disableMfaConfirmation(String arg0);

  /**
   * Translated "Disable MFA for user {0}?".
   * 
   * @return translated "Disable MFA for user {0}?"
   */
  @DefaultMessage("Disable MFA for user {0}?")
  @Key("disableMfaConfirmationHeader")
  String disableMfaConfirmationHeader(String arg0);

  /**
   * Translated "Credentials Name".
   * 
   * @return translated "Credentials Name"
   */
  @DefaultMessage("Credentials Name")
  @Key("filterFieldCredentialNameLabel")
  String filterFieldCredentialNameLabel();

  /**
   * Translated "Credentials Type".
   * 
   * @return translated "Credentials Type"
   */
  @DefaultMessage("Credentials Type")
  @Key("filterFieldCredentialTypeLabel")
  String filterFieldCredentialTypeLabel();

  /**
   * Translated "Credentials Filter".
   * 
   * @return translated "Credentials Filter"
   */
  @DefaultMessage("Credentials Filter")
  @Key("filterHeader")
  String filterHeader();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultMessage("Created By")
  @Key("gridCredentialColumnHeaderCreatedBy")
  String gridCredentialColumnHeaderCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("gridCredentialColumnHeaderCreatedOn")
  String gridCredentialColumnHeaderCreatedOn();

  /**
   * Translated "Credential Type".
   * 
   * @return translated "Credential Type"
   */
  @DefaultMessage("Credential Type")
  @Key("gridCredentialColumnHeaderCredentialType")
  String gridCredentialColumnHeaderCredentialType();

  /**
   * Translated "Expiration Date".
   * 
   * @return translated "Expiration Date"
   */
  @DefaultMessage("Expiration Date")
  @Key("gridCredentialColumnHeaderExpirationDate")
  String gridCredentialColumnHeaderExpirationDate();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridCredentialColumnHeaderId")
  String gridCredentialColumnHeaderId();

  /**
   * Translated "Lock Status".
   * 
   * @return translated "Lock Status"
   */
  @DefaultMessage("Lock Status")
  @Key("gridCredentialColumnHeaderLockStatus")
  String gridCredentialColumnHeaderLockStatus();

  /**
   * Translated "MFA".
   * 
   * @return translated "MFA"
   */
  @DefaultMessage("MFA")
  @Key("gridCredentialColumnHeaderMfa")
  String gridCredentialColumnHeaderMfa();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultMessage("Modified By")
  @Key("gridCredentialColumnHeaderModifiedBy")
  String gridCredentialColumnHeaderModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultMessage("Modified On")
  @Key("gridCredentialColumnHeaderModifiedOn")
  String gridCredentialColumnHeaderModifiedOn();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("gridCredentialColumnHeaderStatus")
  String gridCredentialColumnHeaderStatus();

  /**
   * Translated "Username".
   * 
   * @return translated "Username"
   */
  @DefaultMessage("Username")
  @Key("gridCredentialColumnHeaderUsername")
  String gridCredentialColumnHeaderUsername();

  /**
   * Translated "Locked until {0}".
   * 
   * @return translated "Locked until {0}"
   */
  @DefaultMessage("Locked until {0}")
  @Key("gridCredentialLockedUntil")
  String gridCredentialLockedUntil(String arg0);

  /**
   * Translated "MFA Disabled".
   * 
   * @return translated "MFA Disabled"
   */
  @DefaultMessage("MFA Disabled")
  @Key("gridCredentialMfaDisabled")
  String gridCredentialMfaDisabled();

  /**
   * Translated "MFA Enabled".
   * 
   * @return translated "MFA Enabled"
   */
  @DefaultMessage("MFA Enabled")
  @Key("gridCredentialMfaEnabled")
  String gridCredentialMfaEnabled();

  /**
   * Translated "Unlocked".
   * 
   * @return translated "Unlocked"
   */
  @DefaultMessage("Unlocked")
  @Key("gridCredentialUnlocked")
  String gridCredentialUnlocked();

  /**
   * Translated "Credentials".
   * 
   * @return translated "Credentials"
   */
  @DefaultMessage("Credentials")
  @Key("gridTabCredentialsLabel")
  String gridTabCredentialsLabel();

  /**
   * Translated "Multi Factor Authentication".
   * 
   * @return translated "Multi Factor Authentication"
   */
  @DefaultMessage("Multi Factor Authentication")
  @Key("gridTabMfaLabel")
  String gridTabMfaLabel();

  /**
   * Translated "Manage Multi Factor Authentication".
   * 
   * @return translated "Manage Multi Factor Authentication"
   */
  @DefaultMessage("Manage Multi Factor Authentication")
  @Key("manageMfaMenuItem")
  String manageMfaMenuItem();

  /**
   * Translated "Disabling Multi Factor Authentication...".
   * 
   * @return translated "Disabling Multi Factor Authentication..."
   */
  @DefaultMessage("Disabling Multi Factor Authentication...")
  @Key("maskDisableMfa")
  String maskDisableMfa();

  /**
   * Translated "Disabling Trust...".
   * 
   * @return translated "Disabling Trust..."
   */
  @DefaultMessage("Disabling Trust...")
  @Key("maskDisableTrust")
  String maskDisableTrust();

  /**
   * Translated "Enabling Multi Factor Authentication...".
   * 
   * @return translated "Enabling Multi Factor Authentication..."
   */
  @DefaultMessage("Enabling Multi Factor Authentication...")
  @Key("maskEnableMfa")
  String maskEnableMfa();

  /**
   * Translated "Retrieving Multi Factor Authentication data...".
   * 
   * @return translated "Retrieving Multi Factor Authentication data..."
   */
  @DefaultMessage("Retrieving Multi Factor Authentication data...")
  @Key("maskMfaManagementPanel")
  String maskMfaManagementPanel();

  /**
   * Translated "Disable MFA".
   * 
   * @return translated "Disable MFA"
   */
  @DefaultMessage("Disable MFA")
  @Key("mfaButtonDisable")
  String mfaButtonDisable();

  /**
   * Translated "Enable MFA".
   * 
   * @return translated "Enable MFA"
   */
  @DefaultMessage("Enable MFA")
  @Key("mfaButtonEnable")
  String mfaButtonEnable();

  /**
   * Translated "Forget Trusted Devices".
   * 
   * @return translated "Forget Trusted Devices"
   */
  @DefaultMessage("Forget Trusted Devices")
  @Key("mfaButtonTrustReset")
  String mfaButtonTrustReset();

  /**
   * Translated "Multi Factor Authentication".
   * 
   * @return translated "Multi Factor Authentication"
   */
  @DefaultMessage("Multi Factor Authentication")
  @Key("mfaDialogHeader")
  String mfaDialogHeader();

  /**
   * Translated "Multi Factor Authentication is currently DISABLED for user {0}".
   * 
   * @return translated "Multi Factor Authentication is currently DISABLED for user {0}"
   */
  @DefaultMessage("Multi Factor Authentication is currently DISABLED for user {0}")
  @Key("mfaDisabled")
  String mfaDisabled(String arg0);

  /**
   * Translated "Multi Factor Authentication is currently ENABLED for user {0}".
   * 
   * @return translated "Multi Factor Authentication is currently ENABLED for user {0}"
   */
  @DefaultMessage("Multi Factor Authentication is currently ENABLED for user {0}")
  @Key("mfaEnabled")
  String mfaEnabled(String arg0);

  /**
   * Translated "Forget Trusted Devices".
   * 
   * @return translated "Forget Trusted Devices"
   */
  @DefaultMessage("Forget Trusted Devices")
  @Key("mfaForgetTrustDevice")
  String mfaForgetTrustDevice();

  /**
   * Translated "Are you sure that you want to revoke and forget your Trusted Devices?".
   * 
   * @return translated "Are you sure that you want to revoke and forget your Trusted Devices?"
   */
  @DefaultMessage("Are you sure that you want to revoke and forget your Trusted Devices?")
  @Key("mfaForgetTrustDeviceText")
  String mfaForgetTrustDeviceText();

  /**
   * Translated "Multi factor authentication (MFA) is a process involving multiple stages to verify the identity of the user trying to access the Web Console.".
   * 
   * @return translated "Multi factor authentication (MFA) is a process involving multiple stages to verify the identity of the user trying to access the Web Console."
   */
  @DefaultMessage("Multi factor authentication (MFA) is a process involving multiple stages to verify the identity of the user trying to access the Web Console.")
  @Key("mfaFormBarcodeLabel")
  String mfaFormBarcodeLabel();

  /**
   * Translated "MFA can be enabled for a given user only by the user himself; no one can enable MFA for another user even with the credential:delete permission for the given account. However, an user with credential:delete permission can disable MFA for other users.".
   * 
   * @return translated "MFA can be enabled for a given user only by the user himself; no one can enable MFA for another user even with the credential:delete permission for the given account. However, an user with credential:delete permission can disable MFA for other users."
   */
  @DefaultMessage("MFA can be enabled for a given user only by the user himself; no one can enable MFA for another user even with the credential:delete permission for the given account. However, an user with credential:delete permission can disable MFA for other users.")
  @Key("mfaFormBarcodeLabel2")
  String mfaFormBarcodeLabel2();

  /**
   * Translated "To enable this extra security, follow these steps:".
   * 
   * @return translated "To enable this extra security, follow these steps:"
   */
  @DefaultMessage("To enable this extra security, follow these steps:")
  @Key("mfaFormBarcodeLabel3")
  String mfaFormBarcodeLabel3();

  /**
   * Translated "1. Download and install the Google Authenticator app for your smartphone".
   * 
   * @return translated "1. Download and install the Google Authenticator app for your smartphone"
   */
  @DefaultMessage("1. Download and install the Google Authenticator app for your smartphone")
  @Key("mfaFormBarcodeLabel4")
  String mfaFormBarcodeLabel4();

  /**
   * Translated "2. Click the enable button in the toolbar. You can only enable MFA for the current logged user, while a user with the credential:delete permission can disable MFA on any user covered by the permission.".
   * 
   * @return translated "2. Click the enable button in the toolbar. You can only enable MFA for the current logged user, while a user with the credential:delete permission can disable MFA on any user covered by the permission."
   */
  @DefaultMessage("2. Click the enable button in the toolbar. You can only enable MFA for the current logged user, while a user with the credential:delete permission can disable MFA on any user covered by the permission.")
  @Key("mfaFormBarcodeLabel5")
  String mfaFormBarcodeLabel5();

  /**
   * Translated "3. When the QRCode is shown, open the Google Authenticator and add a new account by scanning the QRCode. Both the QRCode and the Scratch Codes will be shown only once, so make sure to have the generator application running and save the Scratch Codes somewhere before closing the dialog.".
   * 
   * @return translated "3. When the QRCode is shown, open the Google Authenticator and add a new account by scanning the QRCode. Both the QRCode and the Scratch Codes will be shown only once, so make sure to have the generator application running and save the Scratch Codes somewhere before closing the dialog."
   */
  @DefaultMessage("3. When the QRCode is shown, open the Google Authenticator and add a new account by scanning the QRCode. Both the QRCode and the Scratch Codes will be shown only once, so make sure to have the generator application running and save the Scratch Codes somewhere before closing the dialog.")
  @Key("mfaFormBarcodeLabel6")
  String mfaFormBarcodeLabel6();

  /**
   * Translated "On following Kapua Console logins, enter the user’s credentials and the authentication code proposed by Google Authenticator. Scratch codes are one time codes that allows you to complete the login if you cannot produce an authentication code. A scratch code can only be used once; store pass codes safely.".
   * 
   * @return translated "On following Kapua Console logins, enter the user’s credentials and the authentication code proposed by Google Authenticator. Scratch codes are one time codes that allows you to complete the login if you cannot produce an authentication code. A scratch code can only be used once; store pass codes safely."
   */
  @DefaultMessage("On following Kapua Console logins, enter the user’s credentials and the authentication code proposed by Google Authenticator. Scratch codes are one time codes that allows you to complete the login if you cannot produce an authentication code. A scratch code can only be used once; store pass codes safely.")
  @Key("mfaFormBarcodeLabel7")
  String mfaFormBarcodeLabel7();

  /**
   * Translated "Enable MFA".
   * 
   * @return translated "Enable MFA"
   */
  @DefaultMessage("Enable MFA")
  @Key("mfaFormEnableMfa")
  String mfaFormEnableMfa();

  /**
   * Translated "Generate scratch".
   * 
   * @return translated "Generate scratch"
   */
  @DefaultMessage("Generate scratch")
  @Key("mfaFormGenerateScratch")
  String mfaFormGenerateScratch();

  /**
   * Translated "Help".
   * 
   * @return translated "Help"
   */
  @DefaultMessage("Help")
  @Key("mfaFormHelp")
  String mfaFormHelp();

  /**
   * Translated "Revoke Trusted Devices".
   * 
   * @return translated "Revoke Trusted Devices"
   */
  @DefaultMessage("Revoke Trusted Devices")
  @Key("mfaFormRevokeTrustedMachine")
  String mfaFormRevokeTrustedMachine();

  /**
   * Translated "Help".
   * 
   * @return translated "Help"
   */
  @DefaultMessage("Help")
  @Key("mfaHeaderHelp")
  String mfaHeaderHelp();

  /**
   * Translated "Multi Factor Authentication Login".
   * 
   * @return translated "Multi Factor Authentication Login"
   */
  @DefaultMessage("Multi Factor Authentication Login")
  @Key("mfaLoginTitle")
  String mfaLoginTitle();

  /**
   * Translated "To enable the Multi Factor Authentication (MFA) process create the user and than reopen this tab to enable the authentication process.".
   * 
   * @return translated "To enable the Multi Factor Authentication (MFA) process create the user and than reopen this tab to enable the authentication process."
   */
  @DefaultMessage("To enable the Multi Factor Authentication (MFA) process create the user and than reopen this tab to enable the authentication process.")
  @Key("noMfaLabel")
  String noMfaLabel();

  /**
   * Translated "Reset".
   * 
   * @return translated "Reset"
   */
  @DefaultMessage("Reset")
  @Key("resetPasswordButton")
  String resetPasswordButton();

  /**
   * Translated "Unlock".
   * 
   * @return translated "Unlock"
   */
  @DefaultMessage("Unlock")
  @Key("unlockButton")
  String unlockButton();
}
