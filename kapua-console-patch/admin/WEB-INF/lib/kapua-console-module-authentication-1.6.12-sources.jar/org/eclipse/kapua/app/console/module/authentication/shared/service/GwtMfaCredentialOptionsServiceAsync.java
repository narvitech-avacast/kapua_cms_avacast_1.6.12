package org.eclipse.kapua.app.console.module.authentication.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtMfaCredentialOptionsServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtMfaCredentialOptionsService
     */
    void delete( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, java.lang.String stringScopeId, java.lang.String gwtMfaCredentialOptionsId, boolean selfManagement, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtMfaCredentialOptionsService
     */
    void find( java.lang.String scopeIdStr, java.lang.String mfaCredentialOptionsIdStr, boolean selfManagement, AsyncCallback<org.eclipse.kapua.app.console.module.authentication.shared.model.GwtMfaCredentialOptions> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtMfaCredentialOptionsService
     */
    void findByUserId( java.lang.String scopeIdStr, java.lang.String userIdStr, boolean selfManagement, AsyncCallback<org.eclipse.kapua.app.console.module.authentication.shared.model.GwtMfaCredentialOptions> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtMfaCredentialOptionsService
     */
    void create( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, org.eclipse.kapua.app.console.module.authentication.shared.model.GwtMfaCredentialOptionsCreator gwtRoleCreator, boolean selfManagement, AsyncCallback<org.eclipse.kapua.app.console.module.authentication.shared.model.GwtMfaCredentialOptions> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtMfaCredentialOptionsService
     */
    void disableTrust( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, java.lang.String scopeIdStr, java.lang.String mfaCredentialOptionsIdStr, boolean selfManagement, AsyncCallback<Void> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtMfaCredentialOptionsServiceAsync instance;

        public static final GwtMfaCredentialOptionsServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtMfaCredentialOptionsServiceAsync) GWT.create( GwtMfaCredentialOptionsService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "mfaOptions" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
