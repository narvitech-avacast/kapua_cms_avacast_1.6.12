package org.eclipse.kapua.app.console.module.authentication.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtCredentialServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtCredentialService
     */
    void query( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.authentication.shared.model.GwtCredentialQuery gwtCredentialQuery, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.authentication.shared.model.GwtCredential>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtCredentialService
     */
    void delete( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, java.lang.String stringScopeId, java.lang.String gwtCredentialId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtCredentialService
     */
    void create( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, org.eclipse.kapua.app.console.module.authentication.shared.model.GwtCredentialCreator gwtRoleCreator, AsyncCallback<org.eclipse.kapua.app.console.module.authentication.shared.model.GwtCredential> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtCredentialService
     */
    void update( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, org.eclipse.kapua.app.console.module.authentication.shared.model.GwtCredential gwtCredential, AsyncCallback<org.eclipse.kapua.app.console.module.authentication.shared.model.GwtCredential> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtCredentialService
     */
    void changePassword( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, java.lang.String oldPassword, java.lang.String newPassword, java.lang.String mfaCode, java.lang.String stringUserId, java.lang.String stringScopeId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtCredentialService
     */
    void resetPassword( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, java.lang.String stringScopeId, java.lang.String gwtCredentialId, java.lang.String newPassword, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtCredentialService
     */
    void unlock( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, java.lang.String stringScopeId, java.lang.String gwtCredentialId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authentication.shared.service.GwtCredentialService
     */
    void getMinPasswordLength( java.lang.String scopeId, AsyncCallback<java.lang.Integer> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtCredentialServiceAsync instance;

        public static final GwtCredentialServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtCredentialServiceAsync) GWT.create( GwtCredentialService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "credential" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
