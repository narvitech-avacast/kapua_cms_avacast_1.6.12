package org.eclipse.kapua.app.console.module.authorization.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/authorization/src/main/resources/org/eclipse/kapua/app/console/module/authorization/client/messages/ConsoleGroupMessages.properties'.
 */
public interface ConsoleGroupMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "Access Group successfully created.".
   * 
   * @return translated "Access Group successfully created."
   */
  @DefaultMessage("Access Group successfully created.")
  @Key("dialogAddConfirmation")
  String dialogAddConfirmation();

  /**
   * Translated "Access Group creation failed: {0}".
   * 
   * @return translated "Access Group creation failed: {0}"
   */
  @DefaultMessage("Access Group creation failed: {0}")
  @Key("dialogAddError")
  String dialogAddError(String arg0);

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("dialogAddFieldDescription")
  String dialogAddFieldDescription();

  /**
   * Translated "Enter a group description for detailed information about the group.".
   * 
   * @return translated "Enter a group description for detailed information about the group."
   */
  @DefaultMessage("Enter a group description for detailed information about the group.")
  @Key("dialogAddFieldDescriptionTooltip")
  String dialogAddFieldDescriptionTooltip();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("dialogAddFieldName")
  String dialogAddFieldName();

  /**
   * Translated "Access group name must be at least 3 characters long and can contain alphanumeric characters combined with dash and/or underscore.".
   * 
   * @return translated "Access group name must be at least 3 characters long and can contain alphanumeric characters combined with dash and/or underscore."
   */
  @DefaultMessage("Access group name must be at least 3 characters long and can contain alphanumeric characters combined with dash and/or underscore.")
  @Key("dialogAddFieldNameTooltip")
  String dialogAddFieldNameTooltip();

  /**
   * Translated "New Access Group".
   * 
   * @return translated "New Access Group"
   */
  @DefaultMessage("New Access Group")
  @Key("dialogAddHeader")
  String dialogAddHeader();

  /**
   * Translated "Create a new access group providing a name and an optional description.".
   * 
   * @return translated "Create a new access group providing a name and an optional description."
   */
  @DefaultMessage("Create a new access group providing a name and an optional description.")
  @Key("dialogAddInfo")
  String dialogAddInfo();

  /**
   * Translated "Access Group successfully deleted.".
   * 
   * @return translated "Access Group successfully deleted."
   */
  @DefaultMessage("Access Group successfully deleted.")
  @Key("dialogDeleteConfirmation")
  String dialogDeleteConfirmation();

  /**
   * Translated "Access Group delete failed: {0}".
   * 
   * @return translated "Access Group delete failed: {0}"
   */
  @DefaultMessage("Access Group delete failed: {0}")
  @Key("dialogDeleteError")
  String dialogDeleteError(String arg0);

  /**
   * Translated "Delete Access Group: {0}".
   * 
   * @return translated "Delete Access Group: {0}"
   */
  @DefaultMessage("Delete Access Group: {0}")
  @Key("dialogDeleteHeader")
  String dialogDeleteHeader(String arg0);

  /**
   * Translated "Are you sure you want to delete the selected access group?".
   * 
   * @return translated "Are you sure you want to delete the selected access group?"
   */
  @DefaultMessage("Are you sure you want to delete the selected access group?")
  @Key("dialogDeleteInfo")
  String dialogDeleteInfo();

  /**
   * Translated "Access Group successfully updated.".
   * 
   * @return translated "Access Group successfully updated."
   */
  @DefaultMessage("Access Group successfully updated.")
  @Key("dialogEditConfirmation")
  String dialogEditConfirmation();

  /**
   * Translated "Access Group edit failed: {0}".
   * 
   * @return translated "Access Group edit failed: {0}"
   */
  @DefaultMessage("Access Group edit failed: {0}")
  @Key("dialogEditError")
  String dialogEditError(String arg0);

  /**
   * Translated "Edit Access Group: {0}".
   * 
   * @return translated "Edit Access Group: {0}"
   */
  @DefaultMessage("Edit Access Group: {0}")
  @Key("dialogEditHeader")
  String dialogEditHeader(String arg0);

  /**
   * Translated "Edit access group''s data.".
   * 
   * @return translated "Edit access group''s data."
   */
  @DefaultMessage("Edit access group''s data.")
  @Key("dialogEditInfo")
  String dialogEditInfo();

  /**
   * Translated "Cannot load group: {0}".
   * 
   * @return translated "Cannot load group: {0}"
   */
  @DefaultMessage("Cannot load group: {0}")
  @Key("dialogEditLoadFailed")
  String dialogEditLoadFailed(String arg0);

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("filterFieldGroupDescriptionLabel")
  String filterFieldGroupDescriptionLabel();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("filterFieldGroupNameLabel")
  String filterFieldGroupNameLabel();

  /**
   * Translated "Access Group Filter".
   * 
   * @return translated "Access Group Filter"
   */
  @DefaultMessage("Access Group Filter")
  @Key("filterHeader")
  String filterHeader();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultMessage("Created By")
  @Key("gridGroupColumnHeaderCreatedBy")
  String gridGroupColumnHeaderCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("gridGroupColumnHeaderCreatedOn")
  String gridGroupColumnHeaderCreatedOn();

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("gridGroupColumnHeaderDescription")
  String gridGroupColumnHeaderDescription();

  /**
   * Translated "Access Group Name".
   * 
   * @return translated "Access Group Name"
   */
  @DefaultMessage("Access Group Name")
  @Key("gridGroupColumnHeaderGroupName")
  String gridGroupColumnHeaderGroupName();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridGroupColumnHeaderId")
  String gridGroupColumnHeaderId();

  /**
   * Translated "Client ID".
   * 
   * @return translated "Client ID"
   */
  @DefaultMessage("Client ID")
  @Key("gridGroupSubjectColumnHeaderClientId")
  String gridGroupSubjectColumnHeaderClientId();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultMessage("Display Name")
  @Key("gridGroupSubjectColumnHeaderDisplayName")
  String gridGroupSubjectColumnHeaderDisplayName();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridGroupSubjectColumnHeaderId")
  String gridGroupSubjectColumnHeaderId();

  /**
   * Translated "Assigned Devices".
   * 
   * @return translated "Assigned Devices"
   */
  @DefaultMessage("Assigned Devices")
  @Key("groupTabSubjectGridTitle")
  String groupTabSubjectGridTitle();

  /**
   * Translated "Access Groups".
   * 
   * @return translated "Access Groups"
   */
  @DefaultMessage("Access Groups")
  @Key("groups")
  String groups();
}
