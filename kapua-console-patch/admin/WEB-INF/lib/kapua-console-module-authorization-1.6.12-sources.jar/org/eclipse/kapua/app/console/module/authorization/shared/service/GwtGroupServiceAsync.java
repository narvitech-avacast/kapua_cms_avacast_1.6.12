package org.eclipse.kapua.app.console.module.authorization.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtGroupServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtGroupService
     */
    void create( org.eclipse.kapua.app.console.module.authorization.shared.model.GwtGroupCreator gwtGroupCreator, AsyncCallback<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtGroup> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtGroupService
     */
    void update( org.eclipse.kapua.app.console.module.authorization.shared.model.GwtGroup gwtGroup, AsyncCallback<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtGroup> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtGroupService
     */
    void find( java.lang.String scopeShortId, java.lang.String roleShortId, AsyncCallback<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtGroup> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtGroupService
     */
    void query( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.authorization.shared.model.GwtGroupQuery gwtGroupQuery, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtGroup>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtGroupService
     */
    void delete( java.lang.String scopeId, java.lang.String groupId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtGroupService
     */
    void getGroupDescription( java.lang.String scopeShortId, java.lang.String groupShortId, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.api.shared.model.GwtGroupedNVPair>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtGroupService
     */
    void findAll( java.lang.String scopeId, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtGroup>> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtGroupServiceAsync instance;

        public static final GwtGroupServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtGroupServiceAsync) GWT.create( GwtGroupService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "group" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
