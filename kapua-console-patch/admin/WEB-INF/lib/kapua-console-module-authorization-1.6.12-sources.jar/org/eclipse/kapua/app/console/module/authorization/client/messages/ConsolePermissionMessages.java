package org.eclipse.kapua.app.console.module.authorization.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/authorization/src/main/resources/org/eclipse/kapua/app/console/module/authorization/client/messages/ConsolePermissionMessages.properties'.
 */
public interface ConsolePermissionMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "Permission successfully added.".
   * 
   * @return translated "Permission successfully added."
   */
  @DefaultMessage("Permission successfully added.")
  @Key("dialogAddConfirmation")
  String dialogAddConfirmation();

  /**
   * Translated "Permission granting failed: {0}".
   * 
   * @return translated "Permission granting failed: {0}"
   */
  @DefaultMessage("Permission granting failed: {0}")
  @Key("dialogAddError")
  String dialogAddError(String arg0);

  /**
   * Translated "Action".
   * 
   * @return translated "Action"
   */
  @DefaultMessage("Action")
  @Key("dialogAddFieldGridRolePermissionAction")
  String dialogAddFieldGridRolePermissionAction();

  /**
   * Translated "Domain".
   * 
   * @return translated "Domain"
   */
  @DefaultMessage("Domain")
  @Key("dialogAddFieldGridRolePermissionDomain")
  String dialogAddFieldGridRolePermissionDomain();

  /**
   * Translated "Target Scope Id".
   * 
   * @return translated "Target Scope Id"
   */
  @DefaultMessage("Target Scope Id")
  @Key("dialogAddFieldGridRolePermissionTargetScopeId")
  String dialogAddFieldGridRolePermissionTargetScopeId();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("dialogAddFieldName")
  String dialogAddFieldName();

  /**
   * Translated "The name of the new role. It must be unique.".
   * 
   * @return translated "The name of the new role. It must be unique."
   */
  @DefaultMessage("The name of the new role. It must be unique.")
  @Key("dialogAddFieldNameTooltip")
  String dialogAddFieldNameTooltip();

  /**
   * Translated "Select a group if you want to limit user to this group or leave the default value for no restrictions.".
   * 
   * @return translated "Select a group if you want to limit user to this group or leave the default value for no restrictions."
   */
  @DefaultMessage("Select a group if you want to limit user to this group or leave the default value for no restrictions.")
  @Key("dialogAddFieldPermissionAccessGroupTooltip")
  String dialogAddFieldPermissionAccessGroupTooltip();

  /**
   * Translated "Select actions for the picked domain.".
   * 
   * @return translated "Select actions for the picked domain."
   */
  @DefaultMessage("Select actions for the picked domain.")
  @Key("dialogAddFieldPermissionsActionTooltip")
  String dialogAddFieldPermissionsActionTooltip();

  /**
   * Translated "Select a domain from which you wish to add permissions.".
   * 
   * @return translated "Select a domain from which you wish to add permissions."
   */
  @DefaultMessage("Select a domain from which you wish to add permissions.")
  @Key("dialogAddFieldPermissionsDomainTooltip")
  String dialogAddFieldPermissionsDomainTooltip();

  /**
   * Translated "Set this option to True, if you want to user to be able to set this set of permissions to all its child users and if you want the user to be able to see Settings and Child Account Settings.".
   * 
   * @return translated "Set this option to True, if you want to user to be able to set this set of permissions to all its child users and if you want the user to be able to see Settings and Child Account Settings."
   */
  @DefaultMessage("Set this option to True, if you want to user to be able to set this set of permissions to all its child users and if you want the user to be able to see Settings and Child Account Settings.")
  @Key("dialogAddFieldPermissionsForwardableTooltip")
  String dialogAddFieldPermissionsForwardableTooltip();

  /**
   * Translated "Role permissions".
   * 
   * @return translated "Role permissions"
   */
  @DefaultMessage("Role permissions")
  @Key("dialogAddFieldRolePermissions")
  String dialogAddFieldRolePermissions();

  /**
   * Translated "The permissions associated with the new role.".
   * 
   * @return translated "The permissions associated with the new role."
   */
  @DefaultMessage("The permissions associated with the new role.")
  @Key("dialogAddFieldRolePermissionsTooltip")
  String dialogAddFieldRolePermissionsTooltip();

  /**
   * Translated "Create new role".
   * 
   * @return translated "Create new role"
   */
  @DefaultMessage("Create new role")
  @Key("dialogAddHeader")
  String dialogAddHeader();

  /**
   * Translated "Create a new role. ".
   * 
   * @return translated "Create a new role. "
   */
  @DefaultMessage("Create a new role. ")
  @Key("dialogAddInfo")
  String dialogAddInfo();

  /**
   * Translated "Action".
   * 
   * @return translated "Action"
   */
  @DefaultMessage("Action")
  @Key("dialogAddPermissionAction")
  String dialogAddPermissionAction();

  /**
   * Translated "Permission already granted.".
   * 
   * @return translated "Permission already granted."
   */
  @DefaultMessage("Permission already granted.")
  @Key("dialogAddPermissionAlreadyExists")
  String dialogAddPermissionAlreadyExists();

  /**
   * Translated "Grant".
   * 
   * @return translated "Grant"
   */
  @DefaultMessage("Grant")
  @Key("dialogAddPermissionButton")
  String dialogAddPermissionButton();

  /**
   * Translated "Permission association successfully granted.".
   * 
   * @return translated "Permission association successfully granted."
   */
  @DefaultMessage("Permission association successfully granted.")
  @Key("dialogAddPermissionConfirmation")
  String dialogAddPermissionConfirmation();

  /**
   * Translated "Domain".
   * 
   * @return translated "Domain"
   */
  @DefaultMessage("Domain")
  @Key("dialogAddPermissionDomain")
  String dialogAddPermissionDomain();

  /**
   * Translated "Error granting permission: {0}".
   * 
   * @return translated "Error granting permission: {0}"
   */
  @DefaultMessage("Error granting permission: {0}")
  @Key("dialogAddPermissionError")
  String dialogAddPermissionError(String arg0);

  /**
   * Translated "Error retrieving AccessInfo: {0}".
   * 
   * @return translated "Error retrieving AccessInfo: {0}"
   */
  @DefaultMessage("Error retrieving AccessInfo: {0}")
  @Key("dialogAddPermissionErrorAccessInfo")
  String dialogAddPermissionErrorAccessInfo(String arg0);

  /**
   * Translated "Error retrieving actions: {0}".
   * 
   * @return translated "Error retrieving actions: {0}"
   */
  @DefaultMessage("Error retrieving actions: {0}")
  @Key("dialogAddPermissionErrorActions")
  String dialogAddPermissionErrorActions(String arg0);

  /**
   * Translated "Error retrieving domains: {0}".
   * 
   * @return translated "Error retrieving domains: {0}"
   */
  @DefaultMessage("Error retrieving domains: {0}")
  @Key("dialogAddPermissionErrorDomains")
  String dialogAddPermissionErrorDomains(String arg0);

  /**
   * Translated "Error retrieving groups: {0}".
   * 
   * @return translated "Error retrieving groups: {0}"
   */
  @DefaultMessage("Error retrieving groups: {0}")
  @Key("dialogAddPermissionErrorGroups")
  String dialogAddPermissionErrorGroups(String arg0);

  /**
   * Translated "Forwardable".
   * 
   * @return translated "Forwardable"
   */
  @DefaultMessage("Forwardable")
  @Key("dialogAddPermissionForwardable")
  String dialogAddPermissionForwardable();

  /**
   * Translated "Access Group".
   * 
   * @return translated "Access Group"
   */
  @DefaultMessage("Access Group")
  @Key("dialogAddPermissionGroupId")
  String dialogAddPermissionGroupId();

  /**
   * Translated "The Selected Domain Is Not Groupable".
   * 
   * @return translated "The Selected Domain Is Not Groupable"
   */
  @DefaultMessage("The Selected Domain Is Not Groupable")
  @Key("dialogAddPermissionGroupIdNotGroupable")
  String dialogAddPermissionGroupIdNotGroupable();

  /**
   * Translated "Grant Permission".
   * 
   * @return translated "Grant Permission"
   */
  @DefaultMessage("Grant Permission")
  @Key("dialogAddPermissionHeader")
  String dialogAddPermissionHeader();

  /**
   * Translated "Select the permission that should be granted to the user.".
   * 
   * @return translated "Select the permission that should be granted to the user."
   */
  @DefaultMessage("Select the permission that should be granted to the user.")
  @Key("dialogAddPermissionInfo")
  String dialogAddPermissionInfo();

  /**
   * Translated "Loading...".
   * 
   * @return translated "Loading..."
   */
  @DefaultMessage("Loading...")
  @Key("dialogAddPermissionLoading")
  String dialogAddPermissionLoading();

  /**
   * Translated "Assign".
   * 
   * @return translated "Assign"
   */
  @DefaultMessage("Assign")
  @Key("dialogAddRoleButton")
  String dialogAddRoleButton();

  /**
   * Translated "Select A Role".
   * 
   * @return translated "Select A Role"
   */
  @DefaultMessage("Select A Role")
  @Key("dialogAddRoleComboEmptyText")
  String dialogAddRoleComboEmptyText();

  /**
   * Translated "No Roles found...".
   * 
   * @return translated "No Roles found..."
   */
  @DefaultMessage("No Roles found...")
  @Key("dialogAddRoleComboEmptyTextNoRoles")
  String dialogAddRoleComboEmptyTextNoRoles();

  /**
   * Translated "Role".
   * 
   * @return translated "Role"
   */
  @DefaultMessage("Role")
  @Key("dialogAddRoleComboName")
  String dialogAddRoleComboName();

  /**
   * Translated "Select a role from the list to be assigned to the user.".
   * 
   * @return translated "Select a role from the list to be assigned to the user."
   */
  @DefaultMessage("Select a role from the list to be assigned to the user.")
  @Key("dialogAddRoleComboNameTooltip")
  String dialogAddRoleComboNameTooltip();

  /**
   * Translated "Role successfully assigned.".
   * 
   * @return translated "Role successfully assigned."
   */
  @DefaultMessage("Role successfully assigned.")
  @Key("dialogAddRoleConfirmation")
  String dialogAddRoleConfirmation();

  /**
   * Translated "Error when assigning role: An entity with the same value for field already exists.".
   * 
   * @return translated "Error when assigning role: An entity with the same value for field already exists."
   */
  @DefaultMessage("Error when assigning role: An entity with the same value for field already exists.")
  @Key("dialogAddRoleDuplicateError")
  String dialogAddRoleDuplicateError();

  /**
   * Translated "Error assigning role: {0}".
   * 
   * @return translated "Error assigning role: {0}"
   */
  @DefaultMessage("Error assigning role: {0}")
  @Key("dialogAddRoleError")
  String dialogAddRoleError(String arg0);

  /**
   * Translated "Error retrieving AccessInfo: {0}".
   * 
   * @return translated "Error retrieving AccessInfo: {0}"
   */
  @DefaultMessage("Error retrieving AccessInfo: {0}")
  @Key("dialogAddRoleErrorAccessInfo")
  String dialogAddRoleErrorAccessInfo(String arg0);

  /**
   * Translated "Assign Role".
   * 
   * @return translated "Assign Role"
   */
  @DefaultMessage("Assign Role")
  @Key("dialogAddRoleHeader")
  String dialogAddRoleHeader();

  /**
   * Translated "Select a role that should be assigned to the user.".
   * 
   * @return translated "Select a role that should be assigned to the user."
   */
  @DefaultMessage("Select a role that should be assigned to the user.")
  @Key("dialogAddRoleInfo")
  String dialogAddRoleInfo();

  /**
   * Translated "Role deleted successfully.".
   * 
   * @return translated "Role deleted successfully."
   */
  @DefaultMessage("Role deleted successfully.")
  @Key("dialogDeleteConfirmation")
  String dialogDeleteConfirmation();

  /**
   * Translated "Role delete failed: {0}".
   * 
   * @return translated "Role delete failed: {0}"
   */
  @DefaultMessage("Role delete failed: {0}")
  @Key("dialogDeleteError")
  String dialogDeleteError(String arg0);

  /**
   * Translated "Delete role: {0}".
   * 
   * @return translated "Delete role: {0}"
   */
  @DefaultMessage("Delete role: {0}")
  @Key("dialogDeleteHeader")
  String dialogDeleteHeader(String arg0);

  /**
   * Translated "Delete the selected role and all associated permission? Also all user will lose this role if deleted.".
   * 
   * @return translated "Delete the selected role and all associated permission? Also all user will lose this role if deleted."
   */
  @DefaultMessage("Delete the selected role and all associated permission? Also all user will lose this role if deleted.")
  @Key("dialogDeleteInfo")
  String dialogDeleteInfo();

  /**
   * Translated "Revoke".
   * 
   * @return translated "Revoke"
   */
  @DefaultMessage("Revoke")
  @Key("dialogDeletePermissionButton")
  String dialogDeletePermissionButton();

  /**
   * Translated "Permission successfully revoked.".
   * 
   * @return translated "Permission successfully revoked."
   */
  @DefaultMessage("Permission successfully revoked.")
  @Key("dialogDeletePermissionConfirmation")
  String dialogDeletePermissionConfirmation();

  /**
   * Translated "Permission revoke failed: {0}".
   * 
   * @return translated "Permission revoke failed: {0}"
   */
  @DefaultMessage("Permission revoke failed: {0}")
  @Key("dialogDeletePermissionError")
  String dialogDeletePermissionError(String arg0);

  /**
   * Translated "Revoke Permission".
   * 
   * @return translated "Revoke Permission"
   */
  @DefaultMessage("Revoke Permission")
  @Key("dialogDeletePermissionHeader")
  String dialogDeletePermissionHeader();

  /**
   * Translated "Are you sure you want to revoke the selected permission from the user?".
   * 
   * @return translated "Are you sure you want to revoke the selected permission from the user?"
   */
  @DefaultMessage("Are you sure you want to revoke the selected permission from the user?")
  @Key("dialogDeletePermissionInfo")
  String dialogDeletePermissionInfo();

  /**
   * Translated "Remove".
   * 
   * @return translated "Remove"
   */
  @DefaultMessage("Remove")
  @Key("dialogDeleteRoleButton")
  String dialogDeleteRoleButton();

  /**
   * Translated "Role association successfully removed.".
   * 
   * @return translated "Role association successfully removed."
   */
  @DefaultMessage("Role association successfully removed.")
  @Key("dialogDeleteRoleConfirmation")
  String dialogDeleteRoleConfirmation();

  /**
   * Translated "User association removal failed: {0}".
   * 
   * @return translated "User association removal failed: {0}"
   */
  @DefaultMessage("User association removal failed: {0}")
  @Key("dialogDeleteRoleError")
  String dialogDeleteRoleError(String arg0);

  /**
   * Translated "Remove Role Association: {0}".
   * 
   * @return translated "Remove Role Association: {0}"
   */
  @DefaultMessage("Remove Role Association: {0}")
  @Key("dialogDeleteRoleHeader")
  String dialogDeleteRoleHeader(String arg0);

  /**
   * Translated "Remove the association between the user and the role?".
   * 
   * @return translated "Remove the association between the user and the role?"
   */
  @DefaultMessage("Remove the association between the user and the role?")
  @Key("dialogDeleteRoleInfo")
  String dialogDeleteRoleInfo();

  /**
   * Translated "Role edited successfully.".
   * 
   * @return translated "Role edited successfully."
   */
  @DefaultMessage("Role edited successfully.")
  @Key("dialogEditConfirmation")
  String dialogEditConfirmation();

  /**
   * Translated "Role edit failed: {0}".
   * 
   * @return translated "Role edit failed: {0}"
   */
  @DefaultMessage("Role edit failed: {0}")
  @Key("dialogEditError")
  String dialogEditError(String arg0);

  /**
   * Translated "Added By".
   * 
   * @return translated "Added By"
   */
  @DefaultMessage("Added By")
  @Key("dialogEditFieldGridRolePermissionCreatedBy")
  String dialogEditFieldGridRolePermissionCreatedBy();

  /**
   * Translated "Added On".
   * 
   * @return translated "Added On"
   */
  @DefaultMessage("Added On")
  @Key("dialogEditFieldGridRolePermissionCreatedOn")
  String dialogEditFieldGridRolePermissionCreatedOn();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("dialogEditFieldGridRolePermissionId")
  String dialogEditFieldGridRolePermissionId();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("dialogEditFieldName")
  String dialogEditFieldName();

  /**
   * Translated "The name of the role. It must be unique.".
   * 
   * @return translated "The name of the role. It must be unique."
   */
  @DefaultMessage("The name of the role. It must be unique.")
  @Key("dialogEditFieldNameTooltip")
  String dialogEditFieldNameTooltip();

  /**
   * Translated "Role permissions".
   * 
   * @return translated "Role permissions"
   */
  @DefaultMessage("Role permissions")
  @Key("dialogEditFieldRolePermissions")
  String dialogEditFieldRolePermissions();

  /**
   * Translated "The permissions associated with the role.".
   * 
   * @return translated "The permissions associated with the role."
   */
  @DefaultMessage("The permissions associated with the role.")
  @Key("dialogEditFieldRolePermissionsTooltip")
  String dialogEditFieldRolePermissionsTooltip();

  /**
   * Translated "Edit role: {0}".
   * 
   * @return translated "Edit role: {0}"
   */
  @DefaultMessage("Edit role: {0}")
  @Key("dialogEditHeader")
  String dialogEditHeader(String arg0);

  /**
   * Translated "Edit role&#39;s name.".
   * 
   * @return translated "Edit role&#39;s name."
   */
  @DefaultMessage("Edit role&#39;s name.")
  @Key("dialogEditInfo")
  String dialogEditInfo();

  /**
   * Translated "Cannot load role: {0}".
   * 
   * @return translated "Cannot load role: {0}"
   */
  @DefaultMessage("Cannot load role: {0}")
  @Key("dialogEditLoadFailed")
  String dialogEditLoadFailed(String arg0);

  /**
   * Translated "Role Name".
   * 
   * @return translated "Role Name"
   */
  @DefaultMessage("Role Name")
  @Key("filterFieldRoleNameLabel")
  String filterFieldRoleNameLabel();

  /**
   * Translated "Role Filter".
   * 
   * @return translated "Role Filter"
   */
  @DefaultMessage("Role Filter")
  @Key("filterHeader")
  String filterHeader();

  /**
   * Translated "Action".
   * 
   * @return translated "Action"
   */
  @DefaultMessage("Action")
  @Key("gridAccessRoleColumnHeaderAction")
  String gridAccessRoleColumnHeaderAction();

  /**
   * Translated "Granted By".
   * 
   * @return translated "Granted By"
   */
  @DefaultMessage("Granted By")
  @Key("gridAccessRoleColumnHeaderCreatedBy")
  String gridAccessRoleColumnHeaderCreatedBy();

  /**
   * Translated "Granted On".
   * 
   * @return translated "Granted On"
   */
  @DefaultMessage("Granted On")
  @Key("gridAccessRoleColumnHeaderCreatedOn")
  String gridAccessRoleColumnHeaderCreatedOn();

  /**
   * Translated "Domain".
   * 
   * @return translated "Domain"
   */
  @DefaultMessage("Domain")
  @Key("gridAccessRoleColumnHeaderDomain")
  String gridAccessRoleColumnHeaderDomain();

  /**
   * Translated "Forwardable".
   * 
   * @return translated "Forwardable"
   */
  @DefaultMessage("Forwardable")
  @Key("gridAccessRoleColumnHeaderForwardable")
  String gridAccessRoleColumnHeaderForwardable();

  /**
   * Translated "Group Id".
   * 
   * @return translated "Group Id"
   */
  @DefaultMessage("Group Id")
  @Key("gridAccessRoleColumnHeaderGroupId")
  String gridAccessRoleColumnHeaderGroupId();

  /**
   * Translated "Group Name".
   * 
   * @return translated "Group Name"
   */
  @DefaultMessage("Group Name")
  @Key("gridAccessRoleColumnHeaderGroupName")
  String gridAccessRoleColumnHeaderGroupName();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridAccessRoleColumnHeaderId")
  String gridAccessRoleColumnHeaderId();

  /**
   * Translated "Target Scope Id".
   * 
   * @return translated "Target Scope Id"
   */
  @DefaultMessage("Target Scope Id")
  @Key("gridAccessRoleColumnHeaderTargetScopeId")
  String gridAccessRoleColumnHeaderTargetScopeId();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultMessage("Created By")
  @Key("gridRoleColumnHeaderCreatedBy")
  String gridRoleColumnHeaderCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("gridRoleColumnHeaderCreatedOn")
  String gridRoleColumnHeaderCreatedOn();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridRoleColumnHeaderId")
  String gridRoleColumnHeaderId();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("gridRoleColumnHeaderName")
  String gridRoleColumnHeaderName();

  /**
   * Translated "Action".
   * 
   * @return translated "Action"
   */
  @DefaultMessage("Action")
  @Key("gridRolePermissionColumnHeaderAction")
  String gridRolePermissionColumnHeaderAction();

  /**
   * Translated "Added By".
   * 
   * @return translated "Added By"
   */
  @DefaultMessage("Added By")
  @Key("gridRolePermissionColumnHeaderCreatedBy")
  String gridRolePermissionColumnHeaderCreatedBy();

  /**
   * Translated "Added On".
   * 
   * @return translated "Added On"
   */
  @DefaultMessage("Added On")
  @Key("gridRolePermissionColumnHeaderCreatedOn")
  String gridRolePermissionColumnHeaderCreatedOn();

  /**
   * Translated "Domain".
   * 
   * @return translated "Domain"
   */
  @DefaultMessage("Domain")
  @Key("gridRolePermissionColumnHeaderDomain")
  String gridRolePermissionColumnHeaderDomain();

  /**
   * Translated "Forwardable".
   * 
   * @return translated "Forwardable"
   */
  @DefaultMessage("Forwardable")
  @Key("gridRolePermissionColumnHeaderForwardable")
  String gridRolePermissionColumnHeaderForwardable();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridRolePermissionColumnHeaderId")
  String gridRolePermissionColumnHeaderId();

  /**
   * Translated "Target Group".
   * 
   * @return translated "Target Group"
   */
  @DefaultMessage("Target Group")
  @Key("gridRolePermissionColumnHeaderTargetGroup")
  String gridRolePermissionColumnHeaderTargetGroup();

  /**
   * Translated "Target Scope Id".
   * 
   * @return translated "Target Scope Id"
   */
  @DefaultMessage("Target Scope Id")
  @Key("gridRolePermissionColumnHeaderTargetScopeId")
  String gridRolePermissionColumnHeaderTargetScopeId();

  /**
   * Translated "Revoke".
   * 
   * @return translated "Revoke"
   */
  @DefaultMessage("Revoke")
  @Key("gridRolePermissionToolbarDeleteButton")
  String gridRolePermissionToolbarDeleteButton();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridRoleSubjectColumnHeaderId")
  String gridRoleSubjectColumnHeaderId();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("gridRoleSubjectColumnHeaderName")
  String gridRoleSubjectColumnHeaderName();

  /**
   * Translated "Type".
   * 
   * @return translated "Type"
   */
  @DefaultMessage("Type")
  @Key("gridRoleSubjectColumnHeaderType")
  String gridRoleSubjectColumnHeaderType();

  /**
   * Translated "Permissions".
   * 
   * @return translated "Permissions"
   */
  @DefaultMessage("Permissions")
  @Key("gridUserTabPermissionsLabel")
  String gridUserTabPermissionsLabel();

  /**
   * Translated "Roles".
   * 
   * @return translated "Roles"
   */
  @DefaultMessage("Roles")
  @Key("gridUserTabRolesLabel")
  String gridUserTabRolesLabel();

  /**
   * Translated "Action".
   * 
   * @return translated "Action"
   */
  @DefaultMessage("Action")
  @Key("permissionAddDialogAction")
  String permissionAddDialogAction();

  /**
   * Translated "Select actions for the picked domain.".
   * 
   * @return translated "Select actions for the picked domain."
   */
  @DefaultMessage("Select actions for the picked domain.")
  @Key("permissionAddDialogActionTooltip")
  String permissionAddDialogActionTooltip();

  /**
   * Translated "Domain".
   * 
   * @return translated "Domain"
   */
  @DefaultMessage("Domain")
  @Key("permissionAddDialogDomain")
  String permissionAddDialogDomain();

  /**
   * Translated "Select a domain from which you wish to add permissions.".
   * 
   * @return translated "Select a domain from which you wish to add permissions."
   */
  @DefaultMessage("Select a domain from which you wish to add permissions.")
  @Key("permissionAddDialogDomainTooltip")
  String permissionAddDialogDomainTooltip();

  /**
   * Translated "Forwardable".
   * 
   * @return translated "Forwardable"
   */
  @DefaultMessage("Forwardable")
  @Key("permissionAddDialogForwardable")
  String permissionAddDialogForwardable();

  /**
   * Translated "Set this option to True, if you want the user to be able to set this set of permissions to all its child users and if you want the user to be able to see Settings and Child Account Settings.".
   * 
   * @return translated "Set this option to True, if you want the user to be able to set this set of permissions to all its child users and if you want the user to be able to see Settings and Child Account Settings."
   */
  @DefaultMessage("Set this option to True, if you want the user to be able to set this set of permissions to all its child users and if you want the user to be able to see Settings and Child Account Settings.")
  @Key("permissionAddDialogForwardableTooltip")
  String permissionAddDialogForwardableTooltip();

  /**
   * Translated "Group".
   * 
   * @return translated "Group"
   */
  @DefaultMessage("Group")
  @Key("permissionAddDialogGroup")
  String permissionAddDialogGroup();

  /**
   * Translated "The Selected Domain Is Not Groupable".
   * 
   * @return translated "The Selected Domain Is Not Groupable"
   */
  @DefaultMessage("The Selected Domain Is Not Groupable")
  @Key("permissionAddDialogGroupNotGroupable")
  String permissionAddDialogGroupNotGroupable();

  /**
   * Translated "Select a group if you want to limit user to this group or leave the default value for no restrictions.".
   * 
   * @return translated "Select a group if you want to limit user to this group or leave the default value for no restrictions."
   */
  @DefaultMessage("Select a group if you want to limit user to this group or leave the default value for no restrictions.")
  @Key("permissionAddDialogGroupTooltip")
  String permissionAddDialogGroupTooltip();

  /**
   * Translated "Add New Permission".
   * 
   * @return translated "Add New Permission"
   */
  @DefaultMessage("Add New Permission")
  @Key("permissionAddDialogHeader")
  String permissionAddDialogHeader();

  /**
   * Translated "Loading...".
   * 
   * @return translated "Loading..."
   */
  @DefaultMessage("Loading...")
  @Key("permissionAddDialogLoading")
  String permissionAddDialogLoading();

  /**
   * Translated "Select the permission that should be granted to the role.".
   * 
   * @return translated "Select the permission that should be granted to the role."
   */
  @DefaultMessage("Select the permission that should be granted to the role.")
  @Key("permissionAddDialogMessage")
  String permissionAddDialogMessage();

  /**
   * Translated "Delete Permissions: {0}".
   * 
   * @return translated "Delete Permissions: {0}"
   */
  @DefaultMessage("Delete Permissions: {0}")
  @Key("permissionDeleteDialogHeader")
  String permissionDeleteDialogHeader(String arg0);

  /**
   * Translated "Delete selected permission?".
   * 
   * @return translated "Delete selected permission?"
   */
  @DefaultMessage("Delete selected permission?")
  @Key("permissionDeleteDialogMessage")
  String permissionDeleteDialogMessage();

  /**
   * Translated "Permission".
   * 
   * @return translated "Permission"
   */
  @DefaultMessage("Permission")
  @Key("roleTabPermissionGridTitle")
  String roleTabPermissionGridTitle();

  /**
   * Translated "Subject".
   * 
   * @return translated "Subject"
   */
  @DefaultMessage("Subject")
  @Key("roleTabSubjectGridTitle")
  String roleTabSubjectGridTitle();
}
