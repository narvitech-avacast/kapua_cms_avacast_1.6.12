package org.eclipse.kapua.app.console.module.authorization.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtDomainRegistryServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtDomainRegistryService
     */
    void findAll( AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtDomain>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtDomainRegistryService
     */
    void findActionsByDomainName( java.lang.String domainName, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtPermission.GwtAction>> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtDomainRegistryServiceAsync instance;

        public static final GwtDomainRegistryServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtDomainRegistryServiceAsync) GWT.create( GwtDomainRegistryService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "domain" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
