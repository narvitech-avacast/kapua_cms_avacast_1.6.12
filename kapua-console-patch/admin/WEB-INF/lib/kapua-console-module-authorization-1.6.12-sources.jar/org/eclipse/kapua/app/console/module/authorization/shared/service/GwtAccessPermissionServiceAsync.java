package org.eclipse.kapua.app.console.module.authorization.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtAccessPermissionServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtAccessPermissionService
     */
    void create( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, org.eclipse.kapua.app.console.module.authorization.shared.model.GwtAccessPermissionCreator gwtAccessPermissionCreator, AsyncCallback<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtAccessPermission> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtAccessPermissionService
     */
    void findByUserId( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, java.lang.String scopeShortId, java.lang.String userShortId, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtAccessPermission>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtAccessPermissionService
     */
    void delete( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, java.lang.String scopeShortId, java.lang.String accessPermissionShortId, AsyncCallback<Void> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtAccessPermissionServiceAsync instance;

        public static final GwtAccessPermissionServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtAccessPermissionServiceAsync) GWT.create( GwtAccessPermissionService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "accesspermission" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
