package org.eclipse.kapua.app.console.module.authorization.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtRoleServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtRoleService
     */
    void create( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, org.eclipse.kapua.app.console.module.authorization.shared.model.GwtRoleCreator gwtRoleCreator, AsyncCallback<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtRole> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtRoleService
     */
    void update( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, org.eclipse.kapua.app.console.module.authorization.shared.model.GwtRole gwtRole, AsyncCallback<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtRole> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtRoleService
     */
    void find( java.lang.String scopeShortId, java.lang.String roleShortId, AsyncCallback<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtRole> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtRoleService
     */
    void findAll( java.lang.String scopeIdStirng, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtRole>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtRoleService
     */
    void query( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.authorization.shared.model.GwtRoleQuery gwtRoleQuery, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtRole>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtRoleService
     */
    void getRoleDescription( java.lang.String scopeShortId, java.lang.String roleShortId, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.api.shared.model.GwtGroupedNVPair>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtRoleService
     */
    void getRolePermissions( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, java.lang.String scopeShortId, java.lang.String roleShortId, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtRolePermission>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtRoleService
     */
    void delete( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, java.lang.String scopeShortId, java.lang.String roleShortId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtRoleService
     */
    void addRolePermission( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, org.eclipse.kapua.app.console.module.authorization.shared.model.GwtRolePermissionCreator gwtRolePermissionCreator, org.eclipse.kapua.app.console.module.authorization.shared.model.GwtPermission gwtPermission, AsyncCallback<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtRolePermission> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtRoleService
     */
    void deleteRolePermission( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, java.lang.String scopeShortId, java.lang.String roleShortId, AsyncCallback<Void> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtRoleServiceAsync instance;

        public static final GwtRoleServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtRoleServiceAsync) GWT.create( GwtRoleService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "role" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
