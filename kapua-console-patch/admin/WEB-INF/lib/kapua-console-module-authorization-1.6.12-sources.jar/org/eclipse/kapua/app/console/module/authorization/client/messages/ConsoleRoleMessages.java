package org.eclipse.kapua.app.console.module.authorization.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/authorization/src/main/resources/org/eclipse/kapua/app/console/module/authorization/client/messages/ConsoleRoleMessages.properties'.
 */
public interface ConsoleRoleMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "Role successfully created.".
   * 
   * @return translated "Role successfully created."
   */
  @DefaultMessage("Role successfully created.")
  @Key("dialogAddConfirmation")
  String dialogAddConfirmation();

  /**
   * Translated "Role creation failed: {0}".
   * 
   * @return translated "Role creation failed: {0}"
   */
  @DefaultMessage("Role creation failed: {0}")
  @Key("dialogAddError")
  String dialogAddError(String arg0);

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("dialogAddFieldDescription")
  String dialogAddFieldDescription();

  /**
   * Translated "Enter a role description for detailed information about the role.".
   * 
   * @return translated "Enter a role description for detailed information about the role."
   */
  @DefaultMessage("Enter a role description for detailed information about the role.")
  @Key("dialogAddFieldDescriptionTooltip")
  String dialogAddFieldDescriptionTooltip();

  /**
   * Translated "Action".
   * 
   * @return translated "Action"
   */
  @DefaultMessage("Action")
  @Key("dialogAddFieldGridRolePermissionAction")
  String dialogAddFieldGridRolePermissionAction();

  /**
   * Translated "Domain".
   * 
   * @return translated "Domain"
   */
  @DefaultMessage("Domain")
  @Key("dialogAddFieldGridRolePermissionDomain")
  String dialogAddFieldGridRolePermissionDomain();

  /**
   * Translated "Target Scope Id".
   * 
   * @return translated "Target Scope Id"
   */
  @DefaultMessage("Target Scope Id")
  @Key("dialogAddFieldGridRolePermissionTargetScopeId")
  String dialogAddFieldGridRolePermissionTargetScopeId();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("dialogAddFieldName")
  String dialogAddFieldName();

  /**
   * Translated "Role name should be at least 3 characters long and can contain alphanumeric characters combined with dash and/or underscore.".
   * 
   * @return translated "Role name should be at least 3 characters long and can contain alphanumeric characters combined with dash and/or underscore."
   */
  @DefaultMessage("Role name should be at least 3 characters long and can contain alphanumeric characters combined with dash and/or underscore.")
  @Key("dialogAddFieldNameTooltip")
  String dialogAddFieldNameTooltip();

  /**
   * Translated "Role permissions".
   * 
   * @return translated "Role permissions"
   */
  @DefaultMessage("Role permissions")
  @Key("dialogAddFieldRolePermissions")
  String dialogAddFieldRolePermissions();

  /**
   * Translated "The permissions associated with the new role.".
   * 
   * @return translated "The permissions associated with the new role."
   */
  @DefaultMessage("The permissions associated with the new role.")
  @Key("dialogAddFieldRolePermissionsTooltip")
  String dialogAddFieldRolePermissionsTooltip();

  /**
   * Translated "New Role".
   * 
   * @return translated "New Role"
   */
  @DefaultMessage("New Role")
  @Key("dialogAddHeader")
  String dialogAddHeader();

  /**
   * Translated "Create a new role providing a name and an optional description. ".
   * 
   * @return translated "Create a new role providing a name and an optional description. "
   */
  @DefaultMessage("Create a new role providing a name and an optional description. ")
  @Key("dialogAddInfo")
  String dialogAddInfo();

  /**
   * Translated "Role successfully deleted.".
   * 
   * @return translated "Role successfully deleted."
   */
  @DefaultMessage("Role successfully deleted.")
  @Key("dialogDeleteConfirmation")
  String dialogDeleteConfirmation();

  /**
   * Translated "Role delete failed: {0}".
   * 
   * @return translated "Role delete failed: {0}"
   */
  @DefaultMessage("Role delete failed: {0}")
  @Key("dialogDeleteError")
  String dialogDeleteError(String arg0);

  /**
   * Translated "Delete Role: {0}".
   * 
   * @return translated "Delete Role: {0}"
   */
  @DefaultMessage("Delete Role: {0}")
  @Key("dialogDeleteHeader")
  String dialogDeleteHeader(String arg0);

  /**
   * Translated "Are you sure you want to delete the selected role?".
   * 
   * @return translated "Are you sure you want to delete the selected role?"
   */
  @DefaultMessage("Are you sure you want to delete the selected role?")
  @Key("dialogDeleteInfo")
  String dialogDeleteInfo();

  /**
   * Translated "Role successfully updated.".
   * 
   * @return translated "Role successfully updated."
   */
  @DefaultMessage("Role successfully updated.")
  @Key("dialogEditConfirmation")
  String dialogEditConfirmation();

  /**
   * Translated "Role edit failed: {0}".
   * 
   * @return translated "Role edit failed: {0}"
   */
  @DefaultMessage("Role edit failed: {0}")
  @Key("dialogEditError")
  String dialogEditError(String arg0);

  /**
   * Translated "Added By".
   * 
   * @return translated "Added By"
   */
  @DefaultMessage("Added By")
  @Key("dialogEditFieldGridRolePermissionCreatedBy")
  String dialogEditFieldGridRolePermissionCreatedBy();

  /**
   * Translated "Added On".
   * 
   * @return translated "Added On"
   */
  @DefaultMessage("Added On")
  @Key("dialogEditFieldGridRolePermissionCreatedOn")
  String dialogEditFieldGridRolePermissionCreatedOn();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("dialogEditFieldGridRolePermissionId")
  String dialogEditFieldGridRolePermissionId();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("dialogEditFieldName")
  String dialogEditFieldName();

  /**
   * Translated "The name of the role. It must be unique.".
   * 
   * @return translated "The name of the role. It must be unique."
   */
  @DefaultMessage("The name of the role. It must be unique.")
  @Key("dialogEditFieldNameTooltip")
  String dialogEditFieldNameTooltip();

  /**
   * Translated "Role permissions".
   * 
   * @return translated "Role permissions"
   */
  @DefaultMessage("Role permissions")
  @Key("dialogEditFieldRolePermissions")
  String dialogEditFieldRolePermissions();

  /**
   * Translated "The permissions associated with the role.".
   * 
   * @return translated "The permissions associated with the role."
   */
  @DefaultMessage("The permissions associated with the role.")
  @Key("dialogEditFieldRolePermissionsTooltip")
  String dialogEditFieldRolePermissionsTooltip();

  /**
   * Translated "Edit Role: {0}".
   * 
   * @return translated "Edit Role: {0}"
   */
  @DefaultMessage("Edit Role: {0}")
  @Key("dialogEditHeader")
  String dialogEditHeader(String arg0);

  /**
   * Translated "Edit role''s data.".
   * 
   * @return translated "Edit role''s data."
   */
  @DefaultMessage("Edit role''s data.")
  @Key("dialogEditInfo")
  String dialogEditInfo();

  /**
   * Translated "Cannot load role: {0}".
   * 
   * @return translated "Cannot load role: {0}"
   */
  @DefaultMessage("Cannot load role: {0}")
  @Key("dialogEditLoadFailed")
  String dialogEditLoadFailed(String arg0);

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("filterFieldRoleDescriptionLabel")
  String filterFieldRoleDescriptionLabel();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("filterFieldRoleNameLabel")
  String filterFieldRoleNameLabel();

  /**
   * Translated "Role Filter".
   * 
   * @return translated "Role Filter"
   */
  @DefaultMessage("Role Filter")
  @Key("filterHeader")
  String filterHeader();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultMessage("Created By")
  @Key("gridRoleColumnHeaderCreatedBy")
  String gridRoleColumnHeaderCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("gridRoleColumnHeaderCreatedOn")
  String gridRoleColumnHeaderCreatedOn();

  /**
   * Translated "Description".
   * 
   * @return translated "Description"
   */
  @DefaultMessage("Description")
  @Key("gridRoleColumnHeaderDescription")
  String gridRoleColumnHeaderDescription();

  /**
   * Translated "Granted By".
   * 
   * @return translated "Granted By"
   */
  @DefaultMessage("Granted By")
  @Key("gridRoleColumnHeaderGrantedBy")
  String gridRoleColumnHeaderGrantedBy();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridRoleColumnHeaderId")
  String gridRoleColumnHeaderId();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultMessage("Modified By")
  @Key("gridRoleColumnHeaderModifiedBy")
  String gridRoleColumnHeaderModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultMessage("Modified On")
  @Key("gridRoleColumnHeaderModifiedOn")
  String gridRoleColumnHeaderModifiedOn();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("gridRoleColumnHeaderName")
  String gridRoleColumnHeaderName();

  /**
   * Translated "Action".
   * 
   * @return translated "Action"
   */
  @DefaultMessage("Action")
  @Key("gridRolePermissionColumnHeaderAction")
  String gridRolePermissionColumnHeaderAction();

  /**
   * Translated "Added By".
   * 
   * @return translated "Added By"
   */
  @DefaultMessage("Added By")
  @Key("gridRolePermissionColumnHeaderCreatedBy")
  String gridRolePermissionColumnHeaderCreatedBy();

  /**
   * Translated "Added On".
   * 
   * @return translated "Added On"
   */
  @DefaultMessage("Added On")
  @Key("gridRolePermissionColumnHeaderCreatedOn")
  String gridRolePermissionColumnHeaderCreatedOn();

  /**
   * Translated "Domain".
   * 
   * @return translated "Domain"
   */
  @DefaultMessage("Domain")
  @Key("gridRolePermissionColumnHeaderDomain")
  String gridRolePermissionColumnHeaderDomain();

  /**
   * Translated "Forwardable".
   * 
   * @return translated "Forwardable"
   */
  @DefaultMessage("Forwardable")
  @Key("gridRolePermissionColumnHeaderForwardable")
  String gridRolePermissionColumnHeaderForwardable();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridRolePermissionColumnHeaderId")
  String gridRolePermissionColumnHeaderId();

  /**
   * Translated "Target Group".
   * 
   * @return translated "Target Group"
   */
  @DefaultMessage("Target Group")
  @Key("gridRolePermissionColumnHeaderTargetGroup")
  String gridRolePermissionColumnHeaderTargetGroup();

  /**
   * Translated "Target Scope Id".
   * 
   * @return translated "Target Scope Id"
   */
  @DefaultMessage("Target Scope Id")
  @Key("gridRolePermissionColumnHeaderTargetScopeId")
  String gridRolePermissionColumnHeaderTargetScopeId();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultMessage("Display Name")
  @Key("gridRoleSubjectColumnHeaderDisplayName")
  String gridRoleSubjectColumnHeaderDisplayName();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridRoleSubjectColumnHeaderId")
  String gridRoleSubjectColumnHeaderId();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("gridRoleSubjectColumnHeaderName")
  String gridRoleSubjectColumnHeaderName();

  /**
   * Translated "Type".
   * 
   * @return translated "Type"
   */
  @DefaultMessage("Type")
  @Key("gridRoleSubjectColumnHeaderType")
  String gridRoleSubjectColumnHeaderType();

  /**
   * Translated "Roles".
   * 
   * @return translated "Roles"
   */
  @DefaultMessage("Roles")
  @Key("mainMenuRoles")
  String mainMenuRoles();

  /**
   * Translated "Action".
   * 
   * @return translated "Action"
   */
  @DefaultMessage("Action")
  @Key("permissionAddDialogAction")
  String permissionAddDialogAction();

  /**
   * Translated "Domain".
   * 
   * @return translated "Domain"
   */
  @DefaultMessage("Domain")
  @Key("permissionAddDialogDomain")
  String permissionAddDialogDomain();

  /**
   * Translated "Forwardable".
   * 
   * @return translated "Forwardable"
   */
  @DefaultMessage("Forwardable")
  @Key("permissionAddDialogForwardable")
  String permissionAddDialogForwardable();

  /**
   * Translated "Access Group".
   * 
   * @return translated "Access Group"
   */
  @DefaultMessage("Access Group")
  @Key("permissionAddDialogGroup")
  String permissionAddDialogGroup();

  /**
   * Translated "The selected domain is not groupable domain.".
   * 
   * @return translated "The selected domain is not groupable domain."
   */
  @DefaultMessage("The selected domain is not groupable domain.")
  @Key("permissionAddDialogGroupNotGroupable")
  String permissionAddDialogGroupNotGroupable();

  /**
   * Translated "Add New Permissions".
   * 
   * @return translated "Add New Permissions"
   */
  @DefaultMessage("Add New Permissions")
  @Key("permissionAddDialogHeader")
  String permissionAddDialogHeader();

  /**
   * Translated "Loading...".
   * 
   * @return translated "Loading..."
   */
  @DefaultMessage("Loading...")
  @Key("permissionAddDialogLoading")
  String permissionAddDialogLoading();

  /**
   * Translated "Add New Permission.".
   * 
   * @return translated "Add New Permission."
   */
  @DefaultMessage("Add New Permission.")
  @Key("permissionAddDialogMessage")
  String permissionAddDialogMessage();

  /**
   * Translated "Permission successfully deleted.".
   * 
   * @return translated "Permission successfully deleted."
   */
  @DefaultMessage("Permission successfully deleted.")
  @Key("permissionDeleteDialogConfirmation")
  String permissionDeleteDialogConfirmation();

  /**
   * Translated "Revoke Permission: {0}".
   * 
   * @return translated "Revoke Permission: {0}"
   */
  @DefaultMessage("Revoke Permission: {0}")
  @Key("permissionDeleteDialogHeader")
  String permissionDeleteDialogHeader(String arg0);

  /**
   * Translated "Are you sure you want to revoke the selected permission?".
   * 
   * @return translated "Are you sure you want to revoke the selected permission?"
   */
  @DefaultMessage("Are you sure you want to revoke the selected permission?")
  @Key("permissionDeleteDialogMessage")
  String permissionDeleteDialogMessage();

  /**
   * Translated "Permissions".
   * 
   * @return translated "Permissions"
   */
  @DefaultMessage("Permissions")
  @Key("roleTabPermissionGridTitle")
  String roleTabPermissionGridTitle();

  /**
   * Translated "Granted Users".
   * 
   * @return translated "Granted Users"
   */
  @DefaultMessage("Granted Users")
  @Key("roleTabSubjectGridTitle")
  String roleTabSubjectGridTitle();
}
