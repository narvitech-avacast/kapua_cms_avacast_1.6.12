package org.eclipse.kapua.app.console.module.authorization.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtAccessRoleServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtAccessRoleService
     */
    void create( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, org.eclipse.kapua.app.console.module.authorization.shared.model.GwtAccessRoleCreator gwtAccessRoleCreator, AsyncCallback<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtAccessRole> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtAccessRoleService
     */
    void delete( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, java.lang.String scopeShortId, java.lang.String accessRoleShortId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtAccessRoleService
     */
    void findByUserId( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, java.lang.String scopeShortId, java.lang.String userShortId, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtAccessRole>> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtAccessRoleServiceAsync instance;

        public static final GwtAccessRoleServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtAccessRoleServiceAsync) GWT.create( GwtAccessRoleService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "accessrole" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
