package org.eclipse.kapua.app.console.module.authorization.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtAccessInfoServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtAccessInfoService
     */
    void create( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, org.eclipse.kapua.app.console.module.authorization.shared.model.GwtAccessInfoCreator gwtAccessInfoCreator, AsyncCallback<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtAccessInfo> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtAccessInfoService
     */
    void delete( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, java.lang.String scopeShortId, java.lang.String roleShortId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.authorization.shared.service.GwtAccessInfoService
     */
    void findByUserIdOrCreate( java.lang.String scopeShortId, java.lang.String userShortId, AsyncCallback<org.eclipse.kapua.app.console.module.authorization.shared.model.GwtAccessInfo> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtAccessInfoServiceAsync instance;

        public static final GwtAccessInfoServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtAccessInfoServiceAsync) GWT.create( GwtAccessInfoService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "accessinfo" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
