package org.eclipse.kapua.app.console.module.endpoint.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtEndpointServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.endpoint.shared.service.GwtEndpointService
     */
    void create( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, org.eclipse.kapua.app.console.module.endpoint.shared.model.GwtEndpointCreator gwtEndpointCreator, AsyncCallback<org.eclipse.kapua.app.console.module.endpoint.shared.model.GwtEndpoint> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.endpoint.shared.service.GwtEndpointService
     */
    void update( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, org.eclipse.kapua.app.console.module.endpoint.shared.model.GwtEndpoint gwtEndpoint, AsyncCallback<org.eclipse.kapua.app.console.module.endpoint.shared.model.GwtEndpoint> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.endpoint.shared.service.GwtEndpointService
     */
    void find( java.lang.String scopeShortId, java.lang.String roleShortId, AsyncCallback<org.eclipse.kapua.app.console.module.endpoint.shared.model.GwtEndpoint> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.endpoint.shared.service.GwtEndpointService
     */
    void query( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.endpoint.shared.model.GwtEndpointQuery gwtEndpointQuery, java.lang.String section, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.endpoint.shared.model.GwtEndpoint>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.endpoint.shared.service.GwtEndpointService
     */
    void delete( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, java.lang.String scopeId, java.lang.String endpointId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.endpoint.shared.service.GwtEndpointService
     */
    void getEndpointDescription( java.lang.String scopeShortId, java.lang.String endpointShortId, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.api.shared.model.GwtGroupedNVPair>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.endpoint.shared.service.GwtEndpointService
     */
    void findAll( java.lang.String scopeId, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.endpoint.shared.model.GwtEndpoint>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.endpoint.shared.service.GwtEndpointService
     */
    void parseEndpointModel( org.eclipse.kapua.app.console.module.endpoint.client.EndpointModel endpointModel, java.lang.String origin, AsyncCallback<org.eclipse.kapua.app.console.module.endpoint.client.EndpointModel> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtEndpointServiceAsync instance;

        public static final GwtEndpointServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtEndpointServiceAsync) GWT.create( GwtEndpointService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "endpoint" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
