package org.eclipse.kapua.app.console.module.endpoint.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/endpoint/src/main/resources/org/eclipse/kapua/app/console/module/endpoint/client/messages/ConsoleEndpointMessages.properties'.
 */
public interface ConsoleEndpointMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "CORS Origin successfully created.".
   * 
   * @return translated "CORS Origin successfully created."
   */
  @DefaultMessage("CORS Origin successfully created.")
  @Key("corsDialogAddConfirmation")
  String corsDialogAddConfirmation();

  /**
   * Translated "CORS Origin creation failed: {0}".
   * 
   * @return translated "CORS Origin creation failed: {0}"
   */
  @DefaultMessage("CORS Origin creation failed: {0}")
  @Key("corsDialogAddError")
  String corsDialogAddError(String arg0);

  /**
   * Translated "CORS Origin".
   * 
   * @return translated "CORS Origin"
   */
  @DefaultMessage("CORS Origin")
  @Key("corsDialogAddFieldOrigin")
  String corsDialogAddFieldOrigin();

  /**
   * Translated "The CORS Origin complete with protocol and port".
   * 
   * @return translated "The CORS Origin complete with protocol and port"
   */
  @DefaultMessage("The CORS Origin complete with protocol and port")
  @Key("corsDialogAddFieldOriginTooltip")
  String corsDialogAddFieldOriginTooltip();

  /**
   * Translated "New CORS Origin".
   * 
   * @return translated "New CORS Origin"
   */
  @DefaultMessage("New CORS Origin")
  @Key("corsDialogAddHeader")
  String corsDialogAddHeader();

  /**
   * Translated "Create a new CORS Origin.".
   * 
   * @return translated "Create a new CORS Origin."
   */
  @DefaultMessage("Create a new CORS Origin.")
  @Key("corsDialogAddInfo")
  String corsDialogAddInfo();

  /**
   * Translated "CORS Origin successfully updated.".
   * 
   * @return translated "CORS Origin successfully updated."
   */
  @DefaultMessage("CORS Origin successfully updated.")
  @Key("corsDialogEditConfirmation")
  String corsDialogEditConfirmation();

  /**
   * Translated "CORS Origin edit failed: {0}".
   * 
   * @return translated "CORS Origin edit failed: {0}"
   */
  @DefaultMessage("CORS Origin edit failed: {0}")
  @Key("corsDialogEditError")
  String corsDialogEditError(String arg0);

  /**
   * Translated "Edit CORS Origin: {0}".
   * 
   * @return translated "Edit CORS Origin: {0}"
   */
  @DefaultMessage("Edit CORS Origin: {0}")
  @Key("corsDialogEditHeader")
  String corsDialogEditHeader(String arg0);

  /**
   * Translated "Edit CORS Origin''s data.".
   * 
   * @return translated "Edit CORS Origin''s data."
   */
  @DefaultMessage("Edit CORS Origin''s data.")
  @Key("corsDialogEditInfo")
  String corsDialogEditInfo();

  /**
   * Translated "Cannot load CORS Origin: {0}".
   * 
   * @return translated "Cannot load CORS Origin: {0}"
   */
  @DefaultMessage("Cannot load CORS Origin: {0}")
  @Key("corsDialogEditLoadFailed")
  String corsDialogEditLoadFailed(String arg0);

  /**
   * Translated "Unable to parse CORS Origin".
   * 
   * @return translated "Unable to parse CORS Origin"
   */
  @DefaultMessage("Unable to parse CORS Origin")
  @Key("corsDialogUnableToParse")
  String corsDialogUnableToParse();

  /**
   * Translated "Endpoint successfully created.".
   * 
   * @return translated "Endpoint successfully created."
   */
  @DefaultMessage("Endpoint successfully created.")
  @Key("dialogAddConfirmation")
  String dialogAddConfirmation();

  /**
   * Translated "Endpoint creation failed: {0}".
   * 
   * @return translated "Endpoint creation failed: {0}"
   */
  @DefaultMessage("Endpoint creation failed: {0}")
  @Key("dialogAddError")
  String dialogAddError(String arg0);

  /**
   * Translated "Domain Name".
   * 
   * @return translated "Domain Name"
   */
  @DefaultMessage("Domain Name")
  @Key("dialogAddFieldDns")
  String dialogAddFieldDns();

  /**
   * Translated "The domain name of the new endpoint. The one available for external use.".
   * 
   * @return translated "The domain name of the new endpoint. The one available for external use."
   */
  @DefaultMessage("The domain name of the new endpoint. The one available for external use.")
  @Key("dialogAddFieldDnsTooltip")
  String dialogAddFieldDnsTooltip();

  /**
   * Translated "The value must comply with RFC 3986 section 3.2.2.".
   * 
   * @return translated "The value must comply with RFC 3986 section 3.2.2."
   */
  @DefaultMessage("The value must comply with RFC 3986 section 3.2.2.")
  @Key("dialogAddFieldDnsValidation")
  String dialogAddFieldDnsValidation();

  /**
   * Translated "Port".
   * 
   * @return translated "Port"
   */
  @DefaultMessage("Port")
  @Key("dialogAddFieldPort")
  String dialogAddFieldPort();

  /**
   * Translated "The port on which this endpoint accepts connections.".
   * 
   * @return translated "The port on which this endpoint accepts connections."
   */
  @DefaultMessage("The port on which this endpoint accepts connections.")
  @Key("dialogAddFieldPortTooltip")
  String dialogAddFieldPortTooltip();

  /**
   * Translated "Only numbers betweend 1 and 65365 are allowed. RFC section 3.2.3.".
   * 
   * @return translated "Only numbers betweend 1 and 65365 are allowed. RFC section 3.2.3."
   */
  @DefaultMessage("Only numbers betweend 1 and 65365 are allowed. RFC section 3.2.3.")
  @Key("dialogAddFieldPortValidation")
  String dialogAddFieldPortValidation();

  /**
   * Translated "Schema".
   * 
   * @return translated "Schema"
   */
  @DefaultMessage("Schema")
  @Key("dialogAddFieldSchema")
  String dialogAddFieldSchema();

  /**
   * Translated "The schema of the protocol, without '://'".
   * 
   * @return translated "The schema of the protocol, without '://'"
   */
  @DefaultMessage("The schema of the protocol, without '://'")
  @Key("dialogAddFieldSchemaTooltip")
  String dialogAddFieldSchemaTooltip();

  /**
   * Translated "The value must comply with RFC 3986 section 3.1.".
   * 
   * @return translated "The value must comply with RFC 3986 section 3.1."
   */
  @DefaultMessage("The value must comply with RFC 3986 section 3.1.")
  @Key("dialogAddFieldSchemaValidation")
  String dialogAddFieldSchemaValidation();

  /**
   * Translated "Secure".
   * 
   * @return translated "Secure"
   */
  @DefaultMessage("Secure")
  @Key("dialogAddFieldSecure")
  String dialogAddFieldSecure();

  /**
   * Translated "If the endpoints identifies a secure connection (i.e.: SSL)".
   * 
   * @return translated "If the endpoints identifies a secure connection (i.e.: SSL)"
   */
  @DefaultMessage("If the endpoints identifies a secure connection (i.e.: SSL)")
  @Key("dialogAddFieldSecureTooltip")
  String dialogAddFieldSecureTooltip();

  /**
   * Translated "New Endpoint".
   * 
   * @return translated "New Endpoint"
   */
  @DefaultMessage("New Endpoint")
  @Key("dialogAddHeader")
  String dialogAddHeader();

  /**
   * Translated "Create a new endpoint.".
   * 
   * @return translated "Create a new endpoint."
   */
  @DefaultMessage("Create a new endpoint.")
  @Key("dialogAddInfo")
  String dialogAddInfo();

  /**
   * Translated "Endpoint successfully deleted.".
   * 
   * @return translated "Endpoint successfully deleted."
   */
  @DefaultMessage("Endpoint successfully deleted.")
  @Key("dialogDeleteConfirmation")
  String dialogDeleteConfirmation();

  /**
   * Translated "Endpoint delete failed: {0}".
   * 
   * @return translated "Endpoint delete failed: {0}"
   */
  @DefaultMessage("Endpoint delete failed: {0}")
  @Key("dialogDeleteError")
  String dialogDeleteError(String arg0);

  /**
   * Translated "Delete Endpoint: {0}".
   * 
   * @return translated "Delete Endpoint: {0}"
   */
  @DefaultMessage("Delete Endpoint: {0}")
  @Key("dialogDeleteHeader")
  String dialogDeleteHeader(String arg0);

  /**
   * Translated "Are you sure you want to delete the selected endpoint?".
   * 
   * @return translated "Are you sure you want to delete the selected endpoint?"
   */
  @DefaultMessage("Are you sure you want to delete the selected endpoint?")
  @Key("dialogDeleteInfo")
  String dialogDeleteInfo();

  /**
   * Translated "Endpoint successfully updated.".
   * 
   * @return translated "Endpoint successfully updated."
   */
  @DefaultMessage("Endpoint successfully updated.")
  @Key("dialogEditConfirmation")
  String dialogEditConfirmation();

  /**
   * Translated "Endpoint edit failed: {0}".
   * 
   * @return translated "Endpoint edit failed: {0}"
   */
  @DefaultMessage("Endpoint edit failed: {0}")
  @Key("dialogEditError")
  String dialogEditError(String arg0);

  /**
   * Translated "Edit Endpoint: {0}".
   * 
   * @return translated "Edit Endpoint: {0}"
   */
  @DefaultMessage("Edit Endpoint: {0}")
  @Key("dialogEditHeader")
  String dialogEditHeader(String arg0);

  /**
   * Translated "Edit endpoint''s data.".
   * 
   * @return translated "Edit endpoint''s data."
   */
  @DefaultMessage("Edit endpoint''s data.")
  @Key("dialogEditInfo")
  String dialogEditInfo();

  /**
   * Translated "Cannot load endpoint: {0}".
   * 
   * @return translated "Cannot load endpoint: {0}"
   */
  @DefaultMessage("Cannot load endpoint: {0}")
  @Key("dialogEditLoadFailed")
  String dialogEditLoadFailed(String arg0);

  /**
   * Translated "Endpoints".
   * 
   * @return translated "Endpoints"
   */
  @DefaultMessage("Endpoints")
  @Key("endpoints")
  String endpoints();

  /**
   * Translated "Domain name".
   * 
   * @return translated "Domain name"
   */
  @DefaultMessage("Domain name")
  @Key("filterFieldEndpointDnsLabel")
  String filterFieldEndpointDnsLabel();

  /**
   * Translated "Port".
   * 
   * @return translated "Port"
   */
  @DefaultMessage("Port")
  @Key("filterFieldEndpointPortLabel")
  String filterFieldEndpointPortLabel();

  /**
   * Translated "Schema".
   * 
   * @return translated "Schema"
   */
  @DefaultMessage("Schema")
  @Key("filterFieldEndpointSchemaLabel")
  String filterFieldEndpointSchemaLabel();

  /**
   * Translated "Secure".
   * 
   * @return translated "Secure"
   */
  @DefaultMessage("Secure")
  @Key("filterFieldEndpointSecureLabel")
  String filterFieldEndpointSecureLabel();

  /**
   * Translated "Endpoint Filter".
   * 
   * @return translated "Endpoint Filter"
   */
  @DefaultMessage("Endpoint Filter")
  @Key("filterHeader")
  String filterHeader();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultMessage("Created By")
  @Key("gridEndpointColumnHeaderCreatedBy")
  String gridEndpointColumnHeaderCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("gridEndpointColumnHeaderCreatedOn")
  String gridEndpointColumnHeaderCreatedOn();

  /**
   * Translated "Domain Name".
   * 
   * @return translated "Domain Name"
   */
  @DefaultMessage("Domain Name")
  @Key("gridEndpointColumnHeaderEndpointDns")
  String gridEndpointColumnHeaderEndpointDns();

  /**
   * Translated "Port".
   * 
   * @return translated "Port"
   */
  @DefaultMessage("Port")
  @Key("gridEndpointColumnHeaderEndpointPort")
  String gridEndpointColumnHeaderEndpointPort();

  /**
   * Translated "Schema".
   * 
   * @return translated "Schema"
   */
  @DefaultMessage("Schema")
  @Key("gridEndpointColumnHeaderEndpointSchema")
  String gridEndpointColumnHeaderEndpointSchema();

  /**
   * Translated "Secure".
   * 
   * @return translated "Secure"
   */
  @DefaultMessage("Secure")
  @Key("gridEndpointColumnHeaderEndpointSecure")
  String gridEndpointColumnHeaderEndpointSecure();

  /**
   * Translated "Usages".
   * 
   * @return translated "Usages"
   */
  @DefaultMessage("Usages")
  @Key("gridEndpointColumnHeaderEndpointUsage")
  String gridEndpointColumnHeaderEndpointUsage();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridEndpointColumnHeaderId")
  String gridEndpointColumnHeaderId();

  /**
   * Translated "Either Port field is empty or contains non-digit symbols.".
   * 
   * @return translated "Either Port field is empty or contains non-digit symbols."
   */
  @DefaultMessage("Either Port field is empty or contains non-digit symbols.")
  @Key("portFieldEmptyOrInvalid")
  String portFieldEmptyOrInvalid();
}
