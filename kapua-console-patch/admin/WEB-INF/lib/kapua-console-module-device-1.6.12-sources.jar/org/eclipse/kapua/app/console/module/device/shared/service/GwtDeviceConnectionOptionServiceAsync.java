package org.eclipse.kapua.app.console.module.device.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtDeviceConnectionOptionServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceConnectionOptionService
     */
    void update( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken gwtXsrfToken, org.eclipse.kapua.app.console.module.device.shared.model.connection.GwtDeviceConnectionOption gwtDeviceConnectionOption, AsyncCallback<org.eclipse.kapua.app.console.module.device.shared.model.connection.GwtDeviceConnectionOption> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtDeviceConnectionOptionServiceAsync instance;

        public static final GwtDeviceConnectionOptionServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtDeviceConnectionOptionServiceAsync) GWT.create( GwtDeviceConnectionOptionService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "deviceConnectionOption" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
