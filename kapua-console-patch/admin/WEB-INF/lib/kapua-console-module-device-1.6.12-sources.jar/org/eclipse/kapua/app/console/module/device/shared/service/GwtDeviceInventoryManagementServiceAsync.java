package org.eclipse.kapua.app.console.module.device.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtDeviceInventoryManagementServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceInventoryManagementService
     */
    void findDeviceInventory( java.lang.String scopeIdString, java.lang.String deviceIdString, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.device.shared.model.management.inventory.GwtInventoryItem>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceInventoryManagementService
     */
    void findDeviceBundles( java.lang.String scopeIdString, java.lang.String deviceIdString, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.device.shared.model.management.inventory.GwtInventoryBundle>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceInventoryManagementService
     */
    void execDeviceBundle( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String scopeIdString, java.lang.String deviceIdString, org.eclipse.kapua.app.console.module.device.shared.model.management.inventory.GwtInventoryBundle gwtInventoryBundle, boolean startOrStop, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceInventoryManagementService
     */
    void findDeviceContainers( java.lang.String scopeIdString, java.lang.String deviceIdString, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.device.shared.model.management.inventory.GwtInventoryContainer>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceInventoryManagementService
     */
    void execDeviceContainer( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String scopeIdString, java.lang.String deviceIdString, org.eclipse.kapua.app.console.module.device.shared.model.management.inventory.GwtInventoryContainer gwtInventoryContainer, boolean startOrStop, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceInventoryManagementService
     */
    void findDeviceSystemPackages( java.lang.String scopeIdString, java.lang.String deviceIdString, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.device.shared.model.management.inventory.GwtInventorySystemPackage>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceInventoryManagementService
     */
    void findDeviceDeploymentPackages( java.lang.String scopeIdString, java.lang.String deviceIdString, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.device.shared.model.management.inventory.GwtInventoryDeploymentPackage>> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtDeviceInventoryManagementServiceAsync instance;

        public static final GwtDeviceInventoryManagementServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtDeviceInventoryManagementServiceAsync) GWT.create( GwtDeviceInventoryManagementService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "deviceManagementInventory" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
