package org.eclipse.kapua.app.console.module.device.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtDeviceKeystoreManagementServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceKeystoreManagementService
     */
    void getKeystores( java.lang.String scopeIdString, java.lang.String deviceIdString, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.device.shared.model.management.keystore.GwtDeviceKeystore>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceKeystoreManagementService
     */
    void getKeystoreItems( java.lang.String scopeIdString, java.lang.String deviceIdString, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.device.shared.model.management.keystore.GwtDeviceKeystoreItem>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceKeystoreManagementService
     */
    void getKeystoreItems( java.lang.String scopeIdString, java.lang.String deviceIdString, java.lang.String keystoreId, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.device.shared.model.management.keystore.GwtDeviceKeystoreItem>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceKeystoreManagementService
     */
    void getKeystoreItem( java.lang.String scopeIdString, java.lang.String deviceIdString, java.lang.String keystoreId, java.lang.String alias, AsyncCallback<org.eclipse.kapua.app.console.module.device.shared.model.management.keystore.GwtDeviceKeystoreItem> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceKeystoreManagementService
     */
    void createKeystoreCertificateRaw( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String scopeIdString, java.lang.String deviceIdString, org.eclipse.kapua.app.console.module.device.shared.model.management.keystore.GwtDeviceKeystoreCertificate gwtKeystoreCertificate, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceKeystoreManagementService
     */
    void createKeystoreCertificateInfo( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String scopeIdString, java.lang.String deviceIdString, java.lang.String keystoreId, java.lang.String alias, java.lang.String certificateInfoIdString, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceKeystoreManagementService
     */
    void createKeystoreKeypair( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String scopeIdString, java.lang.String deviceIdString, org.eclipse.kapua.app.console.module.device.shared.model.management.keystore.GwtDeviceKeystoreKeypair gwtKeystoreKeypair, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceKeystoreManagementService
     */
    void createKeystoreCsr( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String scopeIdString, java.lang.String deviceIdString, org.eclipse.kapua.app.console.module.device.shared.model.management.keystore.GwtDeviceKeystoreCsr gwtDeviceKeystoreCsr, AsyncCallback<org.eclipse.kapua.app.console.module.device.shared.model.management.keystore.GwtDeviceKeystoreCertificate> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceKeystoreManagementService
     */
    void deleteKeystoreItem( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String scopeIdString, java.lang.String deviceIdString, java.lang.String keystoreId, java.lang.String alias, AsyncCallback<Void> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtDeviceKeystoreManagementServiceAsync instance;

        public static final GwtDeviceKeystoreManagementServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtDeviceKeystoreManagementServiceAsync) GWT.create( GwtDeviceKeystoreManagementService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "deviceManagementKeystore" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
