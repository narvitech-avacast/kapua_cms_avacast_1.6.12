package org.eclipse.kapua.app.console.module.device.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtDeviceManagementServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceManagementService
     */
    void findDevicePackages( java.lang.String scopeShortId, java.lang.String deviceShortId, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.device.shared.model.management.packages.GwtDeploymentPackage>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceManagementService
     */
    void installPackage( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, org.eclipse.kapua.app.console.module.device.shared.model.management.packages.GwtPackageInstallRequest gwtPackageInstallRequest, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceManagementService
     */
    void getDownloadOperations( java.lang.String scopeShortId, java.lang.String deviceShortId, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.device.shared.model.management.packages.GwtPackageOperation>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceManagementService
     */
    void uninstallPackage( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, org.eclipse.kapua.app.console.module.device.shared.model.management.packages.GwtPackageUninstallRequest gwtPackageUninstallRequest, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceManagementService
     */
    void findDeviceConfigurations( org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice device, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.api.shared.model.GwtConfigComponent>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceManagementService
     */
    void updateComponentConfiguration( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice device, org.eclipse.kapua.app.console.module.api.shared.model.GwtConfigComponent configComponent, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceManagementService
     */
    void findDeviceSnapshots( org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice device, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.device.shared.model.management.configurations.GwtSnapshot>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceManagementService
     */
    void rollbackDeviceSnapshot( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice device, org.eclipse.kapua.app.console.module.device.shared.model.management.configurations.GwtSnapshot snapshot, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceManagementService
     */
    void findBundles( org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice device, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.device.shared.model.management.bundles.GwtBundle>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceManagementService
     */
    void startBundle( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice device, org.eclipse.kapua.app.console.module.device.shared.model.management.bundles.GwtBundle pair, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceManagementService
     */
    void stopBundle( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice device, org.eclipse.kapua.app.console.module.device.shared.model.management.bundles.GwtBundle pair, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceManagementService
     */
    void executeCommand( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice device, org.eclipse.kapua.app.console.module.device.shared.model.management.command.GwtDeviceCommandInput commandInput, AsyncCallback<org.eclipse.kapua.app.console.module.device.shared.model.management.command.GwtDeviceCommandOutput> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtDeviceManagementServiceAsync instance;

        public static final GwtDeviceManagementServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtDeviceManagementServiceAsync) GWT.create( GwtDeviceManagementService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "deviceManagement" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
