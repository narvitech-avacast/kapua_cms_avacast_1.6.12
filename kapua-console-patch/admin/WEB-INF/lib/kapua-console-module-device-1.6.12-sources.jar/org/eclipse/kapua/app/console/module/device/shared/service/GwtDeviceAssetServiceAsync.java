package org.eclipse.kapua.app.console.module.device.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtDeviceAssetServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceAssetService
     */
    void read( java.lang.String scopeId, java.lang.String deviceId, org.eclipse.kapua.app.console.module.device.shared.model.management.assets.GwtDeviceAssets deviceAssets, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.device.shared.model.management.assets.GwtDeviceAsset>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceAssetService
     */
    void write( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String scopeIdString, java.lang.String deviceIdString, org.eclipse.kapua.app.console.module.device.shared.model.management.assets.GwtDeviceAsset deviceAsset, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceAssetService
     */
    void get( com.extjs.gxt.ui.client.data.PagingLoadConfig pagingLoadConfig, java.lang.String scopeIdString, java.lang.String deviceIdString, org.eclipse.kapua.app.console.module.device.shared.model.management.assets.GwtDeviceAssets deviceAssets, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.device.shared.model.management.assets.GwtDeviceAsset>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceAssetService
     */
    void trickGWT( org.eclipse.kapua.app.console.module.device.shared.model.management.assets.GwtDeviceAssetChannel channel, AsyncCallback<org.eclipse.kapua.app.console.module.device.shared.model.management.assets.GwtDeviceAssetChannel> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtDeviceAssetServiceAsync instance;

        public static final GwtDeviceAssetServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtDeviceAssetServiceAsync) GWT.create( GwtDeviceAssetService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "asset" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
