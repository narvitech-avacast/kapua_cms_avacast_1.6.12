package org.eclipse.kapua.app.console.module.device.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtDeviceConnectionServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceConnectionService
     */
    void find( java.lang.String scopeId, java.lang.String connectionId, AsyncCallback<org.eclipse.kapua.app.console.module.device.shared.model.connection.GwtDeviceConnection> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceConnectionService
     */
    void getConnectionInfo( java.lang.String scopeIdString, java.lang.String gwtDeviceConnectionId, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.api.shared.model.GwtGroupedNVPair>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceConnectionService
     */
    void query( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.device.shared.model.connection.GwtDeviceConnectionQuery gwtDeviceConnectionQuery, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.device.shared.model.connection.GwtDeviceConnection>> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtDeviceConnectionServiceAsync instance;

        public static final GwtDeviceConnectionServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtDeviceConnectionServiceAsync) GWT.create( GwtDeviceConnectionService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "deviceConnection" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
