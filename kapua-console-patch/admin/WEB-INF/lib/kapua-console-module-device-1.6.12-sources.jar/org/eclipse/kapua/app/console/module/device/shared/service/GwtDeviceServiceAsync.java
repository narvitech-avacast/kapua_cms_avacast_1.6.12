package org.eclipse.kapua.app.console.module.device.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtDeviceServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceService
     */
    void findDevice( java.lang.String scopeIdString, java.lang.String deviceIdString, AsyncCallback<org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceService
     */
    void query( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.device.shared.model.GwtDeviceQuery gwtDeviceQuery, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceService
     */
    void query( org.eclipse.kapua.app.console.module.device.shared.model.GwtDeviceQuery gwtDeviceQuery, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceService
     */
    void createDevice( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, org.eclipse.kapua.app.console.module.device.shared.model.GwtDeviceCreator gwtDeviceCreator, AsyncCallback<org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceService
     */
    void updateAttributes( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice gwtDevice, AsyncCallback<org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceService
     */
    void findDeviceEvents( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.device.shared.model.GwtDevice gwtDevice, java.util.Date startDate, java.util.Date endDate, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.device.shared.model.event.GwtDeviceEvent>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceService
     */
    void findDeviceProfile( java.lang.String scopeIdString, java.lang.String clientId, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.api.shared.model.GwtGroupedNVPair>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceService
     */
    void deleteDevice( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, java.lang.String scopeIdString, java.lang.String clientId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceService
     */
    void addDeviceTag( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsrfToken, java.lang.String scopeIdString, java.lang.String deviceIdString, java.lang.String tagIdString, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceService
     */
    void deleteDeviceTag( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, java.lang.String scopeIdString, java.lang.String deviceId, java.lang.String tagId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceService
     */
    void getTileEndpoint( AsyncCallback<java.lang.String> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.device.shared.service.GwtDeviceService
     */
    void isMapEnabled( AsyncCallback<java.lang.Boolean> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtDeviceServiceAsync instance;

        public static final GwtDeviceServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtDeviceServiceAsync) GWT.create( GwtDeviceService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "device" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
