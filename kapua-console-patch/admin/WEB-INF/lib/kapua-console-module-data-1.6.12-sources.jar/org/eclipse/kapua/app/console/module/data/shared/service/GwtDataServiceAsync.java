package org.eclipse.kapua.app.console.module.data.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtDataServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void findTopicsTree( java.lang.String scopeId, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.data.client.GwtTopic>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void updateTopicTimestamps( java.lang.String gwtScopeId, java.util.List<com.extjs.gxt.ui.client.data.ModelData> topics, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.data.client.GwtTopic>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void updateDeviceTimestamps( java.lang.String gwtScopeId, java.util.List<org.eclipse.kapua.app.console.module.data.shared.model.GwtDatastoreDevice> device, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.data.shared.model.GwtDatastoreDevice>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void findTopicsList( com.extjs.gxt.ui.client.data.PagingLoadConfig config, org.eclipse.kapua.app.console.module.data.shared.model.GwtDataChannelInfoQuery query, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.data.client.GwtTopic>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void findDevices( com.extjs.gxt.ui.client.data.PagingLoadConfig config, java.lang.String scopeId, java.lang.String filter, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.data.shared.model.GwtDatastoreDevice>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void findAssets( com.extjs.gxt.ui.client.data.LoadConfig config, java.lang.String scopeId, org.eclipse.kapua.app.console.module.data.shared.model.GwtDatastoreDevice selectedDevice, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.data.shared.model.GwtDatastoreAsset>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void findHeaders( com.extjs.gxt.ui.client.data.LoadConfig config, java.lang.String scopeId, org.eclipse.kapua.app.console.module.data.client.GwtTopic topic, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.data.shared.model.GwtHeader>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void findNumberHeaders( com.extjs.gxt.ui.client.data.LoadConfig config, java.lang.String scopeId, org.eclipse.kapua.app.console.module.data.client.GwtTopic topic, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.data.shared.model.GwtHeader>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void findHeaders( com.extjs.gxt.ui.client.data.LoadConfig config, java.lang.String scopeId, org.eclipse.kapua.app.console.module.data.shared.model.GwtDatastoreDevice device, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.data.shared.model.GwtHeader>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void findMessagesByTopic( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, java.lang.String scopeId, org.eclipse.kapua.app.console.module.data.client.GwtTopic topic, java.util.List<org.eclipse.kapua.app.console.module.data.shared.model.GwtHeader> headers, java.util.Date startDate, java.util.Date endDate, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.data.client.util.GwtMessage>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void findLastMessageByTopic( java.lang.String scopeId, int limit, AsyncCallback<java.util.List<org.eclipse.kapua.app.console.module.data.client.util.GwtMessage>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void findMessagesByDevice( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, java.lang.String scopeId, org.eclipse.kapua.app.console.module.data.shared.model.GwtDatastoreDevice device, java.util.List<org.eclipse.kapua.app.console.module.data.shared.model.GwtHeader> headers, java.util.Date startDate, java.util.Date endDate, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.data.client.util.GwtMessage>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void findMessagesByAssets( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, java.lang.String scopeId, org.eclipse.kapua.app.console.module.data.shared.model.GwtDatastoreDevice device, org.eclipse.kapua.app.console.module.data.shared.model.GwtDatastoreAsset asset, java.util.List<org.eclipse.kapua.app.console.module.data.shared.model.GwtHeader> headers, java.util.Date startDate, java.util.Date endDate, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.data.client.util.GwtMessage>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.data.shared.service.GwtDataService
     */
    void findHeaders( com.extjs.gxt.ui.client.data.LoadConfig config, java.lang.String scopeId, org.eclipse.kapua.app.console.module.data.shared.model.GwtDatastoreAsset gwtDatastoreAsset, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.data.shared.model.GwtHeader>> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtDataServiceAsync instance;

        public static final GwtDataServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtDataServiceAsync) GWT.create( GwtDataService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "data" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
