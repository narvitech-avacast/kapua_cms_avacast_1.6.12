package org.eclipse.kapua.app.console.module.data.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/data/src/main/resources/org/eclipse/kapua/app/console/module/data/client/messages/ConsoleDataMessages.properties'.
 */
public interface ConsoleDataMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "Select the Device which published the data, then select one of the assets available for the selected device, then select one or more channels available for the selected asset. Finally click the Query button and view the results in tabular form.".
   * 
   * @return translated "Select the Device which published the data, then select one of the assets available for the selected device, then select one or more channels available for the selected asset. Finally click the Query button and view the results in tabular form."
   */
  @DefaultMessage("Select the Device which published the data, then select one of the assets available for the selected device, then select one or more channels available for the selected asset. Finally click the Query button and view the results in tabular form.")
  @Key("assetTabItemMessage")
  String assetTabItemMessage();

  /**
   * Translated "Query".
   * 
   * @return translated "Query"
   */
  @DefaultMessage("Query")
  @Key("assetTabItemQueryButtonText")
  String assetTabItemQueryButtonText();

  /**
   * Translated "By Asset".
   * 
   * @return translated "By Asset"
   */
  @DefaultMessage("By Asset")
  @Key("assetTabItemTitle")
  String assetTabItemTitle();

  /**
   * Translated "Asset".
   * 
   * @return translated "Asset"
   */
  @DefaultMessage("Asset")
  @Key("assetTableAssetHeader")
  String assetTableAssetHeader();

  /**
   * Translated "Driver".
   * 
   * @return translated "Driver"
   */
  @DefaultMessage("Driver")
  @Key("assetTableDriverHeader")
  String assetTableDriverHeader();

  /**
   * Translated "No Assets".
   * 
   * @return translated "No Assets"
   */
  @DefaultMessage("No Assets")
  @Key("assetTableEmptyText")
  String assetTableEmptyText();

  /**
   * Translated "Available Assets".
   * 
   * @return translated "Available Assets"
   */
  @DefaultMessage("Available Assets")
  @Key("assetTableHeader")
  String assetTableHeader();

  /**
   * Translated "Channel Metric".
   * 
   * @return translated "Channel Metric"
   */
  @DefaultMessage("Channel Metric")
  @Key("channelTableChannelHeader")
  String channelTableChannelHeader();

  /**
   * Translated "No Channel Metrics".
   * 
   * @return translated "No Channel Metrics"
   */
  @DefaultMessage("No Channel Metrics")
  @Key("channelTableEmptyText")
  String channelTableEmptyText();

  /**
   * Translated "Available Channel Metrics".
   * 
   * @return translated "Available Channel Metrics"
   */
  @DefaultMessage("Available Channel Metrics")
  @Key("channelTableHeader")
  String channelTableHeader();

  /**
   * Translated "Type".
   * 
   * @return translated "Type"
   */
  @DefaultMessage("Type")
  @Key("channelTableTypeHeader")
  String channelTableTypeHeader();

  /**
   * Translated "Data".
   * 
   * @return translated "Data"
   */
  @DefaultMessage("Data")
  @Key("data")
  String data();

  /**
   * Translated "Date Range:".
   * 
   * @return translated "Date Range:"
   */
  @DefaultMessage("Date Range:")
  @Key("dateRange")
  String dateRange();

  /**
   * Translated "No Devices".
   * 
   * @return translated "No Devices"
   */
  @DefaultMessage("No Devices")
  @Key("deviceInfoGridEmptyText")
  String deviceInfoGridEmptyText();

  /**
   * Translated "Client ID Prefix Filter".
   * 
   * @return translated "Client ID Prefix Filter"
   */
  @DefaultMessage("Client ID Prefix Filter")
  @Key("deviceInfoTableFilter")
  String deviceInfoTableFilter();

  /**
   * Translated "Available Devices".
   * 
   * @return translated "Available Devices"
   */
  @DefaultMessage("Available Devices")
  @Key("deviceInfoTableHeader")
  String deviceInfoTableHeader();

  /**
   * Translated "Last Post Date".
   * 
   * @return translated "Last Post Date"
   */
  @DefaultMessage("Last Post Date")
  @Key("deviceInfoTableLastPostedHeader")
  String deviceInfoTableLastPostedHeader();

  /**
   * Translated "Device".
   * 
   * @return translated "Device"
   */
  @DefaultMessage("Device")
  @Key("deviceInfoTableTopicHeader")
  String deviceInfoTableTopicHeader();

  /**
   * Translated "Select the Device which published the data, then select one or more of the available metrics for that device. Finally click the Query button and view the results in tabular format.".
   * 
   * @return translated "Select the Device which published the data, then select one or more of the available metrics for that device. Finally click the Query button and view the results in tabular format."
   */
  @DefaultMessage("Select the Device which published the data, then select one or more of the available metrics for that device. Finally click the Query button and view the results in tabular format.")
  @Key("deviceTabItemMessage")
  String deviceTabItemMessage();

  /**
   * Translated "Query".
   * 
   * @return translated "Query"
   */
  @DefaultMessage("Query")
  @Key("deviceTabItemQueryButtonText")
  String deviceTabItemQueryButtonText();

  /**
   * Translated "By Device".
   * 
   * @return translated "By Device"
   */
  @DefaultMessage("By Device")
  @Key("deviceTabItemTitle")
  String deviceTabItemTitle();

  /**
   * Translated "No Devices".
   * 
   * @return translated "No Devices"
   */
  @DefaultMessage("No Devices")
  @Key("deviceTableEmptyText")
  String deviceTableEmptyText();

  /**
   * Translated "Channel".
   * 
   * @return translated "Channel"
   */
  @DefaultMessage("Channel")
  @Key("metricsTableChannelHeader")
  String metricsTableChannelHeader();

  /**
   * Translated "Type".
   * 
   * @return translated "Type"
   */
  @DefaultMessage("Type")
  @Key("metricsTableChannelTypeHeader")
  String metricsTableChannelTypeHeader();

  /**
   * Translated "No Metrics".
   * 
   * @return translated "No Metrics"
   */
  @DefaultMessage("No Metrics")
  @Key("metricsTableEmptyText")
  String metricsTableEmptyText();

  /**
   * Translated "Available Channel Metrics".
   * 
   * @return translated "Available Channel Metrics"
   */
  @DefaultMessage("Available Channel Metrics")
  @Key("metricsTableHeaderAssets")
  String metricsTableHeaderAssets();

  /**
   * Translated "Available Metrics for Device: {0}".
   * 
   * @return translated "Available Metrics for Device: {0}"
   */
  @DefaultMessage("Available Metrics for Device: {0}")
  @Key("metricsTableHeaderDevice")
  String metricsTableHeaderDevice(String arg0);

  /**
   * Translated "Available Metrics for Topic: {0}".
   * 
   * @return translated "Available Metrics for Topic: {0}"
   */
  @DefaultMessage("Available Metrics for Topic: {0}")
  @Key("metricsTableHeaderTopic")
  String metricsTableHeaderTopic(String arg0);

  /**
   * Translated "Metric".
   * 
   * @return translated "Metric"
   */
  @DefaultMessage("Metric")
  @Key("metricsTableMetricHeader")
  String metricsTableMetricHeader();

  /**
   * Translated "Metric Type".
   * 
   * @return translated "Metric Type"
   */
  @DefaultMessage("Metric Type")
  @Key("metricsTableMetricTypeHeader")
  String metricsTableMetricTypeHeader();

  /**
   * Translated "No Data currently available!".
   * 
   * @return translated "No Data currently available!"
   */
  @DefaultMessage("No Data currently available!")
  @Key("noDataMessage")
  String noDataMessage();

  /**
   * Translated "Refresh".
   * 
   * @return translated "Refresh"
   */
  @DefaultMessage("Refresh")
  @Key("refresh")
  String refresh();

  /**
   * Translated "Results Chart".
   * 
   * @return translated "Results Chart"
   */
  @DefaultMessage("Results Chart")
  @Key("resultsChartTabItemTitle")
  String resultsChartTabItemTitle();

  /**
   * Translated "Channel".
   * 
   * @return translated "Channel"
   */
  @DefaultMessage("Channel")
  @Key("resultsTableChannelHeader")
  String resultsTableChannelHeader();

  /**
   * Translated "Device".
   * 
   * @return translated "Device"
   */
  @DefaultMessage("Device")
  @Key("resultsTableDeviceHeader")
  String resultsTableDeviceHeader();

  /**
   * Translated "No Results".
   * 
   * @return translated "No Results"
   */
  @DefaultMessage("No Results")
  @Key("resultsTableEmptyText")
  String resultsTableEmptyText();

  /**
   * Translated "Export to CSV".
   * 
   * @return translated "Export to CSV"
   */
  @DefaultMessage("Export to CSV")
  @Key("resultsTableExportToCSV")
  String resultsTableExportToCSV();

  /**
   * Translated "Export to Excel".
   * 
   * @return translated "Export to Excel"
   */
  @DefaultMessage("Export to Excel")
  @Key("resultsTableExportToExcel")
  String resultsTableExportToExcel();

  /**
   * Translated "Results".
   * 
   * @return translated "Results"
   */
  @DefaultMessage("Results")
  @Key("resultsTableTabItemTitle")
  String resultsTableTabItemTitle();

  /**
   * Translated "Timestamp".
   * 
   * @return translated "Timestamp"
   */
  @DefaultMessage("Timestamp")
  @Key("resultsTableTimestampHeader")
  String resultsTableTimestampHeader();

  /**
   * Translated "Topic".
   * 
   * @return translated "Topic"
   */
  @DefaultMessage("Topic")
  @Key("resultsTableTopicHeader")
  String resultsTableTopicHeader();

  /**
   * Translated "Search".
   * 
   * @return translated "Search"
   */
  @DefaultMessage("Search")
  @Key("searchButton")
  String searchButton();

  /**
   * Translated "No Topics".
   * 
   * @return translated "No Topics"
   */
  @DefaultMessage("No Topics")
  @Key("topicInfoGridEmptyText")
  String topicInfoGridEmptyText();

  /**
   * Translated "Calculating...".
   * 
   * @return translated "Calculating..."
   */
  @DefaultMessage("Calculating...")
  @Key("topicInfoTableCalculatingLastPostDate")
  String topicInfoTableCalculatingLastPostDate();

  /**
   * Translated "Available Topics".
   * 
   * @return translated "Available Topics"
   */
  @DefaultMessage("Available Topics")
  @Key("topicInfoTableHeader")
  String topicInfoTableHeader();

  /**
   * Translated "Last Post Date".
   * 
   * @return translated "Last Post Date"
   */
  @DefaultMessage("Last Post Date")
  @Key("topicInfoTableLastPostedHeader")
  String topicInfoTableLastPostedHeader();

  /**
   * Translated "No Messages".
   * 
   * @return translated "No Messages"
   */
  @DefaultMessage("No Messages")
  @Key("topicInfoTableNoLastPostDate")
  String topicInfoTableNoLastPostDate();

  /**
   * Translated "Topic".
   * 
   * @return translated "Topic"
   */
  @DefaultMessage("Topic")
  @Key("topicInfoTableTopicHeader")
  String topicInfoTableTopicHeader();

  /**
   * Translated "Select the Topic under which the data was published, then select one or more of the available metrics for that topic. Finally click the Query button and view the results in a tabular format.".
   * 
   * @return translated "Select the Topic under which the data was published, then select one or more of the available metrics for that topic. Finally click the Query button and view the results in a tabular format."
   */
  @DefaultMessage("Select the Topic under which the data was published, then select one or more of the available metrics for that topic. Finally click the Query button and view the results in a tabular format.")
  @Key("topicTabItemMessage")
  String topicTabItemMessage();

  /**
   * Translated "Query".
   * 
   * @return translated "Query"
   */
  @DefaultMessage("Query")
  @Key("topicTabItemQueryButtonText")
  String topicTabItemQueryButtonText();

  /**
   * Translated "By Topic".
   * 
   * @return translated "By Topic"
   */
  @DefaultMessage("By Topic")
  @Key("topicTabItemTitle")
  String topicTabItemTitle();

  /**
   * Translated "Warning! The query returned more than 10000 results. Please refine the time range.".
   * 
   * @return translated "Warning! The query returned more than 10000 results. Please refine the time range."
   */
  @DefaultMessage("Warning! The query returned more than 10000 results. Please refine the time range.")
  @Key("warningLimitReached")
  String warningLimitReached();
}
