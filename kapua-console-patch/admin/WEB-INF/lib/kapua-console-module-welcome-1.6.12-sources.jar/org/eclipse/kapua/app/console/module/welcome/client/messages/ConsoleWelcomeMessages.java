package org.eclipse.kapua.app.console.module.welcome.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/welcome/src/main/resources/org/eclipse/kapua/app/console/module/welcome/client/messages/ConsoleWelcomeMessages.properties'.
 */
public interface ConsoleWelcomeMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "Welcome".
   * 
   * @return translated "Welcome"
   */
  @DefaultMessage("Welcome")
  @Key("title")
  String title();

  /**
   * Translated "<a href=\"http://eclipse.org/kapua\" target=\"_blank\">Eclipse Kapua&trade;</a> is a modular platform providing the services required to manage IoT gateways and smart edge devices.<br/>Kapua provides a core integration framework and a initial set of core IoT services including a device registry, device management services, messaging services, data management, and application enablement.<br/><br/>To install Kapua in your local environment please refer to the section <a href=\"http://download.eclipse.org/kapua/docs/develop/developer-guide/en/running.html\" target=\"_blank\">running Kapua</a> of the developer guide.".
   * 
   * @return translated "<a href=\"http://eclipse.org/kapua\" target=\"_blank\">Eclipse Kapua&trade;</a> is a modular platform providing the services required to manage IoT gateways and smart edge devices.<br/>Kapua provides a core integration framework and a initial set of core IoT services including a device registry, device management services, messaging services, data management, and application enablement.<br/><br/>To install Kapua in your local environment please refer to the section <a href=\"http://download.eclipse.org/kapua/docs/develop/developer-guide/en/running.html\" target=\"_blank\">running Kapua</a> of the developer guide."
   */
  @DefaultMessage("<a href=\"http://eclipse.org/kapua\" target=\"_blank\">Eclipse Kapua&trade;</a> is a modular platform providing the services required to manage IoT gateways and smart edge devices.<br/>Kapua provides a core integration framework and a initial set of core IoT services including a device registry, device management services, messaging services, data management, and application enablement.<br/><br/>To install Kapua in your local environment please refer to the section <a href=\"http://download.eclipse.org/kapua/docs/develop/developer-guide/en/running.html\" target=\"_blank\">running Kapua</a> of the developer guide.")
  @Key("welcomeMessage")
  String welcomeMessage();
}
