package org.eclipse.kapua.app.console.module.user.client.messages;

/**
 * Interface to represent the messages contained in resource bundle:
 * 	D:/Kapua_cms_bill_1.6.12/kapua-1.6.12/kapua-1.6.12/console/module/user/src/main/resources/org/eclipse/kapua/app/console/module/user/client/messages/ConsoleUserMessages.properties'.
 */
public interface ConsoleUserMessages extends com.google.gwt.i18n.client.Messages {
  
  /**
   * Translated "User successfully created.".
   * 
   * @return translated "User successfully created."
   */
  @DefaultMessage("User successfully created.")
  @Key("dialogAddConfirmation")
  String dialogAddConfirmation();

  /**
   * Translated "User creation failed: {0}".
   * 
   * @return translated "User creation failed: {0}"
   */
  @DefaultMessage("User creation failed: {0}")
  @Key("dialogAddError")
  String dialogAddError(String arg0);

  /**
   * Translated "Expiration Date".
   * 
   * @return translated "Expiration Date"
   */
  @DefaultMessage("Expiration Date")
  @Key("dialogAddExpirationDate")
  String dialogAddExpirationDate();

  /**
   * Translated "Set the expiration date for the user. It should be in format DD/MM/YYYY.".
   * 
   * @return translated "Set the expiration date for the user. It should be in format DD/MM/YYYY."
   */
  @DefaultMessage("Set the expiration date for the user. It should be in format DD/MM/YYYY.")
  @Key("dialogAddExpirationDateTooltip")
  String dialogAddExpirationDateTooltip();

  /**
   * Translated "Confirm Password".
   * 
   * @return translated "Confirm Password"
   */
  @DefaultMessage("Confirm Password")
  @Key("dialogAddFieldConfirmPassword")
  String dialogAddFieldConfirmPassword();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultMessage("Display Name")
  @Key("dialogAddFieldDisplayName")
  String dialogAddFieldDisplayName();

  /**
   * Translated "Enter a display name for more complete profile of the user.".
   * 
   * @return translated "Enter a display name for more complete profile of the user."
   */
  @DefaultMessage("Enter a display name for more complete profile of the user.")
  @Key("dialogAddFieldDisplayNameTooltip")
  String dialogAddFieldDisplayNameTooltip();

  /**
   * Translated "Email".
   * 
   * @return translated "Email"
   */
  @DefaultMessage("Email")
  @Key("dialogAddFieldEmail")
  String dialogAddFieldEmail();

  /**
   * Translated "Enter an email for more complete profile of the user. Email should be in format username@domain.com.".
   * 
   * @return translated "Enter an email for more complete profile of the user. Email should be in format username@domain.com."
   */
  @DefaultMessage("Enter an email for more complete profile of the user. Email should be in format username@domain.com.")
  @Key("dialogAddFieldEmailTooltip")
  String dialogAddFieldEmailTooltip();

  /**
   * Translated "External Id".
   * 
   * @return translated "External Id"
   */
  @DefaultMessage("External Id")
  @Key("dialogAddFieldExternalId")
  String dialogAddFieldExternalId();

  /**
   * Translated "Set the external Id for the user. This Id is provided by the OpenId Connect Provider.".
   * 
   * @return translated "Set the external Id for the user. This Id is provided by the OpenId Connect Provider."
   */
  @DefaultMessage("Set the external Id for the user. This Id is provided by the OpenId Connect Provider.")
  @Key("dialogAddFieldExternalIdTooltip")
  String dialogAddFieldExternalIdTooltip();

  /**
   * Translated "External user".
   * 
   * @return translated "External user"
   */
  @DefaultMessage("External user")
  @Key("dialogAddFieldExternalUser")
  String dialogAddFieldExternalUser();

  /**
   * Translated "Internal user".
   * 
   * @return translated "Internal user"
   */
  @DefaultMessage("Internal user")
  @Key("dialogAddFieldInternalUser")
  String dialogAddFieldInternalUser();

  /**
   * Translated "User''s unique name.".
   * 
   * @return translated "User''s unique name."
   */
  @DefaultMessage("User''s unique name.")
  @Key("dialogAddFieldNameEditDialogTooltip")
  String dialogAddFieldNameEditDialogTooltip();

  /**
   * Translated "Username must be at least 3 characters long and can contain alphanumeric characters combined with dash and/or underscore.".
   * 
   * @return translated "Username must be at least 3 characters long and can contain alphanumeric characters combined with dash and/or underscore."
   */
  @DefaultMessage("Username must be at least 3 characters long and can contain alphanumeric characters combined with dash and/or underscore.")
  @Key("dialogAddFieldNameTooltip")
  String dialogAddFieldNameTooltip();

  /**
   * Translated "Password".
   * 
   * @return translated "Password"
   */
  @DefaultMessage("Password")
  @Key("dialogAddFieldPassword")
  String dialogAddFieldPassword();

  /**
   * Translated "Phone Number".
   * 
   * @return translated "Phone Number"
   */
  @DefaultMessage("Phone Number")
  @Key("dialogAddFieldPhoneNumber")
  String dialogAddFieldPhoneNumber();

  /**
   * Translated "Enter a phone number for more complete profile of the user. It can contain only digits and an optional \"+\" sign at the beginning.".
   * 
   * @return translated "Enter a phone number for more complete profile of the user. It can contain only digits and an optional \"+\" sign at the beginning."
   */
  @DefaultMessage("Enter a phone number for more complete profile of the user. It can contain only digits and an optional \"+\" sign at the beginning.")
  @Key("dialogAddFieldPhoneNumberTooltip")
  String dialogAddFieldPhoneNumberTooltip();

  /**
   * Translated "User Information".
   * 
   * @return translated "User Information"
   */
  @DefaultMessage("User Information")
  @Key("dialogAddFieldSet")
  String dialogAddFieldSet();

  /**
   * Translated "User Type".
   * 
   * @return translated "User Type"
   */
  @DefaultMessage("User Type")
  @Key("dialogAddFieldUserTypeRadioButton")
  String dialogAddFieldUserTypeRadioButton();

  /**
   * Translated "Username".
   * 
   * @return translated "Username"
   */
  @DefaultMessage("Username")
  @Key("dialogAddFieldUsername")
  String dialogAddFieldUsername();

  /**
   * Translated "New User".
   * 
   * @return translated "New User"
   */
  @DefaultMessage("New User")
  @Key("dialogAddHeader")
  String dialogAddHeader();

  /**
   * Translated "Create a new user providing a username and a password or an external id. All other parameters are optional.".
   * 
   * @return translated "Create a new user providing a username and a password or an external id. All other parameters are optional."
   */
  @DefaultMessage("Create a new user providing a username and a password or an external id. All other parameters are optional.")
  @Key("dialogAddInfo")
  String dialogAddInfo();

  /**
   * Translated "No Expiration".
   * 
   * @return translated "No Expiration"
   */
  @DefaultMessage("No Expiration")
  @Key("dialogAddNoExpiration")
  String dialogAddNoExpiration();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("dialogAddStatus")
  String dialogAddStatus();

  /**
   * Translated "Select if the user should be enabled or disabled.".
   * 
   * @return translated "Select if the user should be enabled or disabled."
   */
  @DefaultMessage("Select if the user should be enabled or disabled.")
  @Key("dialogAddStatusTooltip")
  String dialogAddStatusTooltip();

  /**
   * Translated "Password must be {0} to 255 characters long and must contain at least one lower case letter, one upper case letter, one digit and one special character. Allowed special characters: # | '' ! \" £ $ % & @ / [ ] ( ) '{' '}' = ? ^ '' > < , ; . : - _ * + € ^ ` ~".
   * 
   * @return translated "Password must be {0} to 255 characters long and must contain at least one lower case letter, one upper case letter, one digit and one special character. Allowed special characters: # | '' ! \" £ $ % & @ / [ ] ( ) '{' '}' = ? ^ '' > < , ; . : - _ * + € ^ ` ~"
   */
  @DefaultMessage("Password must be {0} to 255 characters long and must contain at least one lower case letter, one upper case letter, one digit and one special character. Allowed special characters: # | '' ! \" £ $ % & @ / [ ] ( ) '{' '}' = ? ^ '' > < , ; . : - _ * + € ^ ` ~")
  @Key("dialogAddTooltipPassword")
  String dialogAddTooltipPassword(String arg0);

  /**
   * Translated "User successfully deleted.".
   * 
   * @return translated "User successfully deleted."
   */
  @DefaultMessage("User successfully deleted.")
  @Key("dialogDeleteConfirmation")
  String dialogDeleteConfirmation();

  /**
   * Translated "User delete failed: {0}".
   * 
   * @return translated "User delete failed: {0}"
   */
  @DefaultMessage("User delete failed: {0}")
  @Key("dialogDeleteError")
  String dialogDeleteError(String arg0);

  /**
   * Translated "Delete User: {0}".
   * 
   * @return translated "Delete User: {0}"
   */
  @DefaultMessage("Delete User: {0}")
  @Key("dialogDeleteHeader")
  String dialogDeleteHeader(String arg0);

  /**
   * Translated "Are you sure you want to delete the selected user?".
   * 
   * @return translated "Are you sure you want to delete the selected user?"
   */
  @DefaultMessage("Are you sure you want to delete the selected user?")
  @Key("dialogDeleteInfo")
  String dialogDeleteInfo();

  /**
   * Translated "Admin user cannot have an expiration date.".
   * 
   * @return translated "Admin user cannot have an expiration date."
   */
  @DefaultMessage("Admin user cannot have an expiration date.")
  @Key("dialogEditAdminExpirationDateError")
  String dialogEditAdminExpirationDateError();

  /**
   * Translated "Admin user cannot be disabled.".
   * 
   * @return translated "Admin user cannot be disabled."
   */
  @DefaultMessage("Admin user cannot be disabled.")
  @Key("dialogEditAdminUserStatusError")
  String dialogEditAdminUserStatusError();

  /**
   * Translated "User successfully updated.".
   * 
   * @return translated "User successfully updated."
   */
  @DefaultMessage("User successfully updated.")
  @Key("dialogEditConfirmation")
  String dialogEditConfirmation();

  /**
   * Translated "User edit failed: {0}".
   * 
   * @return translated "User edit failed: {0}"
   */
  @DefaultMessage("User edit failed: {0}")
  @Key("dialogEditError")
  String dialogEditError(String arg0);

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("dialogEditFieldName")
  String dialogEditFieldName();

  /**
   * Translated "The name of the User. It must be unique.".
   * 
   * @return translated "The name of the User. It must be unique."
   */
  @DefaultMessage("The name of the User. It must be unique.")
  @Key("dialogEditFieldNameTooltip")
  String dialogEditFieldNameTooltip();

  /**
   * Translated "Edit User: {0}".
   * 
   * @return translated "Edit User: {0}"
   */
  @DefaultMessage("Edit User: {0}")
  @Key("dialogEditHeader")
  String dialogEditHeader(String arg0);

  /**
   * Translated "Edit user''s attributes.".
   * 
   * @return translated "Edit user''s attributes."
   */
  @DefaultMessage("Edit user''s attributes.")
  @Key("dialogEditInfo")
  String dialogEditInfo();

  /**
   * Translated "Cannot load user: {0}".
   * 
   * @return translated "Cannot load user: {0}"
   */
  @DefaultMessage("Cannot load user: {0}")
  @Key("dialogEditLoadFailed")
  String dialogEditLoadFailed(String arg0);

  /**
   * Translated "After changing Display Name parameter please refresh browser window in order to update it in all views.".
   * 
   * @return translated "After changing Display Name parameter please refresh browser window in order to update it in all views."
   */
  @DefaultMessage("After changing Display Name parameter please refresh browser window in order to update it in all views.")
  @Key("dialogEditUserName")
  String dialogEditUserName();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultMessage("Display Name")
  @Key("filterFieldDisplayName")
  String filterFieldDisplayName();

  /**
   * Translated "Email".
   * 
   * @return translated "Email"
   */
  @DefaultMessage("Email")
  @Key("filterFieldEmail")
  String filterFieldEmail();

  /**
   * Translated "Expiration Date".
   * 
   * @return translated "Expiration Date"
   */
  @DefaultMessage("Expiration Date")
  @Key("filterFieldExpirationDate")
  String filterFieldExpirationDate();

  /**
   * Translated "Phone Number".
   * 
   * @return translated "Phone Number"
   */
  @DefaultMessage("Phone Number")
  @Key("filterFieldPhoneNumber")
  String filterFieldPhoneNumber();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("filterFieldStatusLabel")
  String filterFieldStatusLabel();

  /**
   * Translated "User Type".
   * 
   * @return translated "User Type"
   */
  @DefaultMessage("User Type")
  @Key("filterFieldUserTypeLabel")
  String filterFieldUserTypeLabel();

  /**
   * Translated "Username".
   * 
   * @return translated "Username"
   */
  @DefaultMessage("Username")
  @Key("filterFieldUsernameLabel")
  String filterFieldUsernameLabel();

  /**
   * Translated "User Filter".
   * 
   * @return translated "User Filter"
   */
  @DefaultMessage("User Filter")
  @Key("filterHeader")
  String filterHeader();

  /**
   * Translated "Created By".
   * 
   * @return translated "Created By"
   */
  @DefaultMessage("Created By")
  @Key("gridUserColumnHeaderCreatedBy")
  String gridUserColumnHeaderCreatedBy();

  /**
   * Translated "Created On".
   * 
   * @return translated "Created On"
   */
  @DefaultMessage("Created On")
  @Key("gridUserColumnHeaderCreatedOn")
  String gridUserColumnHeaderCreatedOn();

  /**
   * Translated "Display Name".
   * 
   * @return translated "Display Name"
   */
  @DefaultMessage("Display Name")
  @Key("gridUserColumnHeaderDisplayName")
  String gridUserColumnHeaderDisplayName();

  /**
   * Translated "Email".
   * 
   * @return translated "Email"
   */
  @DefaultMessage("Email")
  @Key("gridUserColumnHeaderEmail")
  String gridUserColumnHeaderEmail();

  /**
   * Translated "Expiration Date".
   * 
   * @return translated "Expiration Date"
   */
  @DefaultMessage("Expiration Date")
  @Key("gridUserColumnHeaderExpirationDate")
  String gridUserColumnHeaderExpirationDate();

  /**
   * Translated "Id".
   * 
   * @return translated "Id"
   */
  @DefaultMessage("Id")
  @Key("gridUserColumnHeaderId")
  String gridUserColumnHeaderId();

  /**
   * Translated "Modified By".
   * 
   * @return translated "Modified By"
   */
  @DefaultMessage("Modified By")
  @Key("gridUserColumnHeaderModifiedBy")
  String gridUserColumnHeaderModifiedBy();

  /**
   * Translated "Modified On".
   * 
   * @return translated "Modified On"
   */
  @DefaultMessage("Modified On")
  @Key("gridUserColumnHeaderModifiedOn")
  String gridUserColumnHeaderModifiedOn();

  /**
   * Translated "Phone Number".
   * 
   * @return translated "Phone Number"
   */
  @DefaultMessage("Phone Number")
  @Key("gridUserColumnHeaderPhoneNumber")
  String gridUserColumnHeaderPhoneNumber();

  /**
   * Translated "Status".
   * 
   * @return translated "Status"
   */
  @DefaultMessage("Status")
  @Key("gridUserColumnHeaderStatus")
  String gridUserColumnHeaderStatus();

  /**
   * Translated "Type".
   * 
   * @return translated "Type"
   */
  @DefaultMessage("Type")
  @Key("gridUserColumnHeaderUserType")
  String gridUserColumnHeaderUserType();

  /**
   * Translated "Name".
   * 
   * @return translated "Name"
   */
  @DefaultMessage("Name")
  @Key("gridUserColumnHeaderUsername")
  String gridUserColumnHeaderUsername();

  /**
   * Translated "Credentials".
   * 
   * @return translated "Credentials"
   */
  @DefaultMessage("Credentials")
  @Key("gridUserTabCredentialsLabel")
  String gridUserTabCredentialsLabel();

  /**
   * Translated "Users".
   * 
   * @return translated "Users"
   */
  @DefaultMessage("Users")
  @Key("mainMenuUsers")
  String mainMenuUsers();
}
