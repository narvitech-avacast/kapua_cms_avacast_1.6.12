package org.eclipse.kapua.app.console.module.user.shared.service;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

public interface GwtUserServiceAsync
{

    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.user.shared.service.GwtUserService
     */
    void create( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, org.eclipse.kapua.app.console.module.user.shared.model.GwtUserCreator gwtUserCreator, AsyncCallback<org.eclipse.kapua.app.console.module.user.shared.model.GwtUser> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.user.shared.service.GwtUserService
     */
    void update( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, org.eclipse.kapua.app.console.module.user.shared.model.GwtUser gwtUser, AsyncCallback<org.eclipse.kapua.app.console.module.user.shared.model.GwtUser> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.user.shared.service.GwtUserService
     */
    void delete( org.eclipse.kapua.app.console.module.api.shared.model.GwtXSRFToken xsfrToken, java.lang.String accountId, java.lang.String gwtUserId, AsyncCallback<Void> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.user.shared.service.GwtUserService
     */
    void find( java.lang.String accountId, java.lang.String userId, AsyncCallback<org.eclipse.kapua.app.console.module.user.shared.model.GwtUser> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.user.shared.service.GwtUserService
     */
    void findAll( java.lang.String scopeIdString, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.user.shared.model.GwtUser>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.user.shared.service.GwtUserService
     */
    void query( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.user.shared.model.GwtUserQuery gwtUserQuery, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.user.shared.model.GwtUser>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.user.shared.service.GwtUserService
     */
    void getUserDescription( boolean isSsoEnabled, java.lang.String shortScopeId, java.lang.String shortUserId, AsyncCallback<com.extjs.gxt.ui.client.data.ListLoadResult<org.eclipse.kapua.app.console.module.api.shared.model.GwtGroupedNVPair>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.user.shared.service.GwtUserService
     */
    void getUsersForRole( com.extjs.gxt.ui.client.data.PagingLoadConfig pagingLoadConfig, org.eclipse.kapua.app.console.module.authorization.shared.model.GwtAccessRoleQuery query, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.user.shared.model.GwtUser>> callback );


    /**
     * GWT-RPC service  asynchronous (client-side) interface
     * @see org.eclipse.kapua.app.console.module.user.shared.service.GwtUserService
     */
    void getUsersForAccount( com.extjs.gxt.ui.client.data.PagingLoadConfig loadConfig, org.eclipse.kapua.app.console.module.user.shared.model.GwtUserQuery gwtUserQuery, java.lang.String accountId, AsyncCallback<com.extjs.gxt.ui.client.data.PagingLoadResult<org.eclipse.kapua.app.console.module.user.shared.model.GwtUser>> callback );


    /**
     * Utility class to get the RPC Async interface from client-side code
     */
    public static final class Util 
    { 
        private static GwtUserServiceAsync instance;

        public static final GwtUserServiceAsync getInstance()
        {
            if ( instance == null )
            {
                instance = (GwtUserServiceAsync) GWT.create( GwtUserService.class );
                ServiceDefTarget target = (ServiceDefTarget) instance;
                target.setServiceEntryPoint( GWT.getModuleBaseURL() + "user" );
            }
            return instance;
        }

        private Util()
        {
            // Utility class should not be instanciated
        }
    }
}
